Option Strict Off
Option Explicit On
Imports IWshRuntimeLibrary
Imports VB6 = Microsoft.VisualBasic
Imports System
Imports System.Runtime.InteropServices
Imports System.Data
Imports System.Data.OracleClient
Imports System.Data.SqlClient

<ComVisible(True)> _
<ProgId("JD_NTBATCH_CMNFUNCS.jdh_cmnfuncs")> _
<ClassInterface(ClassInterfaceType.AutoDual)> _
Public Class jdh_cmnfuncs

    'Oracle object for connection added during the Remediation changes by Syntel - 10/06/2015
    Private objOraConn As OracleConnection
    Private objSqlConn As SqlConnection
    Public objDecrypPassword As String

    ' User Defined datatypes
    Private Structure FILETIME
        Dim dwLowDateTime As Integer
        Dim dwHighDateTime As Integer
    End Structure

    Private Structure WIN32_FIND_DATA
        Dim dwFileAttributes As Integer
        Dim ftCreationTime As FILETIME
        Dim ftLastAccessTime As FILETIME
        Dim ftLastWriteTime As FILETIME
        Dim nFileSizeHigh As Integer
        Dim nFileSizeLow As Integer
        Dim dwReserved0 As Integer
        Dim dwReserved1 As Integer
        <VBFixedString(260), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst:=260)> Public cFileName() As Char
        <VBFixedString(14), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst:=14)> Public cAlternate() As Char
    End Structure

    ' Windows APIs
    Private Declare Function InternetOpen Lib "wininet.dll" Alias "InternetOpenA" (ByVal sAgent As String, ByVal lAccessType As Integer, ByVal sProxyName As String, ByVal sProxyBypass As String, ByVal lFlags As Integer) As Integer
    Private Declare Function InternetConnect Lib "wininet.dll" Alias "InternetConnectA" (ByVal hInternetSession As Integer, ByVal sServerName As String, ByVal nServerPort As Short, ByVal sUsername As String, ByVal sPassword As String, ByVal lService As Integer, ByVal lFlags As Integer, ByVal lContext As Integer) As Integer
    Private Declare Function FtpFindFirstFile Lib "wininet.dll" Alias "FtpFindFirstFileA" (ByVal hFtpSession As Integer, ByVal lpszSearchFile As String, ByRef lpFindFileData As WIN32_FIND_DATA, ByVal dwFlags As Integer, ByVal dwContent As Integer) As Integer
    Private Declare Function FtpGetFile Lib "wininet.dll" Alias "FtpGetFileA" (ByVal hFtpSession As Integer, ByVal lpszRemoteFile As String, ByVal lpszNewFile As String, ByVal fFailIfExists As Boolean, ByVal dwFlagsAndAttributes As Integer, ByVal dwFlags As Integer, ByVal dwContext As Integer) As Boolean
    Private Declare Function FtpDeleteFile Lib "wininet.dll" Alias "FtpDeleteFileA" (ByVal hFtpSession As Integer, ByVal lpszFileName As String) As Boolean
    Private Declare Function FtpPutFile Lib "wininet.dll" Alias "FtpPutFileA" (ByVal hFtpSession As Integer, ByVal lpszLocalFile As String, ByVal lpszRemoteFile As String, ByVal dwFlags As Integer, ByVal dwContext As Integer) As Boolean
    Private Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Object, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Private Declare Function InternetCloseHandle Lib "wininet.dll" (ByVal hInet As Integer) As Short

    '###########################################################################
    'Function Name     : EstablishConnection
    'Purpose           : To establish the global database connection
    'Input             : (ByVal)p_strProvider    - Database Provider name
    '                    (ByVal)p_strUserName    - Database User Name
    '                    (ByVal)p_strDBname      - Database Name
    '                    (ByVal)p_strServerName  - Database Server Name
    '                    (ByVal)p_strServerPort  - Database Server Port
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for remediation chagnes.
    '###########################################################################
    Public Function EstablishConnection(ByVal p_strProvider As String, ByVal p_strUsername As String, ByVal p_strPassword As String, ByVal p_strDBname As String, ByVal p_strServerName As String, ByVal p_strSystemXmlPath As String, Optional ByVal p_strServerPort As String = "") As Boolean
        ' Variable to store Database Connection String
        Dim l_strConnection As String
        EstablishConnection = True
        Try
            'Calling the CerGetPassword to decode the Facets-Only-Security Password
            ' If (CerGetPassword(p_strPassword, p_strServerName, p_strServerPort, p_strDBname, p_strUsername, p_strSystemXmlPath)) Then
            objDecrypPassword = p_strPassword
            l_strConnection = "Data Source= " & Left(p_strServerName, 8).ToUpper() & ";User Id = " & p_strUsername & ";" & "Password = """ & p_strPassword & """;"
            ''objOraConn = New OracleConnection(l_strConnection)
            'objOraConn.Open()
            objSqlConn = New SqlConnection(l_strConnection)
            objSqlConn.Open()

            'End If
        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : EstablishConnection - " & Err.Description))
            EstablishConnection = False
        Finally
            objSqlConn.Close()
            'objOraConn.Close()
        End Try
    End Function

    '###########################################################################
    'Function Name     : CerGetPassword
    'Purpose           : To retrieve the Database password from the facets
    '                    only security password
    'Input             :
    '                    (ByRef)p_strPassword - Database password
    '                    p_strServerName      - Database server name
    '                    p_strServerPort      - Database server port
    '                    p_strDatabaseName    - Database name
    '                    p_strUserId          - Database user name
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for remediation chagnes.
    '###########################################################################
    Public Function CerGetPassword(ByRef p_strPassword As String, ByVal p_strServerName As String, ByVal p_strServerPort As String, ByVal p_strDatabaseName As String, ByVal p_strUsername As String, ByVal p_strSystemXmlPath As String) As Object

        ' Local variable Declarations and Assignments
        Dim l_Stm As Object             ' steam object used to retrieve the database password from the facets only password
        Dim l_DataAccessMgr As Object   ' To hold the object return by CreateDataAccess function

        Try

            l_Stm = CreateStream()
            l_DataAccessMgr = CreateDataAccess()
            l_Stm.Clear()

            l_Stm.AddItemString("DATA_DOMAIN", p_strDatabaseName)
            l_Stm.AddItemString("SYSTEM_XML_LOCATION", p_strSystemXmlPath)
            l_Stm.AddItemString("APP_SERVER", p_strServerName & "," & p_strServerPort)
            l_DataAccessMgr.SetCommArea(l_Stm)

            If Err.Number <> 0 Then
                MsgBox("Error getting password @ : SetCommArea" & Err.Description)
            End If

            '----------------------------------------------------------------------
            '  Calling the stored procedure - CERSP_STRING_ENCODE_TEST
            '----------------------------------------------------------------------
            Call l_Stm.Clear()
            Call l_Stm.AddItemString("DOMAIN", "100")
            Call l_Stm.AddItemString("CSARG", p_strPassword)
            Call l_Stm.AddItemString("CSSEED", p_strUsername)
            Call l_DataAccessMgr.ExecuteNoResults("CERSP_STRING_ENCODE_TEST", l_Stm)
            p_strPassword = l_Stm.FindItemString("REC_STRI.ENCODE")
        Catch ex As Exception
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CerGetPassword - " & Err.Description))
            CerGetPassword = False
        Finally
            l_DataAccessMgr = Nothing
            l_Stm = Nothing
        End Try

        CerGetPassword = True

    End Function

    '###########################################################################
    'Function Name     : CreateStream
    'Purpose           : To create the CerDataStream object
    'Input             : None
    'Output            : CerDataStream object
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Exception handling/code clean up
    '###########################################################################
    Private Function CreateStream() As ErSystComDataStr.CerDataStream
        ' Local variable Declarations
        Dim l_Ds As Object ' Local object to hold the type of CerDataStream
        Try

            CreateStream = Nothing
            l_Ds = Nothing
            l_Ds = New ErSystComDataStr.CerDataStream
            CreateStream = l_Ds

        Catch ex As Exception
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CreateStream - " & Err.Description))
            CreateStream = Nothing
        Finally
            l_Ds = Nothing
        End Try
    End Function

    '###########################################################################
    'Function Name     : CreateDataAccess
    'Purpose           : To create the CerComDataAccessMgr object
    'Input             : None
    'Output            : CerComDataAccessMgr object
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Exception handling/code clean up
    '###########################################################################
    Private Function CreateDataAccess() As ErSystComDataAccessMgr.CerComDataAccessMgr
        ' Local variable Declarations
        Dim l_DataAccMgr As Object ' Local object to hold the type of CerComDataAccessMgr
        Try
            CreateDataAccess = Nothing
            l_DataAccMgr = Nothing
            l_DataAccMgr = New ErSystComDataAccessMgr.CerComDataAccessMgr
            CreateDataAccess = l_DataAccMgr
        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CreateDataAccess - " & Err.Description))
            CreateDataAccess = Nothing
        Finally
            l_DataAccMgr = Nothing
        End Try
    End Function

    '###########################################################################
    'Function Name     : WriteTrace
    'Purpose           : To the write the trace message into the trace file and
    '                    into the JT_APPLICATION_LOG table
    'Input             :
    '                    (ByRef)p_connDatabase   - Connection object to enter the
    '                                              log message into the log table
    '                    (ByRef)p_dicBatchInfo - Dictionary object with message,
    '                                  status, process type and transaction type
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Remediation changes
    '###########################################################################
    Public Function WriteTrace(ByRef p_dicBatchInfo As Object) As Boolean

        Dim l_strMessage As String              ' String variable to hold the message
        Dim l_strDateTime As String             ' String that holds both the date and time, for writing logs
        Dim l_strUserId As String               ' String variable to hold the Database user name
        Dim l_intReturnCode As Short            ' Integer Variable to hold the return code
        Dim l_intCheck As Short                 ' Integer to store the return code of stored procedure
        Dim l_strModule As String
        Dim l_strProcess As String
        Dim l_intEndPos As Short
        Dim objOraCmd As OracleCommand          ' Create command object for Oracle;
        Dim objSqlCmd As SqlCommand          ' Create command object for Oracle;
        Dim strRunDate As String
        Dim strBatchName As String
        Dim rtnVAl As Integer
        Dim objRunId As String

        Try
            WriteTrace = True
            ' Retrieving the required parameters from the dictionary object
            l_strMessage = p_dicBatchInfo.Item("MESSAGE")
            l_intReturnCode = CShort(p_dicBatchInfo.Item("RETURN CODE"))
            l_strModule = "BTCH"
            l_intEndPos = InStr(6, p_dicBatchInfo.Item("BatchName"), "_")

            '' Changes made for UH1
            If l_intEndPos > 0 Then
                l_strProcess = Mid(p_dicBatchInfo.Item("BatchName"), 6, l_intEndPos - 6)
            Else
                l_strProcess = Mid(p_dicBatchInfo.Item("BatchName"), 6, 8)
            End If

            ' Retrieving the Database user name from the config.ini file
            l_strUserId = p_dicBatchInfo.Item("DatabaseUserId")

            ' Initializing the date and time
            l_strDateTime = CStr(Today) & " - " & CStr(TimeOfDay)
            strBatchName = p_dicBatchInfo.Item("BatchName")

            ' Creating a command object to execute the stored procedure JP_APPLICATION_LOG_APPLY
            'objOraCmd = New OracleCommand
            objSqlCmd = New SqlCommand

            '   With objOraCmd
            With objSqlCmd

                '' Changes made for UH1 starts
                .CommandText = "FSGSP_APPLICATION_LOG_APPLY"
                .CommandType = CommandType.StoredProcedure
                .Connection = objSqlConn

                .Parameters.Add(New SqlParameter("ReturnCode", SqlDbType.Int)).Direction = ParameterDirection.ReturnValue
                .Parameters.Add(New SqlParameter("pPROCESS_RUN_ID", SqlDbType.Int)).Direction = ParameterDirection.Output
                .Parameters.Add(New SqlParameter("pAPP_MODULE_ID", SqlDbType.VarChar)).Value = l_strModule
                .Parameters.Add(New SqlParameter("pPROCESS_ID", SqlDbType.VarChar)).Value = l_strProcess
                .Parameters.Add(New SqlParameter("pSYSTEM_ERR_NO", SqlDbType.Int)).Value = DBNull.Value
                .Parameters.Add(New SqlParameter("pRETURN_STS", SqlDbType.Int)).Value = l_intReturnCode
                .Parameters.Add(New SqlParameter("pPROCESS_MSG", SqlDbType.VarChar)).Value = l_strMessage
                .Parameters.Add(New SqlParameter("pSTART_TIME", SqlDbType.Timestamp)).Value = System.DateTime.FromOADate(Today.ToOADate + TimeOfDay.ToOADate)
                .Parameters.Add(New SqlParameter("pEND_TIME", SqlDbType.Timestamp)).Value = System.DateTime.FromOADate(Today.ToOADate + TimeOfDay.ToOADate)
                .Parameters.Add(New SqlParameter("pUSUS_ID", SqlDbType.Char)).Value = l_strUserId
                .Parameters.Add(New SqlParameter("pCOUNTER_MSG", SqlDbType.VarChar)).Value = strBatchName

                ''objOraConn.Open()
                objSqlConn.Open()
                'Executing the Stored Procedure JP_APPLICATION_LOG_APPLY
                .ExecuteNonQuery()
                ''objOraConn.Close()
                objSqlConn.Close()
                '  rtnVAl = .Parameters("rtn_val").Value.ToString()
                rtnVAl = .Parameters("ReturnCode").Value.ToString()

                ''Changes made for UH1 ends

            End With

            ' Checking if the stored procedure is executed successfully
            If rtnVAl <> 0 Then
                ' Setting the return code key to the dictionary object
                p_dicBatchInfo.Item("RETURN CODE") = 99
                ' Writing the Error message in the Event log
                EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", l_strDateTime & " - " & l_strProcess & " : Non Critical Error : Error in writing message to the log table JT_APPLICATION_LOG; Error Code : 1")
                WriteTrace = False
            End If

        Catch
            WriteTrace = False
            ' Setting the return code to the dictionary object
            p_dicBatchInfo.Item("RETURN CODE") = 99
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (l_strDateTime & " : " & Err.Description))
            WriteTrace = False
        Finally
            'objOraConn.Close()
            'objOraCmd = Nothing

            objSqlConn.Close()
            objSqlCmd = Nothing
        End Try

    End Function

    '###########################################################################
    'Function Name     : SendMail
    'Purpose           : To send mail and check the status of the mail
    'Input             :
    '                    (ByRef)p_connDatabase   - Connection object to enter the
    '                                              log message into the log table
    '                    (ByRef)p_dicBatchInfo - Dictionary object with message,
    '                                  status, process type and transaction type
    '                    p_strFile              - The file whose content is to be mailed
    '                    p_strReceiver          - The mail ids or receiver
    '                    p_strSubject           - The subject of the mail
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Exception handling/code clean up
    '###########################################################################
    Public Function SendMail(ByRef p_dicBatchInfo As Object, ByVal p_strFile As String, ByVal p_strReceiver As String, ByVal p_strSubject As String) As Boolean
        ' Local variable Declarations and Assignments
        Dim l_wshShell As IWshRuntimeLibrary.WshShell   ' Shell object to send email
        Dim l_strBlat As String                         ' String variable to call the blat exe with all parameters
        Dim l_strBlatPath As String
        Dim l_strMailSender As String                   ' String variable to hold the name of sender
        Dim l_strMailServerName As String               ' String variable to hold the name of the mail server
        Dim l_strMailPortNumber As String               ' String variable to hold the port number of the server
        Dim l_lngReturnCode As Integer                  ' Long variable to hold the return code
        Dim l_strLogFilePath As String                  ' String variable to hold the log file name
        Dim l_strAttachFiles As Object                  ' Array to hold all the log file names
        Dim l_strAttach As String                       ' String variable to hold the log file names
        Dim l_intFileCount As Short                     ' Integer variable to hold the file count
        Dim l_strMailPath As String                     ' String variable to hold the path of the mails
        Dim l_strBody As String                         ' String variable to hold the body of the mail
        Dim l_fso As New Scripting.FileSystemObject     ' File System object to open and create the file
        Dim l_txtStream As Scripting.TextStream
        Dim l_strReceiver As String

        Try

            ' Retrieving the Mail sender from the config.ini
            l_strMailSender = p_dicBatchInfo.Item("Sender")

            ' Retrieving the Mail Server name and port address
            l_strMailServerName = p_dicBatchInfo.Item("Mail_ServerName")
            l_strMailPortNumber = p_dicBatchInfo.Item("Mail_Port")

            ' Retrieving the Blat.exe path
            l_strMailPath = CheckSlash(p_dicBatchInfo.Item("Mail Path"))
            l_strBlatPath = l_strMailPath & "blat.exe"

            ' Retrieving the Path of the Batch Output Log Files
            l_strLogFilePath = CheckSlash(p_dicBatchInfo.Item("BatchOutputDirectory"))

            If InStr(1, p_strFile, ",") > 0 Then
                l_strAttachFiles = Split(p_strFile, ",")
                For l_intFileCount = 0 To UBound(l_strAttachFiles)
                    l_strAttach = l_strAttach & " -attach " & l_strLogFilePath & l_strAttachFiles(l_intFileCount)
                Next
            ElseIf Trim(p_strFile) <> "" Then
                l_strAttach = " -attach " & Chr(34) & l_strLogFilePath & p_strFile & Chr(34)
            End If


            'If p_dicBatchInfo.Item("RETURN CODE") = 0 Then
            '    l_strBody = CStr(l_strMailPath) & "SUCCESS.txt"
            'ElseIf Trim(p_strFile) = "" Then
            '    l_strBody = CStr(l_strMailPath) & "ERROR.txt"
            'Else
            '    l_strBody = CStr(l_strMailPath) & "FAIL.txt"
            'End If

            ''Changes made starts for UH1

            If p_dicBatchInfo.Item("RETURN CODE") = 0 Then
                l_strBody = CStr(l_strMailPath) & "SUCCESS.txt"
            ElseIf p_dicBatchInfo.Item("RETURN CODE") = 3 Then
                l_strBody = CStr(l_strMailPath) & "NOINPUT.txt"
            ElseIf Trim(p_strFile) = "" Then
                l_strBody = CStr(l_strMailPath) & "ERROR.txt"
            Else
                l_strBody = CStr(l_strMailPath) & "FAIL.txt"
            End If

            ''Changes made for UH1 ends


            If l_fso.FileExists(l_strMailPath & "MailingList\" & p_strReceiver) Then
                l_txtStream = l_fso.OpenTextFile(l_strMailPath & "MailingList\" & p_strReceiver)
                l_strReceiver = l_txtStream.ReadAll
                l_txtStream = Nothing
            Else
                l_strReceiver = p_strReceiver
            End If

            l_fso = Nothing

            ' Creating the parameters for blat.exe
            l_strBlat = l_strBlatPath & " " & Chr(34) & l_strBody & Chr(34) & " -t " & l_strReceiver & " -s " & Chr(34) & p_strSubject & Chr(34) & " -i " & l_strMailSender & " -server " & l_strMailServerName & ":" & l_strMailPortNumber & l_strAttach

            ' Creating a Shell object, to run the Blat command
            l_wshShell = New IWshRuntimeLibrary.WshShell

            '----------------------------------------------------------------------
            ' Sending the Blat Mail
            '----------------------------------------------------------------------
            l_lngReturnCode = l_wshShell.Run(l_strBlat, 0, True)

            ' Checking for the success of mail operation
            If l_lngReturnCode <> 0 Then
                ' Setting the return code key in the dictionary object

                p_dicBatchInfo.Item("RETURN CODE") = 13

                ' Assigning the value of MESSAGE key in the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Critical Error : Failed E-Mailing the contents of the log file"
                SendMail = False

                ' Calling the function WriteTrace to log the error message
                Call WriteTrace(p_dicBatchInfo)
            Else
                ' Assigning the value of MESSAGE key in the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Log Message : Successfully E-Mailed the contents of the log file"
            End If

        Catch
            SendMail = False
            p_dicBatchInfo.Item("RETURN CODE") = 99
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : SendMail - " & Err.Description))
        Finally
            l_wshShell = Nothing
        End Try
        SendMail = True
    End Function

    '###########################################################################
    'Function Name     : CheckInputFile
    'Purpose           : To check whether the File exists in a directory
    'Input             : (ByVal) p_strSourceFile - Source Filename
    '                    (ByVal) p_strSourceDir  - Source Directory
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Remediation changes
    '###########################################################################
    Public Function CheckInputFile(ByVal p_strSourceFile As String, ByVal p_strSourceDir As String, ByRef p_dicBatchInfo As Object) As Boolean
        Try
            Dim strFilePath As String = String.Empty
            'Build file path
            If p_strSourceDir.Length > 0 Then
                strFilePath += p_strSourceDir
            End If
            strFilePath += p_strSourceFile

            'Check whether the SourceFile exists
            If Not IO.File.Exists(strFilePath) Then
                CheckInputFile = False
                ' Check for the size of the Source file
            ElseIf (FileLen(p_strSourceFile) <= 0) Then
                CheckInputFile = False
            Else
                CheckInputFile = True
            End If

            ' Calling the function WriteTrace to log the error message
            If CheckInputFile = False Then

                p_dicBatchInfo.Item("MESSAGE") = "Log Message : No Input Files are available for processing"

                p_dicBatchInfo.Item("RETURN CODE") = 3
                Call WriteTrace(p_dicBatchInfo)
            End If
        Catch ex As Exception
            CheckInputFile = False
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CheckInputFile - " & Err.Description))
        End Try

    End Function

    '###########################################################################
    'Function Name     : UpdateDicOverride
    'Purpose           : To Update the Override Dictionary object
    'Input             : (ByRef) p_connDatabase           - Database connection object
    '                            p_strItem                - Item name
    '                    (ByRef) p_dicOverrideInfo        - Override dictionary object
    '                    (ByRef) p_dicBatchInfo           - Dictionary object to enter
    '                                                       log message
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - EstablishConnection for Remediation chagnes
    'Optum(pmadhav) - 10/20/2016 : Modifed to fix Billing 
    'Optum(lpankaj) - 11/01/2016 : Modified for PRB0052084- Tax year calculation
    '###########################################################################
    Public Function UpdateDicOverride(ByRef p_strItem As String, ByRef p_dicOverrideInfo As Object, ByRef p_dicBatchInfo As Object) As Object

        Dim objDtRuslt As DataTable
        Dim l_intpos As Short                                   ' Variable to store the end position of file name
        Dim l_strItem As String                                 ' Variable to store the item name
        Dim l_strProcessName As String                          ' Variable to store the last four byte of Pre-Process Xml
        Dim l_arrParam(1, 1) As String                          ' Array to store the Stored Procedure input parameter
        Dim l_strRundate As String                              ' Variable to store the Rundate obtained as output
        Dim l_wrkFilePath As String                             ' Variable to store the Work File path
        Dim l_wrkFileName As String                             ' Variable to store the Work File Name
        Dim l_fso As Scripting.FileSystemObject                 ' File System object for File operation
        Dim l_flInputFile As Scripting.File                     ' File Object
        Dim l_txtStrInput As Scripting.TextStream               ' Object to Read the Source File
        Dim l_strLastLine As String                             ' Variable to store the last line of the file
        Dim l_strGroupId As String                              ' To store the group ID's
        Dim l_strRundateadd As String                           ' Variable to store the Rundate as 2 days advance
        Const l_conadChar As Short = 3                     ' Constant variable to store the value equivalent to varchar
        Const l_conadParamInput As Short = 1                    ' Constant variable to store the value equivalent to Input paramter for the stored procedure
        UpdateDicOverride = True      'Optum(pmadhav) - 10/20/2016 
        Try

            l_strItem = Trim(p_strItem)

            '' made changes for UH1 starts
            If (l_strItem = "RunDate" Or l_strItem = "BillDate" Or l_strItem = "PayDate" Or l_strItem = "StartDate" Or l_strItem = "PAY_DT" Or l_strItem = "CKPY_PAY_DT" Or l_strItem = "CRME_PAY_THRU_DT" Or l_strItem = "RunThruDate") Then
                l_arrParam(0, 0) = "pAPP_MODULE_ID"
                l_strProcessName = "BTCH"

                'Build the input parameter
                l_arrParam(0, 1) = l_conadChar & "," & l_conadParamInput & "," & 4 & "," & l_strProcessName

                'Execute the Stored procedure
                ''If Not (ExecuteSP(p_dicBatchInfo, "FSG.JP_BTCH_SELECT_RUNDATE", l_arrParam, 1, objDtRuslt)) Then
                If Not (ExecuteSP(p_dicBatchInfo, "FSGSP_BTCH_SELECT_RUNDATE", l_arrParam, 1, objDtRuslt)) Then
                    UpdateDicOverride = False
                    objDtRuslt = Nothing

                    Exit Function
                End If

                If (objDtRuslt.Rows.Count <> 1) Or (IsDBNull(objDtRuslt.Rows(0)("RUN_DATE"))) Then
                    UpdateDicOverride = False

                    ' Assigning the Message item and Return code item of the dictionary objects
                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : Invalid Record set returned from JP_BTCH_SELECT_RUNDATE"
                    p_dicBatchInfo.Item("RETURN CODE") = 1

                    ' Calling the Function WriteTrace to log the Trace message
                    WriteTrace(p_dicBatchInfo)

                Else
                    'Fetch the result from the Resultset
                    If l_strItem = "RunThruDate" Then
                        l_strRundate = objDtRuslt.Rows(0)("RUN_DATE").ToString()
                        'Make the Rundate as 2 days advance
                    Else
                        l_strRundate = objDtRuslt.Rows(0)("RUN_DATE").ToString()
                    End If

                    p_dicOverrideInfo.Item(l_strItem) = Replace(p_dicOverrideInfo.Item(l_strItem), "mm/dd/yyyy", Trim(l_strRundate))

                End If

                objDtRuslt = Nothing

            ElseIf l_strItem = "HIAADate" Then
                l_arrParam(0, 0) = "pBTCH_NM"
                l_strProcessName = Mid(p_dicBatchInfo.Item("BatchName"), 14, InStr(14, p_dicBatchInfo.Item("BatchName"), "_", 1) - 14)
                l_strProcessName = Mid(l_strProcessName, 1, 1) & LCase(Mid(l_strProcessName, 2, Len(l_strProcessName) - 1))

                'Build the input parameter
                l_arrParam(0, 1) = l_conadChar & "," & l_conadParamInput & "," & 4 & "," & UCase(l_strProcessName)

                'Execute the Stored procedure
                '' If Not (ExecuteSP(p_dicBatchInfo, "FSG.JP_BTCH_HIAA_FETCHDT", l_arrParam, 1, objDtRuslt)) Then
                If Not (ExecuteSP(p_dicBatchInfo, "JP_BTCH_HIAA_FETCHDT", l_arrParam, 1, objDtRuslt)) Then

                    UpdateDicOverride = False
                    objDtRuslt = Nothing
                    Exit Function
                End If

                If (objDtRuslt.Rows.Count <> 1) Or (IsDBNull(objDtRuslt.Rows(0)("FILE_DATE"))) Or (IsDBNull(objDtRuslt.Rows(0)("EFF_DATE"))) Then
                    UpdateDicOverride = False
                    ' Assigning the Message item and Return code item of the dictionary objects

                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : Invalid Record set returned from JP_BTCH_HIAA_FETCHDT"
                    p_dicBatchInfo.Item("RETURN CODE") = 1
                    ' Calling the Function WriteTrace to log the Trace message
                    WriteTrace(p_dicBatchInfo)
                Else
                    p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatEffDate") = objDtRuslt.Rows(0)("EFF_DATE").ToString()
                    p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatBodyFile") = Replace(p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatBodyFile"), "ccyymmdd", objDtRuslt.Rows(0)("FILE_DATE").ToString())
                    p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatProcFile") = Replace(p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatProcFile"), "ccyymmdd", objDtRuslt.Rows(0)("FILE_DATE").ToString())
                    p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatZipFile") = Replace(p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatZipFile"), "ccyymmdd", objDtRuslt.Rows(0)("FILE_DATE").ToString())
                    p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatFile") = Replace(p_dicOverrideInfo.Item(Trim(l_strProcessName) & "StatFile"), "ccyymmdd", objDtRuslt.Rows(0)("FILE_DATE").ToString())
                End If

                'objDtRuslt = Nothing

            ElseIf (l_strItem = "econn-InputFile" Or l_strItem = "econn-ResubFile") Then


                ' Fetch the Work file path
                l_wrkFilePath = CheckSlash(p_dicBatchInfo.Item("WorkfilePath"))

                l_fso = New Scripting.FileSystemObject
                ' build the WorkFile name

                l_wrkFileName = Trim(p_dicBatchInfo.Item("Database")) & ".ecmms.inputfiles"
                If (l_fso.FolderExists(l_wrkFilePath) And l_fso.FileExists(l_wrkFilePath & l_wrkFileName)) Then

                    'Open the Workfile for reading
                    l_fso = CreateObject("Scripting.FileSystemObject")
                    l_flInputFile = l_fso.GetFile(l_wrkFilePath & l_wrkFileName)
                    l_txtStrInput = l_flInputFile.OpenAsTextStream(Scripting.IOMode.ForReading)

                    'Loops through file capturing each line in the variable
                    Do While Not (l_txtStrInput.AtEndOfStream)
                        l_strLastLine = l_txtStrInput.ReadLine
                    Loop

                    'Update the Override dictionary object
                    If (l_strItem = "econn-InputFile") Then
                        p_dicBatchInfo.Item("InputDir") = CheckSlash(p_dicBatchInfo.Item("InputDir"))
                        p_dicBatchInfo.Item("OutputDir") = CheckSlash(p_dicBatchInfo.Item("OutputDir"))
                        p_dicOverrideInfo.Item("ResubDir") = p_dicBatchInfo.Item("OutputDir") + "Resub\"
                        p_dicOverrideInfo.Item("InputFile") = Trim(l_strLastLine)
                        p_dicOverrideInfo.Item("ResubFile") = Trim(l_strLastLine) & ".resub"
                    End If

                    l_txtStrInput.Close()
                    l_fso = Nothing
                    l_flInputFile = Nothing
                    l_txtStrInput = Nothing
                Else

                    UpdateDicOverride = False
                    ' Log the error message
                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : File not found -  " & l_wrkFilePath & l_wrkFileName
                    p_dicBatchInfo.Item("RETURN CODE") = 3
                    ' Calling the Function WriteTrace to log the Trace message
                    WriteTrace(p_dicBatchInfo)
                End If
                'Added on 08252009

            ElseIf (l_strItem = "econn-InputFile_UM" Or l_strItem = "econn-ResubFile_UM") Then

                ' Fetch the Work file path

                l_wrkFilePath = CheckSlash(p_dicBatchInfo.Item("WorkfilePath"))

                l_fso = New Scripting.FileSystemObject
                ' build the WorkFile name

                l_wrkFileName = Trim(p_dicBatchInfo.Item("Database")) & ".ecumi.inputfiles"

                If (l_fso.FolderExists(l_wrkFilePath) And l_fso.FileExists(l_wrkFilePath & l_wrkFileName)) Then

                    'Open the Workfile for reading
                    l_fso = CreateObject("Scripting.FileSystemObject")

                    l_flInputFile = l_fso.GetFile(l_wrkFilePath & l_wrkFileName)
                    l_txtStrInput = l_flInputFile.OpenAsTextStream(Scripting.IOMode.ForReading)

                    'Loops through file capturing each line in the variable
                    Do While Not (l_txtStrInput.AtEndOfStream)
                        l_strLastLine = l_txtStrInput.ReadLine
                    Loop

                    'Update the Override dictionary object
                    If (l_strItem = "econn-InputFile_UM") Then
                        p_dicBatchInfo.Item("InputDir") = CheckSlash(p_dicBatchInfo.Item("InputDir"))
                        p_dicBatchInfo.Item("OutputDir") = CheckSlash(p_dicBatchInfo.Item("OutputDir"))
                        p_dicOverrideInfo.Item("InputFile") = p_dicBatchInfo.Item("InputDir") + Trim(l_strLastLine)
                        p_dicOverrideInfo.Item("ResubFile") = p_dicBatchInfo.Item("OutputDir") + "Resub\" + CDbl(Trim(l_strLastLine)) + CDbl(".resub")
                    End If

                    l_txtStrInput.Close()
                    l_fso = Nothing
                    l_flInputFile = Nothing
                    l_txtStrInput = Nothing

                    objDtRuslt = Nothing
                Else

                    UpdateDicOverride = False
                    ' Log the error message

                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : File not found -  " & l_wrkFilePath & l_wrkFileName

                    p_dicBatchInfo.Item("RETURN CODE") = 3
                    ' Calling the Function WriteTrace to log the Trace message
                    Call WriteTrace(p_dicBatchInfo)
                End If

                ''Changes for UH1 ends
                '   objDtRuslt = Nothing
            End If

        Catch
            p_dicBatchInfo.Item("RETURN CODE") = 99
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : UpdateDicOverride - " & Err.Description))

        Finally
            l_fso = Nothing
            l_flInputFile = Nothing
            l_txtStrInput = Nothing
            objDtRuslt = Nothing

        End Try

    End Function


    ''' <summary>
    ''' Function to Truncate the given table
    ''' Syntel - 06/10/2015 : Added the function - fnTruncateOraTable for Remediation purpose
    ''' </summary>
    ''' <param name="strTblName"></param>
    ''' <param name="strOraArgConn"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '   Public Function fnTruncateOraTable(ByRef strTblName As String, ByRef strOraArgConn As String) As Boolean
    Public Function fnTruncateSqlTable(ByRef strTblName As String, ByRef strSqlArgConn As String) As Boolean
        'Dim objOraCmd As OracleCommand           'Oracle Command object for Truncate table
        Dim objSqlCmd As SqlCommand           'Oracle Command object for Truncate table
        Dim inRntVal As Integer
        Dim strSchemaName As String
        Try

            ''objOraCmd = New OracleCommand
            objSqlCmd = New SqlCommand
            With objSqlCmd
                If strSqlArgConn <> Nothing Then
                    '.Connection = New OracleConnection(strOraArgConn)
                    .Connection = New SqlConnection(strSqlArgConn)
                Else
                    '.Connection = objOraConn
                    .Connection = objSqlConn
                End If
                If strTblName.Contains(".") Then
                    strSchemaName = strTblName.Split(".")(0) & "."
                    strTblName = strTblName.Split(".")(1)
                End If
                Dim strCmdTxt = "DECLARE" & vbNewLine
                strCmdTxt += "rc NUMBER;" & vbNewLine
                strCmdTxt += "BEGIN" & vbNewLine
                strCmdTxt += "rc:=" & strSchemaName & "TRUNCATE_TABLE('" & strTblName & "');" & vbNewLine
                strCmdTxt += "DBMS_OUTPUT.PUT_LINE(rc);" & vbNewLine
                strCmdTxt += "END;"

                .CommandText = strCmdTxt
                .CommandType = CommandType.Text
                .Connection.Open()
                inRntVal = .ExecuteNonQuery()
            End With

            If inRntVal = 0 Then
                fnTruncateSqlTable = True
            Else
                fnTruncateSqlTable = False
            End If

        Catch ex As Exception
            fnTruncateSqlTable = False
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", CStr(Today) & " - " & CStr(TimeOfDay) & " : Function : fnTruncateOraTable - " & Err.Description)
        Finally
            '  objOraCmd = Nothing
            objSqlCmd = Nothing
            'objOraConn.Close()
            objSqlConn.Close()
        End Try
    End Function

    '###########################################################################
    'Function Name     : ExecuteSP
    'Purpose           : To execute stored procedures
    'Input             :
    '                    (ByRef)p_connDatabase - Connection object to enter the
    '                                              log message into the log table
    '                    (ByRef)p_dicBatchInfo - Dictionary object with message,
    '                                  status, process type and transaction type
    '                    p_strSPName             - Stored procedure name that is
    '                                              to be executed
    '                    (ByRef)p_arrParameter   - Parmeter array that contains the
    '                                              list of parameter and its details
    '                    p_intRSneeded           - To indicate whether the stored
    '                                              procedure returns a result set or not
    '                    (ByRef)p_rstResult      - Record set to collect the results
    '                                              returned by the stored procedure
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - ExecuteSP for Remediation purpose
    '###########################################################################
    Public Function ExecuteSP(ByRef p_dicBatchInfo As Object, ByVal p_strSPName As String, ByRef p_arrParameter As Object, ByVal p_intRSneeded As Short, ByRef p_rstResult As Object) As Boolean
        Dim objDS As New DataSet()
        'Dim objOraCmd As OracleCommand           'Create new command object
        Dim objSqlCmd As SqlCommand           'Create new command object
        Dim l_intIndex As Integer
        Dim l_arrParamParts As String()
        Dim rtnVal As Integer
        Try
            ExecuteSP = True
            'objOraCmd = New OracleCommand
            objSqlCmd = New SqlCommand

            '  With objOraCmd
            With objSqlCmd
                'Assign it connection object
                '.Connection = objOraConn
                .Connection = objSqlConn

                'Assing name of sp as command text and adding parameters

                .CommandText = p_strSPName
                .CommandType = CommandType.StoredProcedure

                Dim strInput As Object(,) = p_arrParameter
                If (strInput.Length > 1) Then
                    ' Creating the parameter array for the stored procedure
                    For l_intIndex = 0 To (strInput.Length / 2 - 1)
                        Try
                            If (p_arrParameter(l_intIndex, 1) <> Nothing Or p_arrParameter(l_intIndex, 0) <> Nothing) Then
                                l_arrParamParts = Split(p_arrParameter(l_intIndex, 1).ToString(), ",")
                                If (l_arrParamParts(1).ToString() = "1") Then
                                    '.Parameters.Add(fnGetOraPara(p_arrParameter(l_intIndex, 0).ToString(), l_arrParamParts(0))).Value = l_arrParamParts(3)
                                    ''made changes for UH1 Starts
                                    .Parameters.Add(fnGetSqlPara(p_arrParameter(l_intIndex, 0).ToString(), l_arrParamParts(0))).Value = l_arrParamParts(3)
                                    ''made changes for UH1 Ends
                                Else
                                    ' .Parameters.Add(fnGetOraPara(p_arrParameter(l_intIndex, 0).ToString(), l_arrParamParts(0))).Direction = ParameterDirection.Output
                                    ''made changes for UH1 Starts
                                    .Parameters.Add(fnGetSqlPara(p_arrParameter(l_intIndex, 0).ToString(), l_arrParamParts(0))).Direction = ParameterDirection.Output

                                    ''made changes for UH1  Ends
                                End If
                            End If
                            l_arrParamParts = Nothing
                        Catch ex As Exception
                            Exit For
                        End Try
                    Next
                End If
                '   .Parameters.Add(New OracleParameter("pReturn_cd", OracleType.Number)).Direction = ParameterDirection.Output
                '' Changes made for UH1 starts
                .Parameters.Add(New SqlParameter("ReturnCode", SqlDbType.Int)).Direction = ParameterDirection.Output
                '' Changes made for UH1 ends

            End With

            'objOraConn.Open()
            objSqlConn.Open()

            If p_intRSneeded = 0 Then
                'objOraCmd.ExecuteOracleScalar()
                objSqlCmd.ExecuteScalar()
            Else

                'Dim oraDAdap As OracleDataAdapter = New OracleDataAdapter(objOraCmd)
                Dim sqlDAdap As SqlDataAdapter = New SqlDataAdapter(objSqlCmd)
                'Dim oraDtDs As DataSet = New DataSet
                Dim sqlDtDs As DataSet = New DataSet
                'oraDAdap.Fill(oraDtDs)
                sqlDAdap.Fill(sqlDtDs)
                If (sqlDtDs.Tables.Count > 0) Then
                    p_rstResult = sqlDtDs.Tables(0)
                End If

            End If

            If (Convert.ToInt16(objSqlCmd.Parameters.Item("ReturnCode").Value) <> 0) Then

                ' Setting the return code key in the dictionary object
                p_dicBatchInfo.Item("RETURN CODE") = 1

                ' Assigning the value of MESSAGE key in the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Non Critical Error : Failed executing the Stored Procedure " & p_strSPName & "; Error code : 1"

                ExecuteSP = False

                ' Calling the Procedure WriteTrace
                WriteTrace(p_dicBatchInfo)

            End If

        Catch ex As Exception
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", CStr(Today) & " - " & CStr(TimeOfDay) & " : ExecuteSP - " & Err.Description)
            p_dicBatchInfo.Item("RETURN CODE") = 99
            ExecuteSP = False
        Finally
            'objOraConn.Close()
            'objOraCmd = Nothing
            objSqlConn.Close()
            objSqlCmd = Nothing
        End Try
    End Function

    ''' <summary>
    ''' Function to create and Parameters for the Execute SP
    ''' Syntel - 06/10/2015 : Added the function - fnGetSqlPara for Remediation purpose
    ''' </summary>
    ''' <param name="strKeyWrd"></param>
    ''' <param name="strDtType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function fnGetSqlPara(ByRef strKeyWrd As String, ByRef strDtType As Integer) As SqlParameter

        '' Changes for UH1 starts

        Try
            If (strDtType = 22) Then
                'Return New OracleParameter(strKeyWrd, OracleType.VarChar)
                Return New SqlParameter(strKeyWrd, SqlDbType.VarChar)
            ElseIf (strDtType = 5) Then
                '      Return New SqlParameter(strKeyWrd, SqlDbType.Cursor)
            ElseIf (strDtType = 6) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.DateTime)
            ElseIf (strDtType = 3) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Char)
            ElseIf (strDtType = 30) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Decimal)
            ElseIf (strDtType = 29) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Float)
            ElseIf (strDtType = 10) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.NVarChar)
            ElseIf (strDtType = 11) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.NChar)
            ElseIf (strDtType = 27) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Int)
            ElseIf (strDtType = 28) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Int)
            ElseIf (strDtType = 13) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Int)
            ElseIf (strDtType = 18) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.Timestamp)
            ElseIf (strDtType = 22) Then
                Return New SqlParameter(strKeyWrd, SqlDbType.VarChar)
            End If

            '' Changes for UH1 ends
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    '###########################################################################
    'Function Name     : GetLogFileName
    'Purpose           : To generate the Log Filename
    'Input             :
    '                    (ByRef)p_connDatabase   - Connection object to enter the
    '                                              log message into the log table
    '                    (ByRef)p_dicBatchInfo   - Dictionary object with message,
    '                                              status and return type
    '                     p_strBatchName         - Batch name
    '                     p_strProductName       - Product name (SA/FA)
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - GetLogFileName for Remediation purpose
    'CSP SSMO Onshore - 01/24/2017: Modified for PRB0137479 - Commented code which generated _ERR, _LOG and _OUT 
    '###########################################################################
    Public Function GetLogFileName(ByRef p_strProductName As String, ByRef p_strBatchName As String, ByRef p_dicBatchInfo As Object) As Boolean
        Dim l_strBatchName As String                ' Variable to store the Batch Name
        Dim l_strProductName As String              ' Variable to store the Product Name
        Dim l_arrParam(3, 1) As String              ' Array to store the Stored Procedure input parameter
        Dim l_strSyinId As String                   ' Variable to store System Instance ID
        Dim l_strLogFileName As String              ' Variable to store the Log File Name
        Dim l_strLogFileExt As String               ' Variable to store the Log File Extension
        Dim objSqlDt As DataTable
        Try
            Const l_conadVarChar As Short = 200         ' Constant variable to store the value equivalent to varchar
            Const l_conadParamInput As Short = 1        ' Constant variable to store the value equivalent to Input paramter for the stored procedure
            GetLogFileName = True

            l_strBatchName = Trim(p_strBatchName)
            l_strProductName = Trim(p_strProductName)
            l_arrParam(0, 0) = "pPZPZ_ID"
            l_arrParam(0, 1) = "3," & l_conadParamInput & "," & 2 & "," & l_strProductName
            l_arrParam(1, 0) = "pBATCH_NM"
            l_arrParam(1, 1) = "3," & l_conadParamInput & "," & 4 & "," & Mid(l_strBatchName, 1, 4)
            '' Changes made for UH1 starts
            l_arrParam(2, 0) = "pDB_NM"
            l_arrParam(2, 1) = "3," & l_conadParamInput & "," & 255 & "," & p_dicBatchInfo.Item("Database")
            '' Changes made for UH1 ends

            'l_arrParam(2, 0) = "cv_1"
            'l_arrParam(2, 1) = "5,0,0,0"

            'Execute the Stored procedure
            ' If Not (ExecuteSP(p_dicBatchInfo, "FSG.JP_BTCH_SELECT_INST", l_arrParam, 1, objOraDt)) Then
            If Not (ExecuteSP(p_dicBatchInfo, "FSGSP_BTCH_SELECT_INST", l_arrParam, 1, objSqlDt)) Then '' Changes made for UH1 starts
                GetLogFileName = False
                'objOraDt = Nothing
                objSqlDt = Nothing
                Exit Function
            End If

            If (objSqlDt.Rows.Count = 0) Or IsDBNull(objSqlDt.Rows(0)("SYIN_INST")) Then
                ' Assigning the Message item and Return code item of the dictionary objects
                GetLogFileName = False

                p_dicBatchInfo.Item("MESSAGE") = "Log Message : Invalid Record set returned from FSGSP_BTCH_SELECT_INST"

                p_dicBatchInfo.Item("RETURN CODE") = 1
                ' Calling the Function WriteTrace to log the Trace message
                WriteTrace(p_dicBatchInfo)
            Else
                'Fetch the result from the Resultset
                l_strSyinId = objSqlDt.Rows(0)("SYIN_INST")


                Select Case p_dicBatchInfo.Item("OutputType")
                    Case "X"
                        l_strLogFileExt = ".xml"
                    Case "T"
                        l_strLogFileExt = ".txt"
                End Select

                'MA-11/08/2015 : Remediation chagnes started as part of Facets upgrade.
                Dim strJobFileName As String = l_strBatchName & "_" & l_strSyinId & "_JOB" & l_strLogFileExt

                ''Changes for UH1 starts
                Dim strLogFileName As String = l_strBatchName & "_" & l_strSyinId & "_LOG" & l_strLogFileExt
                Dim strErrFileName As String = l_strBatchName & "_" & l_strSyinId & "_ERR" & l_strLogFileExt
                Dim strOutFileName As String = l_strBatchName & "_" & l_strSyinId & "_OUT" & l_strLogFileExt

                If p_dicBatchInfo.Exists("LogFileName") Then
                    p_dicBatchInfo.Item("LogFileName") = p_dicBatchInfo.Item("LogFileName") & "," & strErrFileName
                Else
                    p_dicBatchInfo.Add("LogFileName", strErrFileName)

                End If

                If p_dicBatchInfo.Exists("LogFileName") Then
                    p_dicBatchInfo.Item("LogFileName") = p_dicBatchInfo.Item("LogFileName") & "," & strLogFileName
                Else
                    p_dicBatchInfo.Add("LogFileName", strLogFileName)

                End If

                If p_dicBatchInfo.Exists("LogFileName") Then
                    p_dicBatchInfo.Item("LogFileName") = p_dicBatchInfo.Item("LogFileName") & "," & strOutFileName
                Else
                    p_dicBatchInfo.Add("LogFileName", strOutFileName)

                End If

                p_dicBatchInfo.Add("SYINID", l_strSyinId)

                ''Changes for UH1 starts ends

            End If
            objSqlDt = Nothing

        Catch
            GetLogFileName = False
            p_dicBatchInfo.Item("RETURN CODE") = 99
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : GetLogFileName - " & Err.Description))
        Finally
            objSqlDt = Nothing
        End Try
        GetLogFileName = True
    End Function

    '###########################################################################
    'Function Name     : FileRename
    'Purpose           : To Rename a file
    'Input             :
    '                    p_strSourceFile  - Source Filename
    '                    p_strSourceDir   - Source File Path
    '                    p_strDestFile    - New filename
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - FileRename for Exception handling and code clean up
    '###########################################################################
    Public Function FileRename(ByRef p_strSourceFile As String, ByRef p_strSourceDir As String, ByRef p_strDestFile As String, ByRef p_dicBatchInfo As Object) As Boolean

        Dim l_fsoRename As Scripting.FileSystemObject       ' FileSystem Object to fetch the File
        Dim l_file As Scripting.File                        ' File Object to get the file which to be renamed
        Dim l_strSourceFile As String                       ' Variable to store the Source Filename
        Dim l_strDestFile As String                         ' Variable to store the Destination Filename
        Try
            l_fsoRename = New Scripting.FileSystemObject
            FileRename = True

            CheckSlash(p_strSourceDir)

            ' Building Source Filename
            If (Len(Trim(p_strSourceDir)) <> 0 And InStr(1, Trim(p_strSourceFile), Trim(p_strSourceDir)) = 0) Then
                l_strSourceFile = Trim(p_strSourceDir) & Trim(p_strSourceFile)
            Else
                l_strSourceFile = Trim(p_strSourceFile)
            End If

            If InStr(1, p_strDestFile, "\") > 0 Then
                l_strDestFile = Mid(p_strDestFile, InStrRev(p_strDestFile, "\") + 1)
            Else
                l_strDestFile = p_strDestFile
            End If

            'Check whether the SourceFile exists
            If Not (l_fsoRename.FileExists(l_strSourceFile)) Then
                FileRename = False

                p_dicBatchInfo.Item("MESSAGE") = "Log Message : The file " & Mid(l_strSourceFile, InStrRev(l_strSourceFile, "\") + 1) & " not available for renaming"

                p_dicBatchInfo.Item("RETURN CODE") = 10
                WriteTrace(p_dicBatchInfo)
            Else
                ' Renaming the File
                l_file = l_fsoRename.GetFile(l_strSourceFile)
                l_file.Name = Trim(l_strDestFile)
            End If

            l_fsoRename = Nothing
            l_file = Nothing
            Exit Function

        Catch
            FileRename = False
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : File Rename - " & Err.Description))
        Finally
            l_fsoRename = Nothing
            l_file = Nothing
        End Try
        FileRename = True
    End Function

    '###########################################################################
    'Function Name     : FileCopy
    'Purpose           : To Copy a file
    'Input             :
    '                    p_strSourceFile  - Source Filename
    '                    p_strSourceDir   - Source File Path
    '                    p_strDestDir     - Destination Directory
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - FileCopy_Renamed for Exception handling and code clean up
    '###########################################################################
    Public Function FileCopy_Renamed(ByRef p_strSourceFile As String, ByRef p_strSourceDir As String, ByRef p_strDestDir As String, ByRef p_dicBatchInfo As Object) As Object

        'Dim l_fsoFileCopy As Scripting.FileSystemObject             ' FileSystem Object to fetch the File
        Dim l_strSourceFile As String                               ' Variable to store the Source Filename
        Dim l_strDestFile As String                                 ' Variable to store the Destination Filename
        'Dim l_intpos As Short
        Try

            'l_fsoFileCopy = New Scripting.FileSystemObject
            FileCopy_Renamed = True

            CheckSlash(p_strSourceDir)
            CheckSlash(p_strDestDir)

            l_strSourceFile = p_strSourceDir & p_strSourceFile
            l_strDestFile = p_strDestDir & p_strSourceFile

            If IO.File.Exists(l_strSourceFile) And IO.Directory.Exists(p_strDestDir) Then

                IO.File.Copy(l_strSourceFile, l_strDestFile)

                '' Building Source Filename
                'If (Len(Trim(p_strSourceDir)) <> 0 And InStr(1, Trim(p_strSourceFile), Trim(p_strSourceDir)) = 0) Then
                '    l_strSourceFile = Trim(p_strSourceDir) & Trim(p_strSourceFile)
                'Else
                '    l_strSourceFile = Trim(p_strSourceFile)
                'End If

                'Check whether the SourceFile exists and the Destinatiion folder exists
                'If (IO.File.Exists(l_strSourceFile)) And (IO.File.Exists(p_strDestDir)) Then
                'Call CheckSlash(p_strDestDir)

                'l_intpos = InStrRev(l_strSourceFile, "\")

                'If (l_intpos > 0) Then
                '    l_strDestFile = Trim(p_strDestDir) & Mid(l_strSourceFile, l_intpos + 1)
                'Else
                '    l_strDestFile = Trim(p_strDestDir) & l_strSourceFile
                'End If

                'l_fsoFileCopy.CopyFile(l_strSourceFile, l_strDestFile)
            Else
                FileCopy_Renamed = False

                p_dicBatchInfo.Item("MESSAGE") = "Log Message : The file " & Mid(l_strSourceFile, InStrRev(l_strSourceFile, "\") + 1) & " not available for copying"

                p_dicBatchInfo.Item("RETURN CODE") = 10
                WriteTrace(p_dicBatchInfo)
            End If

        Catch ex As Exception
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : FileCopy - " & Err.Description))
            FileCopy_Renamed = False
        Finally
            'l_fsoFileCopy = Nothing
        End Try
        FileCopy_Renamed = True

    End Function

    '###########################################################################
    'Function Name     : FileMove
    'Purpose           : To Move a file
    'Input             :
    '                    p_strSourceFile  - Source Filename
    '                    p_strSourceDir   - Source File Path
    '                    p_strDestFile    - New filename
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - FileMove for Exception handling and code clean up
    '###########################################################################
    Public Function FileMove(ByRef p_strSourceFile As String, ByRef p_strSourceDir As String, ByRef p_strDestDir As String, ByRef p_dicBatchInfo As Object) As Boolean

        Dim l_fsoFileMove As Scripting.FileSystemObject             ' FileSystem Object to fetch the File
        Dim l_strSourceFile As String                               ' Variable to store the Source Filename
        Dim l_strDestDir As String                                  ' Variable to store the Destination Directory
        Dim l_intpos As Short                                       ' Variable to store the position of "\" in Filename
        Try
            l_fsoFileMove = New Scripting.FileSystemObject
            FileMove = True
            l_strDestDir = CheckSlash(p_strDestDir)
            Call CheckSlash(p_strSourceDir)

            ' Building Source Filename
            If (Len(Trim(p_strSourceDir)) <> 0 And InStr(1, Trim(p_strSourceFile), Trim(p_strSourceDir)) = 0) Then
                'l_strSourceFile = Trim(p_strSourceDir) + "\" + Trim(p_strSourceFile)
                l_strSourceFile = Trim(p_strSourceDir) & Trim(p_strSourceFile)
            Else
                l_strSourceFile = Trim(p_strSourceFile)
            End If

            'Check whether the SourceFile exists and Destination Directory exists
            If (l_fsoFileMove.FileExists(l_strSourceFile)) And (l_fsoFileMove.FolderExists(l_strDestDir)) Then

                l_intpos = InStrRev(l_strSourceFile, "\")
                'Build Destination Filename
                If (l_intpos > 0) Then
                    l_strDestDir = l_strDestDir & Mid(l_strSourceFile, l_intpos + 1)
                Else
                    l_strDestDir = l_strDestDir & l_strSourceFile
                End If

                If l_fsoFileMove.FileExists(l_strDestDir) Then
                    l_fsoFileMove.DeleteFile(l_strDestDir)
                End If
                l_fsoFileMove.MoveFile(l_strSourceFile, l_strDestDir)
            Else
                FileMove = False

                p_dicBatchInfo.Item("MESSAGE") = "Log Message : The file " & Mid(l_strSourceFile, InStrRev(l_strSourceFile, "\") + 1) & " not available for moving"

                p_dicBatchInfo.Item("RETURN CODE") = 10
                Call WriteTrace(p_dicBatchInfo)
            End If

        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : FileMove - " & Err.Description))
            FileMove = False
        Finally
            l_fsoFileMove = Nothing
        End Try

        FileMove = True

    End Function

    '###########################################################################
    'Function Name     : FileDelete
    'Purpose           : To delete a file
    'Input             :
    '                    p_strSourceFile  - Source Filename
    '                    p_strSourceDir   - Source File Path
    '                    p_intDaysOld     - Days Old
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - FileDelete for Exception handling and code clean up
    '###########################################################################
    Public Function FileDelete(ByRef p_strSourceFile As String, ByRef p_blnMultipleFiles As String, Optional ByRef p_strSourceDir As String = "", Optional ByRef p_intDaysold As Short = 0) As Boolean

        Dim l_fsoFileDelete As Scripting.FileSystemObject       ' FileSystem Object to fetch the File
        Dim l_strSourceFile As String                           ' Variable to store the Source Filename
        Dim l_strDestFile As String                             ' Variable to store the Destination Filename
        Dim l_dtLastMod As Date                                 ' Variable to store the Last Modified Date
        Dim l_doubDtDiff As Double                              ' Variable to store the Date difference
        Dim l_fdInputFolder As Scripting.Folder
        Dim l_flInputFile As Scripting.File
        Try
            l_fsoFileDelete = New Scripting.FileSystemObject
            CheckSlash(p_strSourceDir)

            ' Building Source Filename
            If (Len(Trim(p_strSourceDir)) <> 0 And InStr(1, Trim(p_strSourceFile), Trim(p_strSourceDir)) = 0) Then
                l_strSourceFile = Trim(p_strSourceDir) & Trim(p_strSourceFile)
            Else
                l_strSourceFile = Trim(p_strSourceFile)
            End If

            If p_blnMultipleFiles = "N" Then
                'Check whether the SourceFile exists and the Destinatiion folder exists
                If l_fsoFileDelete.FileExists(l_strSourceFile) Then
                    If DateDiff(Microsoft.VisualBasic.DateInterval.Day, l_fsoFileDelete.GetFile(l_strSourceFile).DateLastModified, Today) >= p_intDaysold Then
                        l_fsoFileDelete.DeleteFile(l_strSourceFile)
                    End If

                End If
            Else
                l_fdInputFolder = l_fsoFileDelete.GetFolder(p_strSourceDir)
                For Each l_flInputFile In l_fdInputFolder.Files
                    If l_flInputFile.Name Like p_strSourceFile Then
                        l_strSourceFile = l_flInputFile.Path
                        If DateDiff(Microsoft.VisualBasic.DateInterval.Day, l_fsoFileDelete.GetFile(l_strSourceFile).DateLastModified, Today) >= p_intDaysold Then
                            l_fsoFileDelete.DeleteFile(l_strSourceFile)
                        End If
                    End If
                Next l_flInputFile
            End If

        Catch

            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : FileDelete - " & Err.Description))
            FileDelete = False
        Finally
            l_fsoFileDelete = Nothing
        End Try

        FileDelete = True

    End Function

    '###########################################################################
    'Function Name     : BcpInData
    'Purpose           : To Bcp data from a flat file into a table
    'Input             :
    '                    p_dicBatchInfo   - Batch Dictionary Object
    '                    p_strInputFile    - Input Data File
    '                    p_strInputTable   - Input Table Name
    '                    p_blnCleanupTable - Indicator for truncating the table
    '                                        before loading the data file
    '                    p_strInputFile    - Format File
    '                    p_strInputSystem  - Facets/HIPAA
    '                    p_connDatabase    - Database Connection Object
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - BcpInData for Remediation purpose
    '###########################################################################
    Public Function BcpInData(ByRef p_dicBatchInfo As Object, ByRef p_strInputFile As String, ByRef p_strInputTable As String, ByRef p_blnCleanupTable As Boolean, ByRef p_strInputSystem As String, ByRef p_strFormatFile As String, ByRef strLogFilePath As String) As Boolean

        Dim l_wshShell As IWshRuntimeLibrary.WshShell ' Shell object to execute the Bcp
        Dim l_strBcpString As String
        Dim l_strDBName As String
        Dim l_strServerName As String
        Dim l_strPassword As String
        Dim l_strUsername As String
        Dim l_intReturnCode As Short
        Dim l_strConnection As String
        Dim l_strServerPort As String
        Dim l_strProvider As String
        Dim l_strSystemXmlPath As String

        Try
            l_strSystemXmlPath = p_dicBatchInfo.Item("SystemXmlPath")

            If UCase(p_strInputSystem) = "FACETS" Then
                l_strPassword = objDecrypPassword
                l_strServerName = p_dicBatchInfo.Item("Database")
                l_strUsername = p_dicBatchInfo.Item("DatabaseUserId")

            ElseIf UCase(p_strInputSystem) = "HIPAA" Then

                l_strServerName = p_dicBatchInfo.Item("HI_DatabaseServer")
                l_strUsername = p_dicBatchInfo.Item("HI_DatabaseUserId")
                l_strPassword = p_dicBatchInfo.Item("HI_DatabasePassword")
                l_strServerPort = p_dicBatchInfo.Item("HI_Port")
                l_strDBName = p_dicBatchInfo.Item("HI_SchemaName")

                CerGetPassword(l_strPassword, l_strServerName, l_strServerPort, l_strDBName, l_strUsername, l_strSystemXmlPath)
                '  l_strConnection = "Provider=" & l_strProvider & ";" & "User id = " & l_strUsername & ";" & "Password = " & l_strPassword & ";" & "Server name = " & l_strServerName & ";" & "Server port address = " & l_strServerPort
                '' made Changes for UH1 starts
                l_strConnection = "Provider=" & l_strProvider & ";" & "User id = " & l_strUsername & ";" & "Password = " & l_strPassword & ";" & "Server name = " & l_strServerName & ";" & "Server port address = " & l_strServerPort & ";" & "Initial Catalog = " & l_strDBName
                '' made Changes for UH1 ends
            End If

            If p_blnCleanupTable Then
                'If fnTruncateOraTable(p_strInputTable, l_strConnection) Then
                If fnTruncateSqlTable(p_strInputTable, l_strConnection) Then
                    EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : BcpInData - " & "Unable to clear the table - " & p_strInputTable))
                    BcpInData = False
                    Exit Function
                End If
            End If

            'Build Log file path;
            Dim strlogFullPath As String = strLogFilePath & "\"
            Dim strDir() As String = p_strFormatFile.Split("\")
            If (strDir.Length > 1) Then
                Dim strFileName As String = strDir(strDir.Length - 1).Split(".")(0).ToString()
                strlogFullPath += strFileName & ".log"
            End If

            l_strBcpString = "sqlldr " & l_strUsername & "/" & l_strPassword & "@" & l_strServerName & " CONTROL=""" & p_strFormatFile & """ DATA=""" & p_strInputFile & """ BAD=""" & p_strInputFile & ".bad"" LOG=""" & strLogFilePath & """ DIRECT=TRUE"

            ' Creating a Shell object, to run the Bcp command
            l_wshShell = New IWshRuntimeLibrary.WshShell

            l_intReturnCode = l_wshShell.Run(l_strBcpString, 0, True)

            If l_intReturnCode > 0 Then

                BcpInData = False
                ' Assigning the Message item and Return code item of the dictionary objects
                p_dicBatchInfo.Item("MESSAGE") = "Log Message : Bcp in Data Failed for the table " & p_strInputTable
                p_dicBatchInfo.Item("RETURN CODE") = 17
                ' Calling the Function WriteTrace to log the Trace message
                If Not WriteTrace(p_dicBatchInfo) Then
                    l_wshShell = Nothing
                    Exit Function
                End If
            End If

        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : BcpInData - " & Err.Description))
            BcpInData = False
        Finally
            l_wshShell = Nothing
        End Try
        BcpInData = True
    End Function

    '###########################################################################
    'Function Name     : BcpOutData
    'Purpose           : To Bcp data into a flat file from a table
    'Input             :
    '                    p_dicBatchInfo   - Batch Dictionary Object
    '                    p_strOutputFile    - Input Data File
    '                    p_strOutputTable   - Input Table Name
    '                    p_strOutputSystem  - Facets/HIPAA
    '                    p_connDatabase    - Database Connection Object
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - BcpOutData for Remediation purpose
    '###########################################################################
    Public Function BcpOutData(ByRef p_dicBatchInfo As Object, ByRef p_strOutputFile As String, ByRef p_strOutputTable As String, ByRef p_strOutputSystem As String, ByRef p_strFormatFile As String) As Boolean

        Dim l_wshShell As IWshRuntimeLibrary.WshShell ' Shell object to execute the Bcp
        Dim l_strBcpString As String
        Dim l_strDBName As String
        Dim l_strServerName As String
        Dim l_strPassword As String
        Dim l_strUsername As String
        Dim l_intReturnCode As Short
        Dim l_strConnection As String
        Dim l_strServerPort As String
        Dim l_strProvider As String
        Dim l_strSystemXmlPath As String

        Try

            l_strSystemXmlPath = p_dicBatchInfo.Item("SystemXmlPath")

            ''Changes for UH1 starts
            If UCase(p_strOutputSystem) = "FACETS" Then
                l_strDBName = p_dicBatchInfo.Item("Database")
                l_strServerName = p_dicBatchInfo.Item("DatabaseServer")
                l_strPassword = p_dicBatchInfo.Item("DatabasePassword")
                l_strUsername = p_dicBatchInfo.Item("DatabaseUserId")


                ' Calling the CerGetPassword to decode the Facets-Only-Security Password
                'Call CerGetPassword(l_strPassword, l_strServerName, l_strServerPort, l_strDBName, l_strUsername)
                Call CerGetPassword(l_strPassword, l_strServerName, l_strServerPort, l_strDBName, l_strUsername, l_strSystemXmlPath)

            ElseIf UCase(p_strOutputSystem) = "HIPAA" Then
                l_strProvider = p_dicBatchInfo.Item("HI_Provider")
                l_strDBName = p_dicBatchInfo.Item("HI_DatabaseName")
                l_strServerName = p_dicBatchInfo.Item("HI_DatabaseServer")
                l_strPassword = p_dicBatchInfo.Item("HI_DatabasePassword")
                l_strUsername = p_dicBatchInfo.Item("HI_DatabaseUserId")
                l_strServerPort = p_dicBatchInfo.Item("HI_Port")

                ''Changes for UH1 ends

                CerGetPassword(l_strPassword, l_strServerName, l_strServerPort, l_strDBName, l_strUsername, l_strSystemXmlPath)

            End If

            l_strBcpString = "type """ & p_strFormatFile & """ | sqlplus -S " & l_strUsername & "/" & l_strPassword & "@" & l_strServerName & " > """ & p_strOutputFile & """"

            ' Creating a Shell object, to run the Bcp command
            l_wshShell = New IWshRuntimeLibrary.WshShell
            l_intReturnCode = l_wshShell.Run(l_strBcpString, 0, True)

            If l_intReturnCode > 0 Then
                BcpOutData = False

                ' Assigning the Message item and Return code item of the dictionary objects
                p_dicBatchInfo.Item("MESSAGE") = "Log Message : Bcp out Data Failed for the table " & p_strOutputTable
                p_dicBatchInfo.Item("RETURN CODE") = 18

                ' Calling the Function WriteTrace to log the Trace message
                If Not WriteTrace(p_dicBatchInfo) Then
                    l_wshShell = Nothing
                    Exit Function
                End If
            End If

        Catch
            'Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : BcpOutData - " & Err.Description))
            BcpOutData = False
        Finally
            l_wshShell = Nothing
        End Try
        BcpOutData = True
    End Function

    '###########################################################################
    'Function Name     : FTPFile
    'Purpose           : To perform the FTP copy operation
    'Input             :
    '                    (ByRef)p_connDatabase    - Connection object to enter the
    '                                               log message into the log table
    '                    (ByRef)p_dicBatchInfo    - Batch Dictionary object
    '                     p_strOperation          - The type of operation to be
    '                                               performed ('PUT'/'GET'/'DELETE')
    '                     p_strFTPServer          - The server (WDRIVE or UNIXBOX)
    '                     p_strSourceFile         - The source file name (File to
    '                                               be 'PUT'/'GET'/'DEL')
    '                     (Optional)p_strDestFile - The destination file name
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - FTPFile for Remediation purpose
    'Optum  - 10/20/2016 : Modified to fix the code Defect with Billing Batch
    '###########################################################################
    Public Function FTPFile(ByRef p_dicBatchInfo As Object, ByVal p_strOperation As String, ByVal p_strFTPServer As String, ByVal p_strSourceFile As String, Optional ByVal p_strDestFile As Object = Nothing) As Boolean
        FTPFile = True                                   'Optum  - 10/20/2016
        ' Local variable Declarations
        Dim l_strFTPServerName As String                    ' String variable to hold the FTP Server name
        Dim l_strFTPUName As String                         ' String variable to hold the FTP User name
        Dim l_strFTPPwd As String                           ' String variable to hold the FTP Password
        Dim l_lngInet As Integer                            ' Long variable to check whether connection can be established
        Dim l_lngINetConn As Integer                        ' Long variable to check whether connection has been established successfully
        Dim l_lngFileExist As Integer                       ' Long variable to check whether the file is present or not
        Dim l_blnReturnValue As Boolean                     ' Boolean variable to check the success of FTP put operation
        Dim lpFindFileData As WIN32_FIND_DATA               ' User defined datatype to find the existence of file in the FTP server
        Dim l_fso As FileSystemObject  ''Changes for UH1 


        Try
            'MsgBox(p_strOperation + "/" + p_strFTPServer + "/" + p_strSourceFile)   'PM_DEBUG
            ''If Not (p_strOperation = "GET" And p_strFTPServer = "UNIXBOX") Then 
            If Not ((p_strOperation = "GET" And p_strFTPServer = "UNIXBOX") Or (p_strOperation = "GET" And p_strFTPServer = "NASDRIVE") Or (p_strOperation = "DELETE" And p_strFTPServer = "NASDRIVE")) Then ''Changes for UH1
                If Not CheckInputFile(p_strSourceFile, "", p_dicBatchInfo) Then
                    Exit Function
                End If
            End If

            If (p_strFTPServer = "UNIXBOX") Then

                ' Retrieving the UNIX FTP Server name, User name and password from the config.ini file
                l_strFTPServerName = p_dicBatchInfo.Item("UN_ServerName")
                l_strFTPUName = p_dicBatchInfo.Item("UN_UserId")
                l_strFTPPwd = p_dicBatchInfo.Item("UN_Password")

            ElseIf (p_strFTPServer = "WDRIVE") Then

                ' Retrieving the WDRIVE FTP Server name, User name and password from the config.ini file
                l_strFTPServerName = p_dicBatchInfo.Item("WD_ServerName")
                l_strFTPUName = p_dicBatchInfo.Item("WD_UserId")
                l_strFTPPwd = p_dicBatchInfo.Item("WD_Password")
                ''Changes for UH1 starts
            ElseIf (p_strFTPServer = "NASDRIVE") Then
                ' Retrieving the NASDRIVE PATH from the config.ini file
                l_strFTPServerName = p_dicBatchInfo.Item("NAS_Path")
            End If
            ''Changes for UH1 ends

            ''Changes for UH1 starts
            If (p_strFTPServer = "NASDRIVE" And p_strOperation = "GET") Then
                l_fso = New FileSystemObject

                l_fso.GetFile(l_strFTPServerName + p_strSourceFile).Copy(p_strDestFile, True)
                l_blnReturnValue = True
            ElseIf (p_strFTPServer = "NASDRIVE" And p_strOperation = "DELETE") Then
                l_fso = New FileSystemObject

                l_fso.GetFile(l_strFTPServerName + p_strSourceFile).Delete()
                l_blnReturnValue = True
            Else
                ' Checking whether the FTP Connection can be established
                l_lngInet = InternetOpen("MyFTP", 1, "", "", 0)

            End If
            ''Changes for UH1 starts ends

            ' Checking whether the FTP Connection can be established
            '                l_lngInet = InternetOpen("MyFTP", 1, "", "", 0)

            If l_lngInet = 0 Then
                FTPFile = False
                ' Setting the return code key to the dictionary object

                p_dicBatchInfo.Item("RETURN CODE") = 99
                ' Assigning the value of MESSAGE key to the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Non Critical Error : FTP Connection cannot be established"
                ' Calling the function WriteTrace to enter the trace message
                WriteTrace(p_dicBatchInfo)

                Exit Function
            End If

            ' Establishing the FTP Connection
            l_lngINetConn = InternetConnect(l_lngInet, l_strFTPServerName, 0, l_strFTPUName, l_strFTPPwd, 1, 0, 0)

            ' Checking for the success of the FTP connection
            If l_lngINetConn = 0 Then
                FTPFile = False
                ' Setting the return code key to the dictionary object

                p_dicBatchInfo.Item("RETURN CODE") = 99
                ' Assigning the value of MESSAGE key in the dictionary object

                p_dicBatchInfo.Item("MESSAGE") = "Non Critical Error : Failed Establishing Connection to the FTP server"
                ' Calling the function WriteTrace to enter the trace message
                Call WriteTrace(p_dicBatchInfo)

                Exit Function
            End If

            ' For GET and PUT operation, check if the optional parameter is present
            If (p_strOperation = "PUT" Or p_strOperation = "GET") And IsNothing(p_strDestFile) Then
                ' Extract the name of the source file and assign it to destination
                p_strDestFile = Split(p_strSourceFile, "\")(UBound(Split(p_strSourceFile, "\")))

            End If

            ' Checking the type of the operation to be performed
            If p_strOperation = "PUT" Then
                ' Copying the local file to the FTP server
                l_blnReturnValue = FtpPutFile(l_lngINetConn, p_strSourceFile, p_strDestFile, 1, 0)

            Else
                ' Checking if the file exists in the FTP server
                l_lngFileExist = FtpFindFirstFile(l_lngINetConn, p_strSourceFile, lpFindFileData, 0, 0)

                ' If the file is not present, it returns 0
                If l_lngFileExist <> 0 Then
                    If p_strOperation = "GET" Then
                        ' Copying the file from the FTP server to the local machine
                        l_blnReturnValue = FtpGetFile(l_lngINetConn, p_strSourceFile, p_strDestFile, 0, 0, 1, 0)
                    ElseIf p_strOperation = "DELETE" Then
                        ' Deleting the file from the FTP server
                        l_blnReturnValue = FtpDeleteFile(l_lngINetConn, p_strSourceFile)
                    End If
                    ' If the file is not present, log a message indicating that the presence of the file was checked
                Else
                    FTPFile = False
                    ' Assigning the value of MESSAGE key in the dictionary object
                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : Checked for the presence of the File " & p_strSourceFile & " in the FTP server"
                    ' Calling the function WriteTrace to indicate that the presence of corrected file was checked
                    WriteTrace(p_dicBatchInfo)
                    Exit Function
                End If
            End If

            ' Checking for the success of the FTP operation
            If l_blnReturnValue = False Then
                FTPFile = False
                ' Setting the return code key to the dictionary object
                p_dicBatchInfo.Item("RETURN CODE") = 12
                ' Assigning the value of MESSAGE key in the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Non Critical Error : FTP " & p_strOperation & " operation failed for file " & p_strSourceFile
                ' Calling the function WriteTrace to enter the trace message
                WriteTrace(p_dicBatchInfo)
                Exit Function
            Else
                ' Assigning the value of MESSAGE key in the dictionary object
                p_dicBatchInfo.Item("MESSAGE") = "Log Message : FTP " & p_strOperation & " operation success for file " & p_strSourceFile
            End If

            ' Closing the FTP connection
            InternetCloseHandle(l_lngINetConn)
            InternetCloseHandle(l_lngInet)

        Catch
            ' Writing the Return Code
            p_dicBatchInfo.Item("RETURN CODE") = 99
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : FTPFile - " & Err.Description))
            FTPFile = False
        End Try
        FTPFile = True
    End Function

    '###########################################################################
    'Function Name     : MergeFiles
    'Purpose           : To perform merge the content of source files into a
    '                    Destination File
    'Input             : p_strSourceFile          - Starting Characters of Source
    '                                               file name
    '                    p_strSourceDir           - Source files Directory
    '                    p_strDestinationFile     - The Destination File Name
    '                    p_strDestinationDir      - Path for the Destination File
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - MergeFiles for code clean up and exception handling
    '###########################################################################
    Public Function MergeFiles(ByRef p_strSourceFile As String, ByRef p_strSourceDir As String, ByRef p_strDestinationFile As String, ByRef p_strDestinationDir As String, Optional ByVal blnDelExist As Boolean = True) As Boolean

        Dim l_fso As Scripting.FileSystemObject                 ' File System object to open and create the file
        Dim l_txtStrInput As Scripting.TextStream               ' Object to Read the Source File
        Dim l_txtStrOutput As Scripting.TextStream              ' Object to Write into the Destination file
        Dim l_fdInputFolder As Scripting.Folder
        Dim l_flInputFile As Scripting.File
        Dim l_ReadContent As String                             ' Variable to store the content of the source file

        Dim l_strSourceFile As String                           ' Variable to store the Source Filename
        Dim l_strSourceDir As String                            ' Variable to store the Source Directory
        Dim l_strDestinationFile As String                      ' Variable to store the Destination Filename
        Dim l_strDestinationDir As String                       ' Variable to store the Destination Directory

        Try

            l_strSourceDir = CheckSlash(p_strSourceDir)
            l_strDestinationDir = CheckSlash(p_strDestinationDir)

            ' Building Source Filename
            If (Len(l_strSourceDir) <> 0 And InStr(1, Trim(p_strSourceFile), l_strSourceDir) = 0) Then
                l_strSourceFile = Trim(p_strSourceFile)
            Else
                l_strSourceDir = Mid(p_strSourceFile, 1, InStrRev(p_strSourceFile, "\") - 1)
                l_strSourceFile = Mid(Trim(p_strSourceFile), InStrRev(p_strSourceFile, "\") + 1)
            End If

            ' Building Destination Filename
            If (Len(l_strDestinationDir) <> 0 And InStr(1, Trim(p_strDestinationFile), l_strDestinationDir) = 0) Then
                l_strDestinationFile = Trim(p_strDestinationFile)
            Else
                l_strDestinationDir = Mid(p_strDestinationFile, 1, InStrRev(p_strDestinationFile, "\") - 1)
                l_strDestinationFile = Mid(Trim(p_strDestinationFile), InStrRev(p_strDestinationFile, "\") + 1)
            End If

            l_fso = New Scripting.FileSystemObject

            'MA-11/08/2015 - Updated for the remediation changes.
            ' Delete the Destination file if already exists
            If (l_fso.FileExists(l_strDestinationDir & l_strDestinationFile) And blnDelExist) Then
                l_fso.DeleteFile((l_strDestinationDir & l_strDestinationFile))
            End If

            ' Create a new Destination File
            If l_fso.FileExists(l_strDestinationDir & l_strDestinationFile) Then
                l_txtStrOutput = l_fso.OpenTextFile(l_strDestinationDir & l_strDestinationFile, Scripting.IOMode.ForAppending)
            Else
                l_txtStrOutput = l_fso.CreateTextFile(l_strDestinationDir & l_strDestinationFile, True)
            End If
            'MA-11/08/2015 - Updated for the remediation changes.
            l_fdInputFolder = l_fso.GetFolder(l_strSourceDir)

            For Each l_flInputFile In l_fdInputFolder.Files
                If l_flInputFile.Name Like l_strSourceFile Then
                    l_txtStrInput = l_flInputFile.OpenAsTextStream(Scripting.IOMode.ForReading)
                    l_ReadContent = l_txtStrInput.ReadAll
                    l_txtStrOutput.Write((l_ReadContent))
                    l_txtStrInput.Close()
                End If
            Next l_flInputFile

            l_txtStrOutput.Close()

            l_flInputFile = Nothing
            l_fdInputFolder = Nothing
            l_fso = Nothing
            l_txtStrInput = Nothing
            l_txtStrOutput = Nothing

        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : MergeFiles - " & Err.Description))
            MergeFiles = False
        Finally
            l_flInputFile = Nothing
            l_fdInputFolder = Nothing
            l_fso = Nothing
            l_txtStrInput = Nothing
            l_txtStrOutput = Nothing
        End Try
        MergeFiles = True
    End Function

    '###########################################################################
    'Function Name     : CallDLLFunction
    'Purpose           : To Invoke the DLL function that is passed as parameter
    '                    through the VB Script
    'Input             : (ByRef) p_connDatabase           - Database connection object
    '                    (ByRef) p_dicOverrideInfo        - Override dictionary object
    '                    (ByRef) p_dicBatchInfo           - Dictionary object to enter
    '                                                       log message
    '                     p_strName                       - Function that needs to be invoked
    '                     p_dicFuncParam                  - Parameter dictionary object
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - CallDLLFunction for Exception handling and code clean up
    'Optum  - 10/20/2016 : Modified to fix the code Defect with Billing Batch
    '###########################################################################
    Public Function CallDLLFunction(ByVal p_strName As String, ByRef p_dicFuncParam As Object, ByRef p_dicBatchInfo As Object, ByRef p_dicOverrideInfo As Object, ByRef strLogFilePath As String) As Boolean
        CallDLLFunction = True         'Optum  - 10/20/2016
        Try

            Select Case p_strName

                Case "BcpInData"
                    If Not BcpInData(p_dicBatchInfo, p_dicFuncParam.Item("InputFile"), p_dicFuncParam.Item("InputTable"), p_dicFuncParam.Item("CleanupTable"), p_dicFuncParam.Item("InputSystem"), p_dicFuncParam.Item("FormatFile"), strLogFilePath) Then
                        CallDLLFunction = False
                    End If

                Case "BcpOutData"
                    If Not BcpOutData(p_dicBatchInfo, p_dicFuncParam.Item("OutputFile"), p_dicFuncParam.Item("OutputTable"), p_dicFuncParam.Item("OutputSystem"), p_dicFuncParam.Item("FormatFile")) Then
                        CallDLLFunction = False
                    End If

                Case "CheckInputFile"
                    If Not CheckInputFile(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("SourceDir"), p_dicBatchInfo) Then
                        CallDLLFunction = False
                    End If

                Case "FileCopy"
                    If Not FileCopy_Renamed(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("DestinationDir"), p_dicBatchInfo) Then
                        CallDLLFunction = False
                    End If

                Case "FileDelete"
                    If Not FileDelete(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("MultipleFiles"), p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("DaysOld")) Then
                        CallDLLFunction = False
                    End If

                Case "FileMove"
                    If Not FileMove(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("DestinationDir"), p_dicBatchInfo) Then
                        CallDLLFunction = False
                    End If

                Case "FileRename"
                    If Not FileRename(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("DestinationFile"), p_dicBatchInfo) Then
                        CallDLLFunction = False
                    End If

                Case "FTPFile"
                    If Not FTPFile(p_dicBatchInfo, p_dicFuncParam.Item("Action"), p_dicFuncParam.Item("Destination"), p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("DestinationFile")) Then
                        CallDLLFunction = False

                    End If


                Case "GetLogFileName"
                    If Not GetLogFileName(p_dicFuncParam.Item("ProductName"), p_dicFuncParam.Item("BatchName"), p_dicBatchInfo) Then
                        CallDLLFunction = False
                    End If

                Case "MergeFiles"
                    If Not MergeFiles(p_dicFuncParam.Item("SourceFile"), p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("DestinationFile"), p_dicFuncParam.Item("DestinationDir")) Then
                        CallDLLFunction = False
                    End If

                Case "SendMail"
                    If Not SendMail(p_dicBatchInfo, p_dicFuncParam.Item("Body"), p_dicFuncParam.Item("To"), p_dicFuncParam.Item("Subject")) Then
                        CallDLLFunction = False
                    End If

                Case "UpdateDicOverride"
                    If Not UpdateDicOverride(p_dicFuncParam.Item("Item"), p_dicOverrideInfo, p_dicBatchInfo) Then
                        CallDLLFunction = False

                    End If

                Case "CreateEmptyFile"
                    If Not CreateEmptyFile(p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("FileName")) Then
                        CallDLLFunction = False
                    End If

                Case "RemoveTrailingSpaces"
                    If Not RemoveTrailingSpaces(p_dicFuncParam.Item("SourceDir"), p_dicFuncParam.Item("SourceFile")) Then
                        CallDLLFunction = False
                    End If

                Case Else
                    CallDLLFunction = False

                    p_dicBatchInfo.Item("MESSAGE") = "Log Message : Invalid Function Name " & p_strName
                    p_dicBatchInfo.Item("RETURN CODE") = 19
                    Call WriteTrace(p_dicBatchInfo)
            End Select

        Catch

            p_dicBatchInfo.Item("RETURN CODE") = 99
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CallDLLFunction - " & Err.Description))
            CallDLLFunction = False
        End Try


    End Function

    '###########################################################################
    'Function Name     : CheckSlash
    'Purpose           : To append backward slash ("\") to the folder name if its
    '                    last character is not "\"
    'Input             :
    '                    p_strFoldName - Folder path
    'Output            : Folder path with "\" appended
    'Syntel - 06/10/2015 : Modified the function - CheckSlash for Exception handling and code clean up
    '###########################################################################
    Public Function CheckSlash(ByRef p_strFoldName As String) As String

        Try
            ' Checking for the presence of "\" as the last character in string containing the folder path
            If ((Right(Trim(p_strFoldName), 1) <> "\") And Len(Trim(p_strFoldName)) <> 0) Then
                p_strFoldName = Trim(p_strFoldName) & "\"
            Else
                p_strFoldName = Trim(p_strFoldName)
            End If
            CheckSlash = p_strFoldName
        Catch
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CheckSlash - " & Err.Description))
            CheckSlash = p_strFoldName
        End Try

    End Function

    '###########################################################################
    'Function Name     : CreateEmptyFile
    'Purpose           : To create an Empty file
    'Input             :
    '                    p_strSourceDir   - Source File Path
    '                    p_strFileName    - Filename
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - CreateEmptyFile for Exception handling and code clean up
    '###########################################################################
    Public Function CreateEmptyFile(ByRef p_strSourceDir As String, ByRef p_strFileName As String) As Boolean

        Dim l_fsoCreateEmptyFile As Scripting.FileSystemObject      ' FileSystem Object to create the file
        Dim l_strSourceDir As String                                ' Variable to store the Source Dir
        Dim l_strFileName As String                                 ' Variable to store the Filename
        Try
            l_fsoCreateEmptyFile = New Scripting.FileSystemObject

            l_strSourceDir = CheckSlash(p_strSourceDir)

            If InStr(1, p_strFileName, "\") > 0 Then
                l_strFileName = Mid(p_strFileName, InStrRev(p_strFileName, "\") + 1)
            Else
                l_strFileName = p_strFileName
            End If

            l_fsoCreateEmptyFile.CreateTextFile(Trim(l_strSourceDir) & Trim(l_strFileName))

            l_fsoCreateEmptyFile = Nothing
        Catch
            CreateEmptyFile = False
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : CreateEmptyFile - " & Err.Description))
            l_fsoCreateEmptyFile = Nothing
        End Try
        CreateEmptyFile = True
    End Function

    '12-Jul-2006 Cognizant Offshore Added

    '###########################################################################
    'Function Name     : RemoveTrailingSpaces
    'Purpose           : To remove trailing spaces at end of the file
    'Input             :
    '                    p_strSourceDir   - Source File Path
    '                    p_strFileName    - Filename
    'Output            : True/False
    'Syntel - 06/10/2015 : Modified the function - RemoveTrailingSpaces for Exception handling and code clean up
    '###########################################################################
    Public Function RemoveTrailingSpaces(ByRef p_strSourceDir As String, ByRef p_strFileName As String) As Boolean

        Dim l_fsoRemoveBlankLine As Scripting.FileSystemObject              ' FileSystem Object to create the file
        Dim l_strSourceDir As String                                        ' Variable to store the Source Dir
        Dim l_strFileName As String                                         ' Variable to store the Filename
        Dim l_txtReadStream As Scripting.TextStream                         ' Variable to store the File
        Dim l_txtWriteStream As Scripting.TextStream                        ' Variable to store the file after removing the blank line
        Dim l_strReadStr As String                                          ' Variable to store the File in a string
        Try

            RemoveTrailingSpaces = True
            l_fsoRemoveBlankLine = New Scripting.FileSystemObject
            l_strSourceDir = CheckSlash(p_strSourceDir)

            If InStr(1, p_strFileName, "\") > 0 Then
                l_strFileName = Mid(p_strFileName, InStrRev(p_strFileName, "\") + 1)
            Else
                l_strFileName = p_strFileName
            End If

            l_txtReadStream = l_fsoRemoveBlankLine.OpenTextFile(Trim(l_strSourceDir) & Trim(l_strFileName))
            l_strReadStr = l_txtReadStream.ReadAll
            l_strReadStr = Trim(l_strReadStr)
            l_txtWriteStream = l_fsoRemoveBlankLine.CreateTextFile(Trim(l_strSourceDir) & Trim(l_strFileName))
            l_txtWriteStream.Write((l_strReadStr))

        Catch
            RemoveTrailingSpaces = False
            ' Writing the Error message in the Event log
            EventLog.WriteEntry("JD_NTBATCH_CMNFUNCS", (CStr(Today) & " - " & CStr(TimeOfDay) & " : RemoveBlankLine - " & Err.Description))
        Finally
            l_txtWriteStream = Nothing
            l_txtReadStream = Nothing
            l_fsoRemoveBlankLine = Nothing
        End Try
        RemoveTrailingSpaces = True
    End Function

End Class
