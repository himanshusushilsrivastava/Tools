Get-ChildItem "Data" -Filter *.txt | Select-String -Pattern '^customer' | Select -ExpandProperty line | Set-Content "Output.txt"
