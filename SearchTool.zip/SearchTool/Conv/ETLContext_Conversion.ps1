﻿## Script to to context file conversions
##
##

$date = Get-Date -format "yyyyMMdd"
$dateStr = Get-Date -format "MMddyyyyHHmmss"

##Variable##

## Change Below path to the folder location where sript needs to be executed.
$RunPath = "C:\Users\hsrivas1\Documents\GitHub\Talend_02\Finance_JPM_ACH_Recon_KW_Gen_ISL_ETL"
$contextfilefilter = "*dev.properties*"
$conversioncontext = "DEV09.properties" ##Can Change the DV09 or Dev09 based on the file name we want

#Reports Path
$reportpath = $env:HOME + "\" + $dateStr + "_impact_Report.csv"


##

Get-ChildItem $RunPath -recurse -Filter $contextfilefilter  | Select-Object DirectoryName,Name,FullName | Export-Csv -Path $reportpath
$path = Get-ChildItem $RunPath -recurse -Filter $contextfilefilter  | Select-Object DirectoryName,Name,FullName 

foreach ($file in $path) {

$SourceFileName = $file.FullName
write $SourceFileName
$NewFileName = $file.DirectoryName + “\” + $conversioncontext

$dev02data = Get-ChildItem -path $SourceFileName -recurse -Filter *.* | Select-String -pattern "dev02" | Select-Object line,linenumber,filename,path
write $dev02data

$dv02data = Get-ChildItem -path $SourceFileName -recurse -Filter *.* | Select-String -pattern "dv02" | Select-Object line,linenumber,filename,path
write $dv02data

##Add other replace check if needed.

(Get-Content $SourceFileName) | Foreach-Object {$_ -replace 'dev02','dev09'}  | Out-File $SourceFileName
(Get-Content $SourceFileName) | Foreach-Object {$_ -replace 'dv02','dv09'}  | Out-File $SourceFileName

Copy-Item -Path $SourceFileName -Destination $NewFileName
Remove-Item -Path $SourceFileName ##Can be commented if do not wants to remove the dev file

}