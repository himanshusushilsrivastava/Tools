#Search_Keyword1 = "CWTY_ID"
if test -z "CWTY_ID" 
then
      echo "Search_Keyword1 is NULL"
else
      echo "Search_Keyword1 is NOT NULL"
grep --include=\*.{java,xml,properties,sql,sqt} -rin --color "CWTY_ID"
fi

if test -z "${Search_Keyword2}" 
then
      echo "Search_Keyword2 is NULL"
else
      echo "Search_Keyword2 is NOT NULL"
grep --include=\*.{java,xml,properties,sql,sqt} -rin --color "${Search_Keyword2}"      
fi

if test -z "${Search_Keyword3}" 
then
      echo "Search_Keyword3 is NULL"
else
      echo "Search_Keyword3 is NOT NULL"
grep --include=\*.{java,xml,properties,sql,sqt} -rin --color "${Search_Keyword3}"      
fi

echo "CodeInvestigator Processing Completed ! "