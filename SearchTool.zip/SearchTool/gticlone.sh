# the git clone cmd used for cloning each repository
# the parameter recursive is used to clone submodules, too.
#exec > logfile.txt



exec > >(tee -i logfile_clone.log)
exec 2>&1

GIT_CLONE_CMD="git clone "
read -p "Running the Git Clone script now? Which page ? " answer
case $answer in
[123456789]*)   
# fetch repository list via github api
# grep fetches the json object key ssh_url, which contains the ssh url for the repository
REPOLIST=`curl --silent "https://github.optum.com/api/v3/users/UHOneFacets/repos?per_page=200&page=$answer" -q | grep "\"clone_url\"" | awk -F': "' '{print $2}' | sed -e 's/",//g'`

# loop over all repository urls and execute clone
for REPO in $REPOLIST; do
    ${GIT_CLONE_CMD}${REPO}
done
           echo "Completed Successfully"
           break;;
   *) echo "Please Enter numeric only.";;
esac