/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_users_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_users_select

   PRINT "Procedure scs_cnfg_users_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_users_select                                *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_users_select
(
    @pnUserType   INT
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_users_select                               *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Selects the user ids from facets table.             *
 **                                                                           *
 ** Input               :   @pnUserType         - User type                   *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. CER_PZUU_PROUSER_U                               *
 **                       2. CER_USGR_USER_T                                  *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN

    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error

    -- Users        - @pnUserType = 0
    -- Usergroups   - @pnUserType = 1

    IF @pnUserType = 0
     BEGIN
        CREATE TABLE #scst_cnfg_tusr_pzuu
        (
            USUS_ID     CHAR(10)
        )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in create temporary table"
           RETURN   1
       END

        
        INSERT INTO #scst_cnfg_tusr_pzuu
        (
            USUS_ID
        )
        
        SELECT 
            USUS_ID 
        
        FROM    CER_PZUU_PROUSER_U
        WHERE   PZPZ_ID = 'FA'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in insert."
           RETURN   1
       END


        DELETE 
        FROM #scst_cnfg_tusr_pzuu
        
        FROM    #scst_cnfg_tusr_pzuu tusr,
                CER_USGR_USER_T             usgr
        
        WHERE LTRIM(RTRIM(tusr.USUS_ID)) = LTRIM(RTRIM(usgr.USUS_ID))

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in delete"
           RETURN   1
       END


        SELECT 
            USUS_ID 

        FROM #scst_cnfg_tusr_pzuu 
        
        ORDER BY USUS_ID

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in select"
           RETURN   1
       END

     END

    ELSE IF @pnUserType = 1
     BEGIN
        SELECT USUS_ID FROM CER_USGR_USER_T ORDER BY USUS_ID


    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in select"
           RETURN   1
       END

     END
      -- End of procedure

      RETURN 0
END

GO
--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_users_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_users_select"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_users_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_users_select TO Facets_Application
GO
GRANT EXECUTE ON scs_cnfg_users_select TO Facets_Load 
GO
GRANT EXECUTE ON scs_cnfg_users_select TO Sybase_Read_Only 
GO