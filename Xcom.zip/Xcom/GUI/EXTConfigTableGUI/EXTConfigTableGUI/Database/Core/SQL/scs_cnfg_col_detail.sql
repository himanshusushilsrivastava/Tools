/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_col_detail') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_col_detail

   PRINT "Procedure scs_cnfg_col_detail dropped."

 END
GO

CREATE TABLE #scst_cnfg_cols_columns 
  ( 
     COLUMN_NAME     VARCHAR(30) , 
     COLUMN_TYPE     VARCHAR(30) , 
     COLUMN_LENGTH   INT         ,
     COLUMN_SCALE    INT         ,
     NULLS           CHAR(1)     , 
     KEYS            CHAR(1)     , 
     COL_ID          SMALLINT    ,
     IDEN            CHAR(1)
 ) 
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_col_detail                                  *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_col_detail
(
    @pvcTable       VARCHAR(30)        , 
    @pvcDB          VARCHAR(30)  
) 
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_col_detail                                 *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Fetches the column details and updates it to a temp *
 **                       scs_cnfg_col_detail.                                *
 **                                                                           *
 ** Input               :   @pvcTable           - Table Name                  *
 **                         @pvcDB              - Database Name               *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : 1. OBJECT_ID                                        *
 **                       2. INDEX_COL                                        *
 **                                                                           *
 **     Tables          : 1. master..spt_values                               *
 **                       2. sysindexes                                       *
 **                       3. syscolumns                                       *
 **                       4. systypes                                         *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                       1.1 - 09/10/2012 UHGIS offshore                     *
 **                       Modified the NULL comaprisions for ANSINULL issue   *
 **                       as a part of PM10052020 : Custom GUI � Unable to    *
 **                       update the data in the configuration table          *
 ******************************************************************************/
AS 
BEGIN 
 
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************
    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    DECLARE   @lnIndid              INT          , 
              @lnIndkey             INT          , 
              @lnId                 INT          ,  
              @lvcQuery             VARCHAR(5000) 
 
  
         
    SELECT  @lnId       = OBJECT_ID(@pvcDB + ".." + @pvcTable) 
 
    SELECT  @lnIndid    = 1 


    CREATE TABLE #scst_cnfg_clin_index 
    ( 
        COLUMN_NAME VARCHAR(30) 
    ) 


--**************************************************************************
-- Select the error code and rowcount returned for this step               *
--**************************************************************************

  SELECT  @lnError    = @@ERROR ,
          @lnRowCount = @@ROWCOUNT

--**************************************************************************
-- Check for errors while updating a  attachment information.              *
--**************************************************************************

   IF (@lnError <> 0)

   BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_col_detail in truncating table #scst_cnfg_clin_index"
       RETURN   1
   END

     
    CREATE TABLE #scst_cnfg_indi_indid 
    ( 
        INDID   SMALLINT 
    )  
--**************************************************************************
-- Select the error code and rowcount returned for this step               *
--**************************************************************************

  SELECT  @lnError    = @@ERROR ,
          @lnRowCount = @@ROWCOUNT

--**************************************************************************
-- Check for errors while updating a  attachment information.              *
--**************************************************************************

   IF (@lnError <> 0)

   BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_col_detail in truncating table #scst_cnfg_indi_indid"
       RETURN   1
   END

         
    SELECT @lvcQuery =  " INSERT INTO #scst_cnfg_indi_indid "        + 
                        " ( "                                       + 
                        "   INDID "                                 + 
                        " ) "                                       + 
                        " SELECT i.indid "                          + 
                        " FROM master..spt_values   v,     "        + 
                                   @pvcDB + "..sysindexes   i      " + 
                        " WHERE   i.status & v.number = v.number   " + 
                        "   AND   v.type              = 'I'        " + 
                        "   AND   v.number            = 2          " + 
                        "   AND   i.id                = " + CONVERT(VARCHAR, @lnId)    + 
                        "   AND   i.indid             = " + CONVERT(VARCHAR, @lnIndid) 
 
    EXEC(@lvcQuery) 
--**************************************************************************
-- Select the error code and rowcount returned for this step               *
--**************************************************************************

  SELECT  @lnError    = @@ERROR ,
          @lnRowCount = @@ROWCOUNT

--**************************************************************************
-- Check for errors while updating a  attachment information.              *
--**************************************************************************

   IF (@lnError <> 0)

   BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_col_detail in Executing insert for indid value"
       RETURN   1
   END

 
    IF EXISTS (SELECT * FROM #scst_cnfg_indi_indid) 
 
     BEGIN     
 
        SELECT  @lnIndkey = 1 
 
        WHILE   @lnIndkey <= 16 AND INDEX_COL(@pvcDB + ".." + @pvcTable, @lnIndid, @lnIndkey) IS NOT NULL 
 
         BEGIN  
 
            INSERT INTO #scst_cnfg_clin_index 
            ( 
                COLUMN_NAME 
            ) 
            SELECT  INDEX_COL(@pvcDB + ".." + @pvcTable, @lnIndid , @lnIndkey) 

            --**************************************************************************
            -- Select the error code and rowcount returned for this step               *
            --**************************************************************************

              SELECT  @lnError    = @@ERROR ,
                      @lnRowCount = @@ROWCOUNT

            --**************************************************************************
            -- Check for errors while updating a  attachment information.              *
            --**************************************************************************

               IF (@lnError <> 0)

               BEGIN
                   RAISERROR 1 "Error in procedure scs_cnfg_col_detail in selecting column names"
                   RETURN   1
               END     


            SELECT  @lnIndkey = @lnIndkey + 1 
 
         END 
 
     END       
 
 
    ELSE  
 
 
     BEGIN   
         
        TRUNCATE TABLE #scst_cnfg_indi_indid 
 
        SELECT @lvcQuery =  " INSERT INTO #scst_cnfg_indi_indid "    + 
                            " ( "                                   + 
                            "   INDID "                             + 
                            " ) "                                   + 
                            " SELECT  indid "                       + 
                            " FROM " + @pvcDB + "..sysindexes i, "  + 
                            "           master..spt_values    v "   + 
                            " WHERE   i.status2 & 512 = 512 "       + 
                            "  AND   i.indid        <> 0 "          + 
                            "  AND   v.type          = 'I' "        + 
                            "  AND   v.number        = 2 "          + 
                            "  AND   i.id            = " + CONVERT(VARCHAR, @lnId) 
 
        EXEC(@lvcQuery) 

        --**************************************************************************
        -- Select the error code and rowcount returned for this step               *
        --**************************************************************************

          SELECT  @lnError    = @@ERROR ,
                  @lnRowCount = @@ROWCOUNT

        --**************************************************************************
        -- Check for errors while updating a  attachment information.              *
        --**************************************************************************

           IF (@lnError <> 0)

           BEGIN
               RAISERROR 1 "Error in procedure scs_cnfg_col_detail in Executing insert for indid value"
               RETURN   1
           END
           

        SELECT  @lnIndid = INDID 
        FROM    #scst_cnfg_indi_indid 
 
        IF @lnIndid IS NOT NULL 
         BEGIN             
 
            SELECT  @lnIndkey = 1 
 
            WHILE   @lnIndkey <= 16 AND INDEX_COL(@pvcDB + ".." + @pvcTable, @lnIndid, @lnIndkey) IS NOT NULL 
 
             BEGIN     
 
 
                INSERT INTO #scst_cnfg_clin_index 
                ( 
                    COLUMN_NAME 
                ) 
                SELECT  
                INDEX_COL(@pvcDB + ".." + @pvcTable, @lnIndid, @lnIndkey) 
                --**************************************************************************
                -- Select the error code and rowcount returned for this step               *
                --**************************************************************************

                  SELECT  @lnError    = @@ERROR ,
                          @lnRowCount = @@ROWCOUNT

                --**************************************************************************
                -- Check for errors while updating a  attachment information.              *
                --**************************************************************************

                   IF (@lnError <> 0)

                   BEGIN
                       RAISERROR 1 "Error in procedure scs_cnfg_col_detail in selecting column nanes"
                       RETURN   1
                   END


                SELECT  @lnIndkey = @lnIndkey + 1 
 
             END  
 
         END 
 
     END 
     
    SELECT @lvcQuery =  " INSERT INTO #scst_cnfg_cols_columns "    + 
                        " ( "                                     + 
                        "   COLUMN_NAME     , "                   + 
                        "   COLUMN_TYPE     , "                   + 
                        "   COLUMN_LENGTH   , "                   + 
                        "   COLUMN_SCALE    , "                   + 
                        "   NULLS           , "                   + 
                        "   KEYS            , "                   + 
                        "   COL_ID          , "                   + 
                        "   IDEN              "                   +
                        " ) "                                     + 
                        " SELECT "                                + 
                        "    scol.name                   , "      + 
                        "    LTRIM(RTRIM(styp.name))     , "      + 
                       /* Begin Version 1.1*/
                       /*  "CASE WHEN scol.scale <> NULL  "        + */
                        "  CASE WHEN scol.scale IS NOT NULL  "    +
                       /* End Version 1.1 */ 
                        "           THEN scol.prec - scol.scale " +
                        "         ELSE                     "      +
                        "                scol.length       "      +
                        "         END                 ,    "      +
                        /* Begin Version 1.1 */
                        /* "    CASE WHEN scol.scale <> NULL  "      + */
                        "  CASE WHEN scol.scale IS NOT NULL  "  + 
                        /* End Version 1.1 */
                        "           THEN scol.scale        "      +
                        "         ELSE                     "      +
                        "                0	               "      +
                        "         END	    			,  "      +
                        "    CASE WHEN scol.status = 8     "      + 
                        "         THEN 'Y'                 "      + 
                        "         ELSE 'N'                 "      + 
                        "         END                    , "      + 
                        "    'N'                         , "      + 
                        "    scol.colid                  , "      + 
                        "    CASE WHEN scol.status = 128   "      + 
                        "         THEN 'Y'                 "      + 
                        "         ELSE 'N'                 "      + 
                        "         END                      "      +
                        " FROM " + @pvcDB + "..syscolumns  scol, "+  
                                   @pvcDB + "..systypes    styp " + 
                        " WHERE   scol.id = " + convert(varchar, @lnId) + 
                        "   AND   scol.usertype = styp.usertype " 
 
    EXEC(@lvcQuery)     
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_col_detail in insert of column information"
           RETURN   1
       END
   

    UPDATE  #scst_cnfg_cols_columns 
 
    SET     KEYS = 'Y' 
 
    FROM    #scst_cnfg_cols_columns   cols, 
            #scst_cnfg_clin_index  indx 
 
    WHERE   indx.COLUMN_NAME = cols.COLUMN_NAME 

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_col_detail in update of keys"
           RETURN   1
       END

   -- End of procedure

    RETURN 0
END
GO

DROP TABLE #scst_cnfg_cols_columns
GO

/******************************************************************************
 * Check for errors in creating the procedure.                                *
 ******************************************************************************/

IF OBJECT_ID('scs_cnfg_col_detail') IS NOT NULL

    BEGIN

        PRINT 'Procedure scs_cnfg_col_detail created sucessfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating procedure scs_cnfg_col_detail'

    END
GO


/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_col_detail TO Facets_Application 
GO
  
GRANT EXECUTE ON scs_cnfg_col_detail TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_col_detail TO Sybase_Read_Only 
GO