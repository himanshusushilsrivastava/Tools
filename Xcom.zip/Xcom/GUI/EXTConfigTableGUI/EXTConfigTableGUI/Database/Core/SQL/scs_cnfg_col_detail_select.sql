/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_col_detail_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_col_detail_select

   PRINT "Procedure scs_cnfg_col_detail_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_col_detail_select                           *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_col_detail_select  
(
    @pvcTable       VARCHAR(30)        , 
    @pvcDB          VARCHAR(30)  
) 
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_col_detail_select                          *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Fetches the column details.                         *
 **                                                                           *
 ** Input               :   @pvcTable           - Table Name                  *
 **                         @pvcDB              - Database Name               *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : 1. OBJECT_ID                                        *
 **                       2. INDEX_COL                                        *
 **                                                                           *
 **     Tables          : None                                                *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS 
BEGIN 
 
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************
    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error

     
        CREATE TABLE #scst_cnfg_cols_columns 
        ( 
            COLUMN_NAME     VARCHAR(30) , 
            COLUMN_TYPE     VARCHAR(30) , 
            COLUMN_LENGTH   INT         ,
            COLUMN_SCALE    INT         ,
            NULLS           CHAR(1)     , 
            KEYS            CHAR(1)     , 
            COL_ID          SMALLINT    ,
            IDEN            CHAR(1)
        ) 
 
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_col_detail_select in truncating table #scst_cnfg_cols_columns"
           RETURN   1
       END

         
        EXEC @lnError = scs_cnfg_col_detail @pvcTable, @pvcDB

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_col_detail_select in select"
           RETURN   1
       END

     
        SELECT  
           COLUMN_NAME      ,
           COLUMN_TYPE      ,
           COLUMN_LENGTH    ,
           NULLS            ,
           KEYS             ,
           IDEN             ,
           COLUMN_SCALE

        FROM #scst_cnfg_cols_columns ORDER BY COL_ID
        
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_col_detail_select in select"
           RETURN   1
       END

    -- End of procedure

    RETURN 0
END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************

IF OBJECT_ID('scs_cnfg_col_detail_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_col_detail_select."

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_col_detail_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_col_detail_select TO Facets_Application
GO

GRANT EXECUTE ON scs_cnfg_col_detail_select TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_col_detail_select TO Sybase_Read_Only 
GO



