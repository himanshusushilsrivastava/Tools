/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_usr_perm_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_usr_perm_select

   PRINT "Procedure scs_cnfg_usr_perm_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_usr_perm_select                             *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_usr_perm_select
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_usr_perm_select                            *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Updates the user permissions on the tables into the *
 **                       work table fakpfstage..scst_cnfg_perm_wrk           *
 **                                                                           *
 ** Input               :   None                                              *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_perm_wrk                   *
 **                       2. CER_USGU_USERGRP_U                               *
 **                       3. fakpfstage..scst_cnfg_perm_usus_tbl              *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/

AS

BEGIN
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error

    DECLARE @lvcUser        VARCHAR(10),
            @lvcSystemAdmin VARCHAR(10),
            @lvcDB          VARCHAR(30)

    SELECT  @lvcUser        = SUSER_NAME()


    UPDATE  fakpfstage..scst_cnfg_perm_wrk

    SET
    PERM_INS    = pmpm.PERM_INS    ,
    PERM_UPD    = pmpm.PERM_UPD

    FROM    fakpfstage..scst_cnfg_perm_usus_tbl pmpm,
            CER_USGU_USERGRP_U                  usgu,
            fakpfstage..scst_cnfg_perm_wrk      wrk

    WHERE   wrk.TABLE_NAME      = pmpm.TABLE_NAME
      AND   wrk.DB_NAME         = pmpm.DB_NAME
      AND   usgu.USGR_USUS_ID   = pmpm.USUS_ID
      AND   usgu.USUS_ID        = @lvcUser

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in update"
           RETURN   1
       END


    UPDATE
    fakpfstage..scst_cnfg_perm_wrk

    SET
    PERM_INS    = pmpm.PERM_INS    ,
    PERM_UPD    = pmpm.PERM_UPD

    FROM    fakpfstage..scst_cnfg_perm_usus_tbl pmpm,
            fakpfstage..scst_cnfg_perm_wrk      wrk
    
    WHERE   wrk.TABLE_NAME  = pmpm.TABLE_NAME
      AND   wrk.DB_NAME     = pmpm.DB_NAME
      AND   pmpm.USUS_ID    = @lvcUser

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_users_select in update"
           RETURN   1
       END


      -- End of procedure
      RETURN 0
END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_usr_perm_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_usr_perm_select"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_usr_perm_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_usr_perm_select TO Facets_Application
GO
GRANT EXECUTE ON scs_cnfg_usr_perm_select TO Facets_Load 
GO
GRANT EXECUTE ON scs_cnfg_usr_perm_select TO Sybase_Read_Only 
GO
