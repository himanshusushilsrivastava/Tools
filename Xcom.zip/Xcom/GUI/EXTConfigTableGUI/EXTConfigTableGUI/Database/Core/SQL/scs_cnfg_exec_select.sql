/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_exec_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_exec_select

   PRINT "Procedure scs_cnfg_exec_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_exec_insert                                 *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_exec_select
(
    @pvcTable   VARCHAR(30)        ,
    @pvcDB      VARCHAR(30)
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_exec_insert                                *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Selects from the table name as input parameter.     *
 **                                                                           *
 ** Input               :   @pvcTable           - Table Name                  *
 **                         @pvcDB              - Database Name               *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. Table as parameter                               *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


            EXEC("SELECT * FROM " + @pvcDB + ".." + @pvcTable)
            --**************************************************************************
            -- Select the error code and rowcount returned for this step               *
            --**************************************************************************

              SELECT  @lnError    = @@ERROR ,
                      @lnRowCount = @@ROWCOUNT

            --**************************************************************************
            -- Check for errors while updating a  attachment information.              *
            --**************************************************************************

               IF (@lnError <> 0)

               BEGIN
                   RAISERROR 1 "Error in procedure scs_cnfg_exec_insert in select"
                   RETURN   1
               END
     -- End of procedure

    RETURN 0
END
GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_exec_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_exec_select"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_exec_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_exec_select TO Facets_Application
GO
GRANT EXECUTE ON scs_cnfg_exec_select TO Facets_Load 
GO
GRANT EXECUTE ON scs_cnfg_exec_select TO Sybase_Read_Only 
GO