/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_tables_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_tables_select

   PRINT "Procedure scs_cnfg_tables_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_tables_select                               *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_tables_select
(
    @pchDB  VARCHAR(30)
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_tables_select                              *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Selects the tables from                             *
 **                       fakpfstage..scst_cnfg_tables_config into work table *
 **                       fakpfstage..scst_cnfg_perm_wrk                      *
 **                                                                           *
 ** Input               :   @pchDB      - Database Name                       *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : 1. scs_cnfg_usr_perm_select                         *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_tables_config              *
 **                       2. fakpfstage..scst_cnfg_perm_wrk                   *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN

    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    DELETE FROM fakpfstage..scst_cnfg_perm_wrk

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_tables_select in truncate"
           RETURN   1
       END

    
    INSERT INTO
    fakpfstage..scst_cnfg_perm_wrk
    (
        TABLE_NAME  ,
        DB_NAME     ,
        PERM_INS    ,
        PERM_UPD    
    )
    SELECT 
        TABLE_NAME  ,
        DB_NAME     ,
        'N'         ,
        'N'
    
    FROM    fakpfstage..scst_cnfg_tables_config 
    
    WHERE   DB_NAME     = @pchDB

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_tables_select in insert"
           RETURN   1
       END

    EXEC @lnError = scs_cnfg_usr_perm_select

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_tables_select in Execute procedure scs_cnfg_usr_perm_select"
           RETURN   1
       END


    SELECT 
        TABLE_NAME  ,
        PERM_INS    ,
        PERM_UPD    
    FROM fakpfstage..scst_cnfg_perm_wrk

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_tables_select in select"
           RETURN   1
       END

      -- End of procedure

      RETURN 0

END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************

IF OBJECT_ID('scs_cnfg_tables_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_tables_select."

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_tables_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_tables_select TO Facets_Application
GO
GRANT EXECUTE ON scs_cnfg_tables_select TO Facets_Load 
GO
GRANT EXECUTE ON scs_cnfg_tables_select TO Sybase_Read_Only 
GO
 