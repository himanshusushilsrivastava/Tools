/******************************************************************************
 * If the Trigger already exists, then drop and recreate it.                  *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_tables_config_dtrg') IS NOT NULL

    BEGIN

        DROP TRIGGER scst_cnfg_tables_config_dtrg

        PRINT 'Dropped trigger scst_cnfg_tables_config_dtrg'

    END

GO

/*****************************************************************************
 * Create the Trigger scst_cnfg_tables_config_dtrg                            *
 *****************************************************************************/

CREATE TRIGGER scst_cnfg_tables_config_dtrg ON scst_cnfg_tables_config
FOR DELETE
/***************************************************************************
**  NAME:       scst_cnfg_tables_config_dtrg
**  AUTHOR:     Cognizant
**  VERSION:    1.0
**  DATE:       04/09/2008
**  FUNCTION:   this trigger is for delete on scst_cnfg_tables_config table
**  PARAMETERS: input- NA
**              output- NA
**
**  ERRORS RAISED:
**
**  CREATE/CHANGE LOG:
**  Date                Name            Reason
**  04/09/2008		    Cognizant	    Created	
**
***************************************************************************/
AS
BEGIN

    DELETE FROM scst_cnfg_perm_usus_tbl
 
    FROM    deleted                 dltd,
            scst_cnfg_perm_usus_tbl pmpm
    
    WHERE   pmpm.TABLE_NAME  = dltd.TABLE_NAME

END
GO

/******************************************************************************
 * Check for errors in creating the trigger.                                *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_tables_config_dtrg') IS NOT NULL

    BEGIN

        PRINT 'Trigger scst_cnfg_tables_config_dtrg created sucessfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating trigger scst_cnfg_tables_config_dtrg'

    END

GO