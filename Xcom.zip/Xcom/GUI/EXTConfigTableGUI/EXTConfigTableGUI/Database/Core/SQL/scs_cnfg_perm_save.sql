/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_perm_save') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_perm_save

   PRINT "Procedure scs_cnfg_perm_save dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_perm_save                                   *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_perm_save
(
    @pvcUSUS_ID     VARCHAR(10),
    @pvcDBName      VARCHAR(30),
    @pvcTableName   VARCHAR(30),
    @pchPermIns       CHAR(1),
    @pchPermUpd       CHAR(1)
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_perm_save                                  *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Saves the table permission for a user.              *
 **                                                                           *
 ** Input               :   @pvcUSUS_ID         - User ID                     *
 **                         @pvcTableName       - Table Name                  *
 **                         @pchPermRd          - Permission Read             *
 **                         @pchPermIns         - Permission Insert           *
 **                         @pchPermUpd         - Permission Update           *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_perm_usus_tbl              *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    IF NOT EXISTS 
    (
        SELECT 1 FROM fakpfstage..scst_cnfg_perm_usus_tbl 
        WHERE   USUS_ID     = @pvcUSUS_ID
          AND   TABLE_NAME  = @pvcTableName
          AND   DB_NAME     = @pvcDBName
    )
     BEGIN
        INSERT INTO fakpfstage..scst_cnfg_perm_usus_tbl
        (
            USUS_ID     ,
            DB_NAME     ,
            TABLE_NAME  ,
            PERM_INS    ,
            PERM_UPD
        )
        VALUES
        (
            @pvcUSUS_ID     ,
            @pvcDBName      ,
            @pvcTableName   ,
            @pchPermIns     ,
            @pchPermUpd
        )

        --**************************************************************************
        -- Select the error code and rowcount returned for this step               *
        --**************************************************************************

          SELECT  @lnError    = @@ERROR ,
                  @lnRowCount = @@ROWCOUNT

        --**************************************************************************
        -- Check for errors while updating a  attachment information.              *
        --**************************************************************************

           IF (@lnError <> 0)

           BEGIN
               RAISERROR 1 "Error in procedure scs_cnfg_perm_save in insert"
               RETURN   1
           END
     END
    ELSE
     BEGIN
        UPDATE fakpfstage..scst_cnfg_perm_usus_tbl
        SET
            PERM_INS  = @pchPermIns ,
            PERM_UPD  = @pchPermUpd

        WHERE   USUS_ID     = @pvcUSUS_ID
          AND   TABLE_NAME  = @pvcTableName
          AND   DB_NAME     = @pvcDBName
        
        --**************************************************************************
        -- Select the error code and rowcount returned for this step               *
        --**************************************************************************

          SELECT  @lnError    = @@ERROR ,
                  @lnRowCount = @@ROWCOUNT

        --**************************************************************************
        -- Check for errors while updating a  attachment information.              *
        --**************************************************************************

           IF (@lnError <> 0)

           BEGIN
               RAISERROR 1 "Error in procedure scs_cnfg_perm_save in update"
               RETURN   1
           END

     END
    -- End of procedure

    RETURN 0
END

GO
--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_perm_save') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_perm_save"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_perm_save created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_perm_save TO Facets_Application
GO

GRANT EXECUTE ON scs_cnfg_perm_save TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_perm_save TO Sybase_Read_Only 
GO