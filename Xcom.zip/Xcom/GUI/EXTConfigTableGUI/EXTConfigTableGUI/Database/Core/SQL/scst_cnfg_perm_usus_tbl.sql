/******************************************************************************
 * This script file creates the table scst_cnfg_perm_usus_tbl                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_perm_usus_tbl') IS NOT NULL

    BEGIN

        DROP TABLE scst_cnfg_perm_usus_tbl

        PRINT 'Dropped table scst_cnfg_perm_usus_tbl'

    END

GO

/******************************************************************************
 **                                                                           *
 ** Table Name              : scst_cnfg_perm_usus_tbl                         *
 **                                                                           *
 ** Purpose                 : Holds list of all the User Id and Table Names   *
 **                           along with the permission of the corresponding  *
 **                           user on the table.                              *
 **                                                                           *
 **                                                                           *
 ** Revision History        : 1.0 - 04/09/2008  Cognizant Offshore            *
 **                           Initial version                                 *
 **                                                                           *
 ******************************************************************************/

CREATE TABLE scst_cnfg_perm_usus_tbl
(
    USUS_ID     VARCHAR(30)     NOT NULL,
    DB_NAME     VARCHAR(30)     NOT NULL,
    TABLE_NAME  VARCHAR(30)     NOT NULL,
    PERM_INS    CHAR(1)         NOT NULL,
    PERM_UPD    CHAR(1)         NOT NULL
)
LOCK DATAROWS
GO

/******************************************************************************
 * Grant permission                                                           *
 ******************************************************************************/
 
GRANT DELETE ON scst_cnfg_perm_usus_tbl TO Facets_Application
GO
 
GRANT INSERT ON scst_cnfg_perm_usus_tbl TO Facets_Application
GO
 
GRANT REFERENCES ON scst_cnfg_perm_usus_tbl TO Facets_Application
GO
 
GRANT SELECT ON scst_cnfg_perm_usus_tbl TO Facets_Application
GO
 
GRANT UPDATE ON scst_cnfg_perm_usus_tbl TO Facets_Application
GO

/******************************************************************************
 * Check for errors in creating the table scst_cnfg_perm_usus_tbl             *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_perm_usus_tbl') IS NOT NULL

    BEGIN

        PRINT 'Table scst_cnfg_perm_usus_tbl created successfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating table scst_cnfg_perm_usus_tbl'

    END

GO