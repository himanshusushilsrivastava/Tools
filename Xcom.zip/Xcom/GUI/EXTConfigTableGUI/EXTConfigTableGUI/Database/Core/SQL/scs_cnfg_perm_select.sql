/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_perm_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_perm_select

   PRINT "Procedure scs_cnfg_perm_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_perm_select                                 *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_perm_select
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_perm_select                                *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Selects the table permission for a user.            *
 **                                                                           *
 ** Input               :   None                                              *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_perm_usus_tbl              *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN

    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    SELECT 
        USUS_ID     ,
        DB_NAME     ,
        TABLE_NAME  ,
        PERM_INS    ,
        PERM_UPD
    FROM fakpfstage..scst_cnfg_perm_usus_tbl 

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_perm_save in insert"
           RETURN   1
       END

      -- End of procedure

      RETURN 0
END
GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_perm_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_perm_select"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_perm_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_perm_select TO Facets_Application
GO

GRANT EXECUTE ON scs_cnfg_perm_select TO Facets_Load 
GO

GRANT EXECUTE ON scs_cnfg_perm_select TO Sybase_Read_Only 
GO