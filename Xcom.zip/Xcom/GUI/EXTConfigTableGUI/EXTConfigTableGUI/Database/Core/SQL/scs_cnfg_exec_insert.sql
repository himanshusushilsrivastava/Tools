/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_exec_insert') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_exec_insert

   PRINT "Procedure scs_cnfg_exec_insert dropped."

 END
GO
/*****************************************************************************
 * Create the Procedure scs_cnfg_exec_insert                                 *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_exec_insert  
(
    @pvcDB          VARCHAR(30) ,
    @pvcTable       VARCHAR(30) ,
    @pvcQuery1      VARCHAR(1900)  , 
    @pvcQuery2      VARCHAR(1900)  ,
    @pvcQuery3      VARCHAR(1900)  ,
    @pvcQuery4      VARCHAR(1900)  ,
    @pvcQuery5      VARCHAR(1900)  ,
    @pvcQuery6      VARCHAR(1900)
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_exec_insert                                *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Combines the query strings to insert value into a   *
 **                       the table.                                          *
 **                                                                           *
 ** Input               :   @pvcDB              - Database Name               *
 **                         @pvcTable           - Table Name                  *
 **                         @pvcQuery1          - Query part 1                *
 **                         @pvcQuery2          - Query part 2                *
 **                         @pvcQuery3          - Query part 3                *
 **                         @pvcQuery4          - Query part 4                *
 **                         @pvcQuery5          - Query part 5                *
 **                         @pvcQuery6          - Query part 6                *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_perm_usus_tbl                          *
 **			              2. CER_USGU_USERGRP_U				                  *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS 
 
BEGIN

    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    DECLARE @lvcUser        VARCHAR(10) ,
            @lchCheck       CHAR(1)

    SELECT  @lvcUser    = SUSER_NAME()
    SELECT  @lchCheck   = 'N'
    

    SELECT  @lchCheck = 'Y'
                  
    FROM    fakpfstage..scst_cnfg_perm_usus_tbl pmpm,
            CER_USGU_USERGRP_U      usgu

    WHERE   pmpm.TABLE_NAME = LTRIM(RTRIM(@pvcTable))
      AND   pmpm.USUS_ID    = usgu.USGR_USUS_ID
      AND   usgu.USUS_ID    = @lvcUser
      AND   pmpm.PERM_INS   = 'Y'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_exec_insert in Checking Group permission"
           RETURN   1
       END

    SELECT  @lchCheck = 'N' 
    FROM    fakpfstage..scst_cnfg_perm_usus_tbl 

    WHERE   TABLE_NAME      = LTRIM(RTRIM(@pvcTable)) 
      AND   USUS_ID         = @lvcUser
      AND   PERM_INS        = 'N'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_exec_insert in Checking User permission"
           RETURN   1
       END


    SELECT  @lchCheck = 'Y' 
    FROM    fakpfstage..scst_cnfg_perm_usus_tbl 

    WHERE   TABLE_NAME      = LTRIM(RTRIM(@pvcTable)) 
      AND   USUS_ID         = @lvcUser
      AND   PERM_INS        = 'Y'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_exec_insert in Checking User permission"
           RETURN   1
       END



    IF  ( @lchCheck = 'Y' )
     BEGIN
        EXEC ("INSERT INTO " + @pvcDB + ".." + @pvcTable + @pvcQuery1 + @pvcQuery2 + @pvcQuery3 + @pvcQuery4 + @pvcQuery5 + @pvcQuery6)
        --**************************************************************************
        -- Select the error code and rowcount returned for this step               *
        --**************************************************************************

          SELECT  @lnError    = @@ERROR ,
                  @lnRowCount = @@ROWCOUNT

        --**************************************************************************
        -- Check for errors while updating a  attachment information.              *
        --**************************************************************************

           IF (@lnError <> 0)

           BEGIN
               RAISERROR 1 "Error in procedure scs_cnfg_exec_insert in Executing insert"
               RETURN   1
           END
     END
     -- End of procedure

    RETURN 0
END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************

IF OBJECT_ID('scs_cnfg_exec_insert') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_exec_insert."

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_exec_insert created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_exec_insert TO Facets_Application
GO

GRANT EXECUTE ON scs_cnfg_exec_insert TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_exec_insert TO Sybase_Read_Only 
GO