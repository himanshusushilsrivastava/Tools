/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_check_tbl') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_check_tbl

   PRINT "Procedure scs_cnfg_check_tbl dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_check_tbl                                   *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_check_tbl
(
	@pvcTable VARCHAR(30),
	@pvcDB    VARCHAR(30)
)
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_check_tbl                                  *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Checks for the existence of a table                 *
 **                                                                           *
 ** Input               :   @pvcTable           - Table Name                  *
 **                         @pvcDB              - Database Name               *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : None                                                *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                       1.1 - 08/17/2010 Vasanthan Cognizant                *
 **                       471 Facets & Sybase 15 upgrade(NULL comparison)     *
 ******************************************************************************/
AS
BEGIN

     --**************************************************************************
     --  Declare all variables,using by this procedure                          *
     --**************************************************************************

     DECLARE   @lnRowCount           INT ,      --  Number of records processed
               @lnError              INT        --  @@error

	IF OBJECT_ID(@pvcDB + ".." + @pvcTable) IS NOT NULL  -- Version 1.1 <> changed to IS NOT
	 BEGIN    
		SELECT "Y"
	 END      
	ELSE      
	 BEGIN    
		SELECT "N"
	 END
     
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_check_tbl in checking for table"
           RETURN   1
       END


    -- End of procedure

    RETURN 0


END           
GO
--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************

IF OBJECT_ID('scs_cnfg_check_tbl') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_check_tbl."

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_check_tbl created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_check_tbl TO Facets_Application
GO

GRANT EXECUTE ON scs_cnfg_check_tbl TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_check_tbl TO Sybase_Read_Only 
GO