/******************************************************************************
 * This script file creates the index scsx_cnfg_tables_config                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the index already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS (SELECT  name 
           FROM    sysindexes 
           WHERE   name = 'scsx_cnfg_tables_config')

   BEGIN

      DROP INDEX scst_cnfg_tables_config.scsx_cnfg_tables_config

      PRINT "Index scsx_cnfg_tables_config dropped."

   END
GO

/******************************************************************************
 ** Index Name              : scsx_cnfg_tables_config                         *
 **                                                                           *
 ** Revision History        :                                                 *
 **                         1.0 - 04/09/2008   Cognizant                      *
 **                          Initial version                                  *
 ******************************************************************************/

/******************************************************************************
 * Create index scsx_cnfg_tables_config on table scst_cnfg_tables_config      *
 ******************************************************************************/


CREATE UNIQUE CLUSTERED INDEX scsx_cnfg_tables_config
    ON scst_cnfg_tables_config(TABLE_NAME, DB_NAME)

GO

/******************************************************************************
 * Check for errors in creating index scsx_cnfg_tables_config                 *
 ******************************************************************************/

IF NOT EXISTS (SELECT name 
               FROM   sysindexes 
               WHERE  name = 'scsx_cnfg_tables_config')

   BEGIN

      PRINT "Error creating index scsx_cnfg_tables_config"

   END

ELSE

   BEGIN

      PRINT "Index scsx_cnfg_tables_config created successfully."

   END
   
GO

