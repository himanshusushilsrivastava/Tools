/******************************************************************************
 * This script file creates the index scsx_cnfg_perm_usus_tbl                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the index already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS (SELECT  name 
           FROM    sysindexes 
           WHERE   name = 'scsx_cnfg_perm_usus_tbl')

   BEGIN

      DROP INDEX scst_cnfg_perm_usus_tbl.scsx_cnfg_perm_usus_tbl

      PRINT "Index scsx_cnfg_perm_usus_tbl dropped."

   END
GO

/******************************************************************************
 ** Index Name              : scsx_cnfg_perm_usus_tbl                         *
 **                                                                           *
 ** Revision History        :                                                 *
 **                         1.0 - 04/09/2008   Cognizant                      *
 **                          Initial version                                  *
 ******************************************************************************/

/******************************************************************************
 * Create index scsx_cnfg_perm_usus_tbl on table scst_cnfg_perm_usus_tbl      *
 ******************************************************************************/


CREATE UNIQUE CLUSTERED INDEX scsx_cnfg_perm_usus_tbl
    ON scst_cnfg_perm_usus_tbl(USUS_ID, DB_NAME, TABLE_NAME)

GO

/******************************************************************************
 * Check for errors in creating index scsx_cnfg_perm_usus_tbl                 *
 ******************************************************************************/

IF NOT EXISTS (SELECT name 
               FROM   sysindexes 
               WHERE  name = 'scsx_cnfg_perm_usus_tbl')

   BEGIN

      PRINT "Error creating index scsx_cnfg_perm_usus_tbl"

   END

ELSE

   BEGIN

      PRINT "Index scsx_cnfg_perm_usus_tbl created successfully."

   END
   
GO

