/******************************************************************************
 * If the Trigger already exists, then drop and recreate it.                  *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_tables_config_utrg') IS NOT NULL

    BEGIN

        DROP TRIGGER scst_cnfg_tables_config_utrg

        PRINT 'Dropped trigger scst_cnfg_tables_config_utrg'

    END

GO

/*****************************************************************************
 * Create the Trigger scst_cnfg_tables_config_utrg                            *
 *****************************************************************************/

CREATE TRIGGER scst_cnfg_tables_config_utrg ON scst_cnfg_tables_config
FOR UPDATE
/***************************************************************************
**  NAME:       scst_cnfg_tables_config_utrg
**  AUTHOR:     Cognizant
**  VERSION:    1.0
**  DATE:       04/09/2008
**  FUNCTION:   this trigger is for update on scst_cnfg_tables_config table
**  PARAMETERS: input- NA
**              output- NA
**
**  ERRORS RAISED:
**
**  CREATE/CHANGE LOG:
**  Date                Name            Reason
**  04/09/2008		    Cognizant	    Created	
**
***************************************************************************/
AS
BEGIN

    DELETE FROM scst_cnfg_perm_usus_tbl
 
    FROM    deleted                 dltd,
            scst_cnfg_perm_usus_tbl pmpm
    
    WHERE   pmpm.TABLE_NAME  = dltd.TABLE_NAME

END
GO

/******************************************************************************
 * Check for errors in creating the trigger.                                *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_tables_config_utrg') IS NOT NULL

    BEGIN

        PRINT 'Trigger scst_cnfg_tables_config_utrg created sucessfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating trigger scst_cnfg_tables_config_utrg'

    END

GO