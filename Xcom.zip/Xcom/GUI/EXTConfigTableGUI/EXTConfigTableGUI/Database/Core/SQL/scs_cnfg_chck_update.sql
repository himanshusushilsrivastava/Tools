/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_chck_update') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_chck_update

   PRINT "Procedure scs_cnfg_chck_update dropped."

 END
GO
/*****************************************************************************
 * Create the Procedure scs_cnfg_chck_update                                 *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_chck_update
(
    @pvcTable       VARCHAR(30)        , 
    @pvcDB          VARCHAR(30)  
) 
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_chck_update                                *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Checks for back-end read access                     *
 **                                                                           *
 ** Input               :   @pvcTable                                         *
 **                         @pvcDB                                            *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. sysusers                                         *
 **                       2. CER_USGU_USERGRP_U                               *
 **                       3. spt_values                                       *
 **                       4. sysprotects                                      *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/

AS

BEGIN
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error

    DECLARE @lvcUser    VARCHAR(10), 
            @lnId       INT        ,  
            @lvcQuery   VARCHAR(2048) 

    SELECT  @lvcUser    = SUSER_NAME()
    SELECT  @lnId       = OBJECT_ID(@pvcDB + ".." + @pvcTable) 

    --**************************************************************************
    -- Creating temp tables                                                    *
    --**************************************************************************    
    CREATE TABLE #scst_cnfg_chck_perm
    (
        PERM_UPD    CHAR(1)
    )
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in create table #scst_perm_check"
       RETURN   1
    END

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************    
    CREATE TABLE #scst_cnfg_uid
    (
        uid    INT
    )
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in create table #scst_cnfg_uid"
       RETURN   1
    END

    INSERT INTO #scst_cnfg_chck_perm
    (
        PERM_UPD
    )
    VALUES
    (
        'N'
    )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END
    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END

    SELECT @lvcQuery = (    " INSERT INTO #scst_cnfg_uid (uid)         "        +
                            " SELECT uid FROM " + @pvcDB + "..sysusers "        +
                            " WHERE  name ='" + @lvcUser + "'          "        +
                            " OR  name ='public'                       "        +
                            " OR name IN  " +
                            "          (                                     "  +
                            "              SELECT USGR_USUS_ID               "  +
                            "              FROM   CER_USGU_USERGRP_U         "  +
                            "              WHERE  USUS_ID='" + @lvcUser + "' "  +
                            "          )                                     " 
                       )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END


    EXEC (@lvcQuery)

        --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END



    SELECT @lvcQuery = (    " INSERT INTO #scst_cnfg_uid (uid)          "      +
                            " SELECT gid FROM " + @pvcDB + "..sysusers  "      +
                            " WHERE  name = '" + @lvcUser + "'          "      +
                            " OR name IN  "                                    +
                            "          (                                     " +
                            "              SELECT USGR_USUS_ID               " +
                            "              FROM   CER_USGU_USERGRP_U         " +
                            "              WHERE  USUS_ID='" + @lvcUser + "' " +
                            "          )                                     " 
                       )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END



    EXEC (@lvcQuery)

        --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in inserting value into the temporary table"
       RETURN   1
    END


/*****************************************************************************
 * Create the Procedure scs_cnfg_chck_bknd_select                            *
 *****************************************************************************/

    SELECT @lvcQuery = (    "UPDATE #scst_cnfg_chck_perm                     " +
                            "SET PERM_UPD = 'Y'                               " +
                            "FROM  " + @pvcDB + "..sysprotects  p,           " +
                            "      master.dbo.spt_values        v,           " +
                            "      " + @pvcDB + "..sysusers     u ,          " +
                            "      #scst_cnfg_chck_perm         chck ,       " +
                            "      #scst_cnfg_uid               uid          " + 
                            "WHERE p.uid          = u.uid                    " +
                            "  AND p.action       = v.number                 " +
                            "  AND p.protecttype  = 1                        " +
                            "  AND v.type         = 'T'                      " +
                            "  AND u.uid           = uid.uid                 " +
                            "  AND v.name = 'Update'                         " +
                            "  AND p.id   = " + CONVERT(VARCHAR, @lnId)        +
                            "  AND chck.PERM_UPD = 'N'                       "
                        )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END
    
    EXEC (@lvcQuery)
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in executing the dynamic query"
       RETURN   1
    END

/*****************************************************************************
 * Create the Query                                                          *
 *****************************************************************************/

    SELECT @lvcQuery = (    "UPDATE #scst_cnfg_chck_perm                 " +
                            "SET PERM_UPD = 'G'                           " +
                            "FROM  " + @pvcDB + "..sysprotects  p,       " +
                            "      master.dbo.spt_values        v,       " +
                            "      " + @pvcDB + "..sysusers     u ,      " +
                            "      #scst_cnfg_chck_perm         chck     " +
                            "WHERE p.uid          = u.uid                " +
                            "  AND p.action       = v.number             " +
                            "  AND p.protecttype  = 2                    " +
                            "  AND v.type         = 'T'                  " +
                            "  AND u.name in                             " +
                            "      (                                     " +
                            "          SELECT USGR_USUS_ID               " +
                            "          FROM   CER_USGU_USERGRP_U         " +
                            "          WHERE  USUS_ID='" + @lvcUser + "' " +
                            "      )                                     " +
                            "  AND v.name = 'Update'                     " +
                            "  AND p.id   = " + CONVERT(VARCHAR, @lnId)    +
                            "  AND chck.PERM_UPD = 'F'                    "
                        )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END
    
    EXEC (@lvcQuery)
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in executing the dynamic query"
       RETURN   1
    END


/*****************************************************************************
 * Create the Query                                                          *
 *****************************************************************************/

    SELECT @lvcQuery = (    "UPDATE #scst_cnfg_chck_perm                 " +
                            "SET PERM_UPD = 'U'                           " +
                            "FROM  " + @pvcDB + "..sysprotects  p,       " +
                            "      master.dbo.spt_values        v,       " +
                            "      " + @pvcDB + "..sysusers     u ,      " +
                            "      #scst_cnfg_chck_perm         chck     " +
                            "WHERE p.uid          = u.uid                " +
                            "  AND p.action       = v.number             " +
                            "  AND p.protecttype  = 2                    " +
                            "  AND v.type         = 'T'                  " +
                            "  AND u.name         = '"+ @lvcUser +"'     " +
                            "  AND v.name         = 'Update'             " +
                            "  AND p.id           = " + CONVERT(VARCHAR, @lnId) +
                            "  AND chck.PERM_UPD   = 'F'                  "
                        )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END
    
    EXEC (@lvcQuery)
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in executing the dynamic query"
       RETURN   1
    END


/*****************************************************************************
 * Create the Query                                                          *
 *****************************************************************************/

    SELECT @lvcQuery = (    "UPDATE #scst_cnfg_chck_perm                 " +
                            "SET PERM_UPD = 'Y'                           " +
                            "FROM  " + @pvcDB + "..sysprotects  p,       " +
                            "      master.dbo.spt_values        v,       " +
                            "      " + @pvcDB + "..sysusers     u ,      " +
                            "      #scst_cnfg_chck_perm         chck     " +
                            "WHERE p.uid          = u.uid                " +
                            "  AND p.action       = v.number             " +
                            "  AND p.protecttype  = 1                    " +
                            "  AND v.type         = 'T'                  " +
                            "  AND u.name         = '"+ @lvcUser +"'     " +
                            "  AND v.name         = 'Update'             " +
                            "  AND p.id           = " + CONVERT(VARCHAR, @lnId) +
                            "  AND chck.PERM_UPD   = 'G'                  "
                        )

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END
    
    EXEC (@lvcQuery)
    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in executing the dynamic query"
       RETURN   1
    END

    
    UPDATE  #scst_cnfg_chck_perm
    SET     PERM_UPD = 'Y'
    WHERE   PERM_UPD = 'F'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END
    
    UPDATE  #scst_cnfg_chck_perm
    SET     PERM_UPD = 'N'
    WHERE   PERM_UPD = 'G'
       OR   PERM_UPD = 'U'

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

    SELECT  @lnError    = @@ERROR ,
            @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************
    
    IF (@lnError <> 0)

    BEGIN
       RAISERROR 1 "Error in procedure scs_cnfg_chck_update in creating the dynamic query"
       RETURN   1
    END

    SELECT PERM_UPD FROM #scst_cnfg_chck_perm


    -- End of procedure
    RETURN 0
END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************
IF OBJECT_ID('scs_cnfg_chck_update') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_chck_update"

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_chck_update created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_chck_update TO Facets_Application

GO
GRANT EXECUTE ON scs_cnfg_chck_update TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_chck_update TO Sybase_Read_Only 
GO


