/******************************************************************************
 * If the Stored procedure already exists, then drop and recreate it.         *
 ******************************************************************************/
IF OBJECT_ID('scs_cnfg_db_all_select') IS NOT NULL

 BEGIN

   DROP PROC scs_cnfg_db_all_select

   PRINT "Procedure scs_cnfg_db_all_select dropped."

 END
GO

/*****************************************************************************
 * Create the Procedure scs_cnfg_db_all_select                               *
 *****************************************************************************/
CREATE PROCEDURE scs_cnfg_db_all_select
/******************************************************************************
 **                                                                           *
 ** Procedure Name      : scs_cnfg_db_all_select                              *
 **                                                                           *
 **                                                                           *
 ** Purpose             : Fetches the DB list from                            *
 **                       fakpfstage..scst_cnfg_dbdb_database.                *
 ** Input               :   None                                              *
 **                                                                           *
 ** Output              :   None                                              *
 **                                                                           *
 **                                                                           *
 ** Return Values       : 0 if successful                                     *
 **                       Sybase @@error in case of a failure                 *
 **                                                                           *
 ** Dependencies                                                              *
 **     Procedures      : None                                                *
 **                                                                           *
 **     Tables          : 1. fakpfstage..scst_cnfg_dbdb_database              *
 **                                                                           *
 ** Revision History    : 1.0 - 04/09/2008 Cognizant Offshore                 *
 **                       Initial version                                     *
 **                                                                           *
 ******************************************************************************/
AS

BEGIN
     
     
    --**************************************************************************
    --  Declare all variables,using by this procedure                          *
    --**************************************************************************

    DECLARE   @lnRowCount           INT ,      --  Number of records processed
              @lnError              INT        --  @@error


    SELECT  DB_NAME 
    
    FROM    fakpfstage..scst_cnfg_dbdb_database
    
    GROUP BY  DB_NAME

    --**************************************************************************
    -- Select the error code and rowcount returned for this step               *
    --**************************************************************************

      SELECT  @lnError    = @@ERROR ,
              @lnRowCount = @@ROWCOUNT

    --**************************************************************************
    -- Check for errors while updating a  attachment information.              *
    --**************************************************************************

       IF (@lnError <> 0)

       BEGIN
           RAISERROR 1 "Error in procedure scs_cnfg_db_all_select in select"
           RETURN   1
       END


        
    -- End of procedure

    RETURN 0
END

GO

--*******************************************************************************
--* Check for errors in creating the procedure.                                 *
--*******************************************************************************

IF OBJECT_ID('scs_cnfg_db_all_select') IS NULL

   BEGIN

      PRINT "Error creating the procedure scs_cnfg_db_all_select."

   END

ELSE

   BEGIN

      PRINT "Procedure scs_cnfg_db_all_select created successfully."

   END

GO

/******************************************************************************
 * Grant permission to procedure                                              *
 ******************************************************************************/

GRANT EXECUTE ON scs_cnfg_db_all_select TO Facets_Application
GO
 
GRANT EXECUTE ON scs_cnfg_db_all_select TO Facets_Load 
GO
  
GRANT EXECUTE ON scs_cnfg_db_all_select TO Sybase_Read_Only 
GO
