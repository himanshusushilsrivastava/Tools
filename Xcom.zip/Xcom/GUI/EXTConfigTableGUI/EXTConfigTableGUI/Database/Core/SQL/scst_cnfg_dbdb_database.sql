/******************************************************************************
 * This script file creates the table scst_cnfg_dbdb_database                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_dbdb_database') IS NOT NULL

    BEGIN

        DROP TABLE scst_cnfg_dbdb_database

        PRINT 'Dropped table scst_cnfg_dbdb_database'

    END

GO

/******************************************************************************
 **                                                                           *
 ** Table Name              : scst_cnfg_dbdb_database                         *
 **                                                                           *
 ** Purpose                 : Holds list of all databases.                    *
 **                                                                           *
 ** Revision History        : 1.0 - 04/09/2008  Cognizant Offshore            *
 **                           Initial version                                 *
 **                                                                           *
 ******************************************************************************/

CREATE TABLE scst_cnfg_dbdb_database
(
    DB_NAME     VARCHAR(30)     NOT NULL
)
LOCK DATAROWS
GO


/******************************************************************************
 * Grant permission                                                           *
 ******************************************************************************/
 
GRANT DELETE ON scst_cnfg_dbdb_database TO Facets_Application
GO
 
GRANT INSERT ON scst_cnfg_dbdb_database TO Facets_Application
GO
 
GRANT REFERENCES ON scst_cnfg_dbdb_database TO Facets_Application
GO
 
GRANT SELECT ON scst_cnfg_dbdb_database TO Facets_Application
GO
 
GRANT UPDATE ON scst_cnfg_dbdb_database TO Facets_Application
GO

/******************************************************************************
 * Check for errors in creating the table scst_cnfg_dbdb_database             *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_dbdb_database') IS NOT NULL

    BEGIN

        PRINT 'Table scst_cnfg_dbdb_database created successfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating table scst_cnfg_dbdb_database'

    END

GO