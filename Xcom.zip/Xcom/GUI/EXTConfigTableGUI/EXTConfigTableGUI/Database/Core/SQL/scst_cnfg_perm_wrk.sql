/******************************************************************************
 * This script file creates the table scst_cnfg_perm_wrk                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_perm_wrk') IS NOT NULL

    BEGIN

        DROP TABLE scst_cnfg_perm_wrk

        PRINT 'Dropped table scst_cnfg_perm_wrk'

    END

GO

/******************************************************************************
 **                                                                           *
 ** Table Name              : scst_cnfg_perm_wrk                              *
 **                                                                           *
 ** Purpose                 : Work table for holding the table name and the   *
 **                           user permissions on the table.                  *
 **                                                                           *
 **                                                                           *
 ** Revision History        : 1.0 - 04/09/2008  Cognizant Offshore            *
 **                           Initial version                                 *
 **                                                                           *
 ******************************************************************************/

CREATE TABLE scst_cnfg_perm_wrk
(
    TABLE_NAME  VARCHAR(30)     NOT NULL,
    DB_NAME     VARCHAR(30)     NOT NULL,
    PERM_INS    CHAR(1)         NOT NULL,
    PERM_UPD    CHAR(1)         NOT NULL,
)
LOCK DATAROWS
GO

/******************************************************************************
 * Grant permission                                                           *
 ******************************************************************************/
 
GRANT DELETE ON scst_cnfg_perm_wrk TO Facets_Application
GO
 
GRANT INSERT ON scst_cnfg_perm_wrk TO Facets_Application
GO
 
GRANT REFERENCES ON scst_cnfg_perm_wrk TO Facets_Application
GO
 
GRANT SELECT ON scst_cnfg_perm_wrk TO Facets_Application
GO
 
GRANT UPDATE ON scst_cnfg_perm_wrk TO Facets_Application
GO

/******************************************************************************
 * Check for errors in creating the table scst_cnfg_perm_wrk                  *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_perm_wrk') IS NOT NULL

    BEGIN

        PRINT 'Table scst_cnfg_perm_wrk created successfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating table scst_cnfg_perm_wrk'

    END

GO