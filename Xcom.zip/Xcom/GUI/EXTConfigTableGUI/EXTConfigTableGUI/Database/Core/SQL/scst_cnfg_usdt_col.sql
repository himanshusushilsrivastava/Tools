/******************************************************************************
 * This script file creates the table scst_cnfg_usdt_col                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_usdt_col') IS NOT NULL

    BEGIN

        DROP TABLE scst_cnfg_usdt_col

        PRINT 'Dropped table scst_cnfg_usdt_col'

    END

GO

/******************************************************************************
 **                                                                           *
 ** Table Name              : scst_cnfg_usdt_col                              *
 **                                                                           *
 ** Purpose                 : Holds list of all the User Id and Create date   *
 **                           field column names                              *
 **                                                                           *
 **                                                                           *
 ** Revision History        : 1.0 - 04/09/2008  Cognizant Offshore            *
 **                           Initial version                                 *
 **                                                                           *
 ******************************************************************************/

CREATE TABLE scst_cnfg_usdt_col
(
    TABLE_NAME          VARCHAR(30)     NOT NULL ,
    USUS_ID_COL_NAME    VARCHAR(30)     NULL     ,
    CREATE_DT_COL_NAME  VARCHAR(30)     NULL
)
LOCK DATAROWS
GO

/******************************************************************************
 * Grant permission                                                           *
 ******************************************************************************/
 
GRANT DELETE ON scst_cnfg_usdt_col TO Facets_Application
GO
 
GRANT INSERT ON scst_cnfg_usdt_col TO Facets_Application
GO
 
GRANT REFERENCES ON scst_cnfg_usdt_col TO Facets_Application
GO
 
GRANT SELECT ON scst_cnfg_usdt_col TO Facets_Application
GO
 
GRANT UPDATE ON scst_cnfg_usdt_col TO Facets_Application
GO

/******************************************************************************
 * Check for errors in creating the table scst_cnfg_usdt_col                  *
 ******************************************************************************/

IF OBJECT_ID('scst_cnfg_usdt_col') IS NOT NULL

    BEGIN

        PRINT 'Table scst_cnfg_usdt_col created successfully'

    END

ELSE

    BEGIN

        PRINT 'Error creating table scst_cnfg_usdt_col'

    END

GO