/******************************************************************************
 * This script file creates the index scsx_cnfg_perm_wrk                      *
 ******************************************************************************/

/******************************************************************************
 * Check if the index already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS (SELECT  name 
           FROM    sysindexes 
           WHERE   name = 'scsx_cnfg_perm_wrk')

   BEGIN

      DROP INDEX scst_cnfg_perm_wrk.scsx_cnfg_perm_wrk

      PRINT "Index scsx_cnfg_perm_wrk dropped."

   END
GO

/******************************************************************************
 ** Index Name              : scsx_cnfg_perm_wrk                              *
 **                                                                           *
 ** Revision History        :                                                 *
 **                         1.0 - 04/09/2008   Cognizant                      *
 **                          Initial version                                  *
 ******************************************************************************/

/******************************************************************************
 * Create index scsx_cnfg_perm_wrk on table scst_cnfg_perm_wrk                *
 ******************************************************************************/


CREATE UNIQUE CLUSTERED INDEX scsx_cnfg_perm_wrk
    ON scst_cnfg_perm_wrk(TABLE_NAME)

GO

/******************************************************************************
 * Check for errors in creating index scsx_cnfg_perm_wrk                      *
 ******************************************************************************/

IF NOT EXISTS (SELECT name 
               FROM   sysindexes 
               WHERE  name = 'scsx_cnfg_perm_wrk')

   BEGIN

      PRINT "Error creating index scsx_cnfg_perm_wrk"

   END

ELSE

   BEGIN

      PRINT "Index scsx_cnfg_perm_wrk created successfully."

   END
   
GO

