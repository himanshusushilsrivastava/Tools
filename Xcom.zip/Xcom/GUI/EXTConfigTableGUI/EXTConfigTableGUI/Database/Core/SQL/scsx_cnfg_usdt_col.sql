/******************************************************************************
 * This script file creates the index scsx_cnfg_usdt_col                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the index already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS (SELECT  name 
           FROM    sysindexes 
           WHERE   name = 'scsx_cnfg_usdt_col')

   BEGIN

      DROP INDEX scst_cnfg_usdt_col.scsx_cnfg_usdt_col

      PRINT "Index scsx_cnfg_usdt_col dropped."

   END
GO

/******************************************************************************
 ** Index Name              : scsx_cnfg_usdt_col                         *
 **                                                                           *
 ** Revision History        :                                                 *
 **                         1.0 - 04/09/2008   Cognizant                      *
 **                          Initial version                                  *
 ******************************************************************************/

/******************************************************************************
 * Create index scsx_cnfg_usdt_col on table scst_cnfg_usdt_col      *
 ******************************************************************************/


CREATE UNIQUE CLUSTERED INDEX scsx_cnfg_usdt_col
    ON scst_cnfg_usdt_col(TABLE_NAME, USUS_ID_COL_NAME, CREATE_DT_COL_NAME)

GO

/******************************************************************************
 * Check for errors in creating index scsx_cnfg_usdt_col                 *
 ******************************************************************************/

IF NOT EXISTS (SELECT name 
               FROM   sysindexes 
               WHERE  name = 'scsx_cnfg_usdt_col')

   BEGIN

      PRINT "Error creating index scsx_cnfg_usdt_col"

   END

ELSE

   BEGIN

      PRINT "Index scsx_cnfg_usdt_col created successfully."

   END
   
GO

