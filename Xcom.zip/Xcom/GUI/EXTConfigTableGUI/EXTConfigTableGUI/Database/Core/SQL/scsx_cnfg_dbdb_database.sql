/******************************************************************************
 * This script file creates the index scsx_cnfg_dbdb_database                 *
 ******************************************************************************/

/******************************************************************************
 * Check if the index already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS (SELECT  name 
           FROM    sysindexes 
           WHERE   name = 'scsx_cnfg_dbdb_database')

   BEGIN

      DROP INDEX scst_cnfg_dbdb_database.scsx_cnfg_dbdb_database

      PRINT "Index scsx_cnfg_dbdb_database dropped."

   END
GO

/******************************************************************************
 ** Index Name              : scsx_cnfg_dbdb_database                         *
 **                                                                           *
 ** Revision History        :                                                 *
 **                         1.0 - 04/09/2008   Cognizant                      *
 **                          Initial version                                  *
 ******************************************************************************/

/******************************************************************************
 * Create index scsx_cnfg_dbdb_database on table scst_cnfg_dbdb_database      *
 ******************************************************************************/


CREATE UNIQUE CLUSTERED INDEX scsx_cnfg_dbdb_database
    ON scst_cnfg_dbdb_database(DB_NAME)

GO

/******************************************************************************
 * Check for errors in creating index scsx_cnfg_dbdb_database                 *
 ******************************************************************************/

IF NOT EXISTS (SELECT name 
               FROM   sysindexes 
               WHERE  name = 'scsx_cnfg_dbdb_database')

   BEGIN

      PRINT "Error creating index scsx_cnfg_dbdb_database"

   END

ELSE

   BEGIN

      PRINT "Index scsx_cnfg_dbdb_database created successfully."

   END
   
GO

