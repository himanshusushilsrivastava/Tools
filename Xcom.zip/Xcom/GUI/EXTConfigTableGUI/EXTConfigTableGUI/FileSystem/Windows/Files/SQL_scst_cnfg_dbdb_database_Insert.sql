/******************************************************************************
' NAME               : Database_Name_Insert                                   '
' FUNCTION           : Inserts the database name into scst_cnfg_dbdb_database '
'                                                                             '
' CREATE/CHANGE LOG  :                                                        '
' Sr.no  Ver.No  Date         Name                 Reason                     '
'-----------------------------------------------------------------------------'
' 1      1.0     04/09/2008   Cognizant            Initial Version            '
'                                                                             '
******************************************************************************/
/***********************************************************************
 * Deleting fakpfpr0 database                                          *
 ***********************************************************************/
DELETE FROM scst_cnfg_dbdb_database
WHERE DB_NAME IN ('fakpfpr0', 'fakpfstage', 'tempdb')

GO

/***********************************************************************
 * Inserting fakpfpr0 database                                         *
 ***********************************************************************/
INSERT INTO scst_cnfg_dbdb_database
(
    DB_NAME
)
VALUES
(
    'fakpfpr0'
)
GO
/***********************************************************************
 * Inserting fakpfstage database                                       *
 ***********************************************************************/
INSERT INTO scst_cnfg_dbdb_database
(
    DB_NAME
)
VALUES
(
    'fakpfstage'
)
GO
/***********************************************************************
 * Inserting tempdb database                                           *
 ***********************************************************************/
INSERT INTO scst_cnfg_dbdb_database
(
    DB_NAME
)
VALUES
(
    'tempdb'
)
GO