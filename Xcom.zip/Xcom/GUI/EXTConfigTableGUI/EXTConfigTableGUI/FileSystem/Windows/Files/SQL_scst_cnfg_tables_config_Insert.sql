/******************************************************************************
' NAME               : Master_Table_Insert                                    '
' FUNCTION           : Inserts the master table and table storing user id and '
'                      date columns into the master table                     '
'                                                                             '
' CREATE/CHANGE LOG  :                                                        '
' Sr.no  Ver.No  Date         Name                 Reason                     '
'-----------------------------------------------------------------------------'
' 1      1.0     04/09/2008   Cognizant            Initial Version            '
'                                                                             '
******************************************************************************/
/***********************************************************************
 * Deleting Master Table details into Master Table List                *
 ***********************************************************************/

DELETE FROM scst_cnfg_tables_config
WHERE   TABLE_NAME  = 'scst_cnfg_tables_config'
  AND   DB_NAME     = 'fakpfstage'
GO

/***********************************************************************
 * Deleting Master Table details into Master Table List                *
 ***********************************************************************/
DELETE FROM scst_cnfg_tables_config
WHERE   TABLE_NAME  = 'scst_cnfg_usdt_col'
  AND   DB_NAME     = 'fakpfstage'
GO

/***********************************************************************
 * Inserting Master Table details into Master Table List               *
 ***********************************************************************/

INSERT INTO scst_cnfg_tables_config
(
    TABLE_NAME  ,
    DB_NAME     
)
VALUES
(
    'scst_cnfg_tables_config',
    'fakpfstage'
)
GO


/***********************************************************************
 * Inserting Master Table details into Master Table List               *
 ***********************************************************************/
INSERT INTO scst_cnfg_tables_config
(
    TABLE_NAME  ,
    DB_NAME     
)
VALUES
(
    'scst_cnfg_usdt_col',
    'fakpfstage'
)
GO