Public Class clsDB
    '========================================================================================='
    '   Name : clsDB
    '
    '   Description :   This class stores all the data related to a DB.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Properties/Variables"

    Private strDBName As String
    Private intTableCount As Integer
    Private Table() As clsTable

    '---------------------------------------------------------------------------------------
    ' Name : DBName
    '
    '---------------------------------------------------------------------------------------
    Public Property DBName() As String
        Get
            Return strDBName
        End Get
        Set(ByVal value As String)
            strDBName = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Tables
    '
    '---------------------------------------------------------------------------------------
    Public Property Tables(ByVal pintIndex As Integer) As clsTable
        Get
            Return Table(pintIndex)
        End Get
        Set(ByVal value As clsTable)
            Table(pintIndex) = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : TableCount
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property TableCount() As Integer
        Get
            Return intTableCount
        End Get
    End Property

#End Region

#Region "Private Method"
    '---------------------------------------------------------------------------------------
    ' Name : Init
    '           Initializes the objects.
    ' Parameters :
    ' pintCount
    '---------------------------------------------------------------------------------------
    Public Sub Init(ByVal pintCount As Integer)
        Dim intCount As Integer
        ReDim Table(pintCount)
        intCount = 0
        While intCount < pintCount
            Table(intCount) = New clsTable
            intCount = intCount + 1
        End While

        intTableCount = pintCount
    End Sub

#End Region

End Class
