Option Explicit On

Public Class clsDBHandler
    '========================================================================================='
    '   Name : clsDBHandler
    '
    '   Description : Wrapper class for ADODB connection object
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

    ' Singleton reference to the DBHandler
    Private Shared dbHandler As New clsDBHandler

    Private Sub New()
        ' Singleton class
    End Sub


    '---------------------------------------------------------------------------------------
    '
    ' Name : GetDBHandler - Static funtion to return the DBHanlder reference
    '
    ' Return value : clsDBHandler
    '---------------------------------------------------------------------------------------
    Public Shared Function GetDBHandler() As clsDBHandler
        Return dbHandler
    End Function

    'Connection object
    Private dbConn As ADODB.Connection

    'Connection String
    Public strConnString As String

    '---------------------------------------------------------------------------------------
    ' Name : ConnectionString - Sets the connection string
    '
    '---------------------------------------------------------------------------------------
    Public WriteOnly Property ConnectionString() As String
        Set(ByVal Value As String)
            strConnString = Value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Init - Procedure initializes the database connection
    '
    '---------------------------------------------------------------------------------------
    Public Sub Init()
        dbConn = New ADODB.Connection
        dbConn.Open(strConnString)
    End Sub
    '---------------------------------------------------------------------------------------
    '   GetCommandObject
    '   -  Returns a Text Script command object
    '
    '    Parameters: - spQuery,Column name,Facetsdata
    '
    '   Return Value: ADODB.Command.
    '---------------------------------------------------------------------------------------


    Public Function GetCommandObject(ByVal spQuery As String) As ADODB.Command
        Dim dbCmd As New ADODB.Command

        dbCmd.CommandText = spQuery
        dbCmd.CommandType = ADODB.CommandTypeEnum.adCmdText
        dbCmd.ActiveConnection = dbConn

        Return dbCmd

    End Function

    '---------------------------------------------------------------------------------------
    '   GetCommandObject
    '   -  Returns a stores procedure command object
    '
    '    Parameters: - spQuery,Column name,Facetsdata
    '
    '   Return Value: ADODB.Command.
    '---------------------------------------------------------------------------------------


    Public Function GetSPCommandObject(ByVal spName As String) As ADODB.Command
        Dim dbCmd As New ADODB.Command

        dbCmd.CommandText = spName
        dbCmd.CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
        dbCmd.ActiveConnection = dbConn

        Return dbCmd

    End Function


    '---------------------------------------------------------------------------------------
    '   GetRecordSetObject
    '   -  Returns a record set object
    '
    '    Parameters: -
    '
    '   Return Value: ADODB.Recordset
    '---------------------------------------------------------------------------------------


    Public Function GetRecordSetObject() As ADODB.Recordset

        Dim dbRecordSet As ADODB.Recordset
        dbRecordSet = New ADODB.Recordset

        dbRecordSet.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        dbRecordSet.CursorType = ADODB.CursorTypeEnum.adOpenStatic
        dbRecordSet.LockType = ADODB.LockTypeEnum.adLockReadOnly

        Return dbRecordSet

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : Finalize - On destruction of class closes the connection object if open
    '
    '---------------------------------------------------------------------------------------
    Protected Overrides Sub Finalize()
        Try
            If Not dbConn Is Nothing Then
                If dbConn.State = ADODB.ObjectStateEnum.adStateOpen Then 'adStateOpen 
                    dbConn.Close()
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    '---------------------------------------------------------------------------------------
    '   BeginTransaction
    '   -  Begins Transaction
    '
    '    Parameters: -
    '
    '---------------------------------------------------------------------------------------

    Public Sub BeginTransaction()
        'Chris
        'dbConn.BeginTrans()
    End Sub

    '---------------------------------------------------------------------------------------
    '   CommitTransaction
    '   -  Commits Transaction
    '
    '    Parameters: -
    '
    '---------------------------------------------------------------------------------------

    Public Sub CommitTransaction()
        'Chris
        'dbConn.CommitTrans()
    End Sub

    '---------------------------------------------------------------------------------------
    '   RollsbackTransaction
    '   -  Rollsback Transaction
    '
    '    Parameters: -
    '
    '---------------------------------------------------------------------------------------
    Public Sub RollbackTransaction()
        'Chris
        'dbConn.RollbackTrans()
    End Sub

End Class
