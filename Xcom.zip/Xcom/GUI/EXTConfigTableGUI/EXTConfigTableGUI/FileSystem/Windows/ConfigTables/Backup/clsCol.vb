Public Class clsCol
    '========================================================================================='
    '   Name : clsCol
    '
    '   Description :   This class stores all the data related to a column.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Properties/Variables"

    Private strColName As String
    Private strColType As String
    Private intColLen As Integer
    Private boolNull As Boolean
    Private boolPK As Boolean
    Private boolIden As Boolean
    Private intScale As Integer

    '---------------------------------------------------------------------------------------
    ' Name : ColName
    '
    '---------------------------------------------------------------------------------------
    Public Property ColName() As String
        Get
            Return strColName
        End Get
        Set(ByVal value As String)
            strColName = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Type
    '
    '---------------------------------------------------------------------------------------
    Public Property Type() As String
        Get
            Return strColType
        End Get
        Set(ByVal value As String)
            strColType = value
        End Set
    End Property


    '---------------------------------------------------------------------------------------
    ' Name : Length
    '
    '---------------------------------------------------------------------------------------
    Public Property Length() As Integer
        Get
            Return intColLen
        End Get
        Set(ByVal value As Integer)
            intColLen = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Scale
    '
    '---------------------------------------------------------------------------------------
    Public Property Scale() As Integer
        Get
            Return intScale
        End Get
        Set(ByVal value As Integer)
            intScale = value
        End Set
    End Property


    '---------------------------------------------------------------------------------------
    ' Name : Nullable
    '
    '---------------------------------------------------------------------------------------
    Public Property Nullable() As Boolean
        Get
            Return boolNull
        End Get
        Set(ByVal value As Boolean)
            boolNull = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Key
    '
    '---------------------------------------------------------------------------------------
    Public Property Key() As Boolean
        Get
            Return boolPK
        End Get
        Set(ByVal value As Boolean)
            boolPK = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Identity
    '
    '---------------------------------------------------------------------------------------
    Public Property Identity() As Boolean
        Get
            Return boolIden
        End Get
        Set(ByVal value As Boolean)
            boolIden = value
        End Set
    End Property

#End Region

End Class
