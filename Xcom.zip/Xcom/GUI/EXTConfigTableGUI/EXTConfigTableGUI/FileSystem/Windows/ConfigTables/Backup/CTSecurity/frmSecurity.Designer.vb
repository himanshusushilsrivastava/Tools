<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSecurity
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tabSecurity = New System.Windows.Forms.TabControl
        Me.tbpView = New System.Windows.Forms.TabPage
        Me.grdSecurityView = New System.Windows.Forms.DataGridView
        Me.tbpConfigure = New System.Windows.Forms.TabPage
        Me.cmdConfigure = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.lblDb = New System.Windows.Forms.Label
        Me.cboDatabase = New System.Windows.Forms.ComboBox
        Me.lblTable = New System.Windows.Forms.Label
        Me.cmdPopTable = New System.Windows.Forms.Button
        Me.cmdPushTable = New System.Windows.Forms.Button
        Me.lstTablesSelect = New System.Windows.Forms.ListBox
        Me.lstTablesAll = New System.Windows.Forms.ListBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cboUserType = New System.Windows.Forms.ComboBox
        Me.cmdPopUser = New System.Windows.Forms.Button
        Me.cmdPushUser = New System.Windows.Forms.Button
        Me.lstUserAll = New System.Windows.Forms.ListBox
        Me.lstUserSelect = New System.Windows.Forms.ListBox
        Me.lblID = New System.Windows.Forms.Label
        Me.lblUserType = New System.Windows.Forms.Label
        Me.tabSecurity.SuspendLayout()
        Me.tbpView.SuspendLayout()
        CType(Me.grdSecurityView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpConfigure.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabSecurity
        '
        Me.tabSecurity.Controls.Add(Me.tbpView)
        Me.tabSecurity.Controls.Add(Me.tbpConfigure)
        Me.tabSecurity.Location = New System.Drawing.Point(1, 1)
        Me.tabSecurity.Name = "tabSecurity"
        Me.tabSecurity.SelectedIndex = 0
        Me.tabSecurity.Size = New System.Drawing.Size(409, 469)
        Me.tabSecurity.TabIndex = 0
        '
        'tbpView
        '
        Me.tbpView.BackColor = System.Drawing.Color.Transparent
        Me.tbpView.Controls.Add(Me.grdSecurityView)
        Me.tbpView.Location = New System.Drawing.Point(4, 22)
        Me.tbpView.Name = "tbpView"
        Me.tbpView.Padding = New System.Windows.Forms.Padding(3)
        Me.tbpView.Size = New System.Drawing.Size(401, 443)
        Me.tbpView.TabIndex = 1
        Me.tbpView.Text = "View"
        Me.tbpView.UseVisualStyleBackColor = True
        '
        'grdSecurityView
        '
        Me.grdSecurityView.AllowUserToAddRows = False
        Me.grdSecurityView.AllowUserToDeleteRows = False
        Me.grdSecurityView.AllowUserToResizeRows = False
        Me.grdSecurityView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdSecurityView.BackgroundColor = System.Drawing.Color.Silver
        Me.grdSecurityView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdSecurityView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.grdSecurityView.Location = New System.Drawing.Point(5, 3)
        Me.grdSecurityView.Name = "grdSecurityView"
        Me.grdSecurityView.RowHeadersVisible = False
        Me.grdSecurityView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdSecurityView.Size = New System.Drawing.Size(392, 437)
        Me.grdSecurityView.TabIndex = 0
        '
        'tbpConfigure
        '
        Me.tbpConfigure.BackColor = System.Drawing.Color.White
        Me.tbpConfigure.Controls.Add(Me.cmdConfigure)
        Me.tbpConfigure.Controls.Add(Me.Panel2)
        Me.tbpConfigure.Controls.Add(Me.Panel1)
        Me.tbpConfigure.Location = New System.Drawing.Point(4, 22)
        Me.tbpConfigure.Name = "tbpConfigure"
        Me.tbpConfigure.Padding = New System.Windows.Forms.Padding(3)
        Me.tbpConfigure.Size = New System.Drawing.Size(401, 443)
        Me.tbpConfigure.TabIndex = 0
        Me.tbpConfigure.Text = "Configure"
        '
        'cmdConfigure
        '
        Me.cmdConfigure.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cmdConfigure.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdConfigure.Location = New System.Drawing.Point(318, 414)
        Me.cmdConfigure.Name = "cmdConfigure"
        Me.cmdConfigure.Size = New System.Drawing.Size(75, 23)
        Me.cmdConfigure.TabIndex = 45
        Me.cmdConfigure.Text = "Configure"
        Me.cmdConfigure.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lblDb)
        Me.Panel2.Controls.Add(Me.cboDatabase)
        Me.Panel2.Controls.Add(Me.lblTable)
        Me.Panel2.Controls.Add(Me.cmdPopTable)
        Me.Panel2.Controls.Add(Me.cmdPushTable)
        Me.Panel2.Controls.Add(Me.lstTablesSelect)
        Me.Panel2.Controls.Add(Me.lstTablesAll)
        Me.Panel2.Location = New System.Drawing.Point(2, 201)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(396, 208)
        Me.Panel2.TabIndex = 44
        '
        'lblDb
        '
        Me.lblDb.AutoSize = True
        Me.lblDb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDb.Location = New System.Drawing.Point(6, 13)
        Me.lblDb.Name = "lblDb"
        Me.lblDb.Size = New System.Drawing.Size(61, 13)
        Me.lblDb.TabIndex = 46
        Me.lblDb.Text = "DataBase"
        '
        'cboDatabase
        '
        Me.cboDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDatabase.FormattingEnabled = True
        Me.cboDatabase.Location = New System.Drawing.Point(69, 5)
        Me.cboDatabase.Name = "cboDatabase"
        Me.cboDatabase.Size = New System.Drawing.Size(126, 21)
        Me.cboDatabase.TabIndex = 45
        '
        'lblTable
        '
        Me.lblTable.AutoSize = True
        Me.lblTable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTable.Location = New System.Drawing.Point(6, 31)
        Me.lblTable.Name = "lblTable"
        Me.lblTable.Size = New System.Drawing.Size(61, 13)
        Me.lblTable.TabIndex = 44
        Me.lblTable.Text = "Table List"
        '
        'cmdPopTable
        '
        Me.cmdPopTable.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cmdPopTable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPopTable.Location = New System.Drawing.Point(214, 118)
        Me.cmdPopTable.Name = "cmdPopTable"
        Me.cmdPopTable.Size = New System.Drawing.Size(30, 23)
        Me.cmdPopTable.TabIndex = 43
        Me.cmdPopTable.Text = "<"
        Me.cmdPopTable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPopTable.UseVisualStyleBackColor = False
        '
        'cmdPushTable
        '
        Me.cmdPushTable.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cmdPushTable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPushTable.Location = New System.Drawing.Point(214, 89)
        Me.cmdPushTable.Name = "cmdPushTable"
        Me.cmdPushTable.Size = New System.Drawing.Size(30, 23)
        Me.cmdPushTable.TabIndex = 42
        Me.cmdPushTable.Text = ">"
        Me.cmdPushTable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPushTable.UseVisualStyleBackColor = False
        '
        'lstTablesSelect
        '
        Me.lstTablesSelect.BackColor = System.Drawing.Color.Silver
        Me.lstTablesSelect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstTablesSelect.FormattingEnabled = True
        Me.lstTablesSelect.Location = New System.Drawing.Point(250, 31)
        Me.lstTablesSelect.Name = "lstTablesSelect"
        Me.lstTablesSelect.Size = New System.Drawing.Size(141, 171)
        Me.lstTablesSelect.Sorted = True
        Me.lstTablesSelect.TabIndex = 41
        '
        'lstTablesAll
        '
        Me.lstTablesAll.BackColor = System.Drawing.Color.Silver
        Me.lstTablesAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstTablesAll.FormattingEnabled = True
        Me.lstTablesAll.Location = New System.Drawing.Point(69, 31)
        Me.lstTablesAll.Name = "lstTablesAll"
        Me.lstTablesAll.Size = New System.Drawing.Size(141, 171)
        Me.lstTablesAll.Sorted = True
        Me.lstTablesAll.TabIndex = 40
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cboUserType)
        Me.Panel1.Controls.Add(Me.cmdPopUser)
        Me.Panel1.Controls.Add(Me.cmdPushUser)
        Me.Panel1.Controls.Add(Me.lstUserAll)
        Me.Panel1.Controls.Add(Me.lstUserSelect)
        Me.Panel1.Controls.Add(Me.lblID)
        Me.Panel1.Controls.Add(Me.lblUserType)
        Me.Panel1.Location = New System.Drawing.Point(2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(396, 195)
        Me.Panel1.TabIndex = 43
        '
        'cboUserType
        '
        Me.cboUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUserType.FormattingEnabled = True
        Me.cboUserType.Items.AddRange(New Object() {"User ID", "User Group"})
        Me.cboUserType.Location = New System.Drawing.Point(69, 3)
        Me.cboUserType.Name = "cboUserType"
        Me.cboUserType.Size = New System.Drawing.Size(126, 21)
        Me.cboUserType.TabIndex = 39
        '
        'cmdPopUser
        '
        Me.cmdPopUser.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cmdPopUser.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPopUser.Location = New System.Drawing.Point(214, 110)
        Me.cmdPopUser.Name = "cmdPopUser"
        Me.cmdPopUser.Size = New System.Drawing.Size(30, 23)
        Me.cmdPopUser.TabIndex = 38
        Me.cmdPopUser.Text = "<"
        Me.cmdPopUser.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPopUser.UseVisualStyleBackColor = False
        '
        'cmdPushUser
        '
        Me.cmdPushUser.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.cmdPushUser.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPushUser.Location = New System.Drawing.Point(214, 81)
        Me.cmdPushUser.Name = "cmdPushUser"
        Me.cmdPushUser.Size = New System.Drawing.Size(30, 23)
        Me.cmdPushUser.TabIndex = 37
        Me.cmdPushUser.Text = ">"
        Me.cmdPushUser.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPushUser.UseVisualStyleBackColor = False
        '
        'lstUserAll
        '
        Me.lstUserAll.BackColor = System.Drawing.Color.Silver
        Me.lstUserAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstUserAll.FormattingEnabled = True
        Me.lstUserAll.Location = New System.Drawing.Point(69, 31)
        Me.lstUserAll.Name = "lstUserAll"
        Me.lstUserAll.Size = New System.Drawing.Size(141, 158)
        Me.lstUserAll.Sorted = True
        Me.lstUserAll.TabIndex = 35
        '
        'lstUserSelect
        '
        Me.lstUserSelect.BackColor = System.Drawing.Color.Silver
        Me.lstUserSelect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstUserSelect.FormattingEnabled = True
        Me.lstUserSelect.Location = New System.Drawing.Point(250, 31)
        Me.lstUserSelect.Name = "lstUserSelect"
        Me.lstUserSelect.Size = New System.Drawing.Size(141, 158)
        Me.lstUserSelect.Sorted = True
        Me.lstUserSelect.TabIndex = 36
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(6, 33)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(49, 13)
        Me.lblID.TabIndex = 33
        Me.lblID.Text = "User ID"
        '
        'lblUserType
        '
        Me.lblUserType.AutoSize = True
        Me.lblUserType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.Location = New System.Drawing.Point(6, 11)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(64, 13)
        Me.lblUserType.TabIndex = 34
        Me.lblUserType.Text = "User Type"
        '
        'frmSecurity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(410, 469)
        Me.Controls.Add(Me.tabSecurity)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSecurity"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Security"
        Me.tabSecurity.ResumeLayout(False)
        Me.tbpView.ResumeLayout(False)
        CType(Me.grdSecurityView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpConfigure.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tabSecurity As System.Windows.Forms.TabControl
    Friend WithEvents tbpConfigure As System.Windows.Forms.TabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblDb As System.Windows.Forms.Label
    Friend WithEvents cboDatabase As System.Windows.Forms.ComboBox
    Friend WithEvents lblTable As System.Windows.Forms.Label
    Friend WithEvents cmdPopTable As System.Windows.Forms.Button
    Friend WithEvents cmdPushTable As System.Windows.Forms.Button
    Friend WithEvents lstTablesSelect As System.Windows.Forms.ListBox
    Friend WithEvents lstTablesAll As System.Windows.Forms.ListBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboUserType As System.Windows.Forms.ComboBox
    Friend WithEvents cmdPopUser As System.Windows.Forms.Button
    Friend WithEvents cmdPushUser As System.Windows.Forms.Button
    Friend WithEvents lstUserAll As System.Windows.Forms.ListBox
    Friend WithEvents lstUserSelect As System.Windows.Forms.ListBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents lblUserType As System.Windows.Forms.Label
    Friend WithEvents tbpView As System.Windows.Forms.TabPage
    Friend WithEvents grdSecurityView As System.Windows.Forms.DataGridView
    Friend WithEvents cmdConfigure As System.Windows.Forms.Button
End Class
