Public Class clsPerm
    '========================================================================================='
    '   Name : clsPerm
    '
    '   Description : This is the class which stores the permission on a table.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Properties/Variables"

    Private boolInsert As Boolean
    Private boolUpdate As Boolean

    '---------------------------------------------------------------------------------------
    ' Name : Insert
    '
    '---------------------------------------------------------------------------------------
    Public Property Insert() As Boolean
        Get
            Return boolInsert
        End Get
        Set(ByVal value As Boolean)
            boolInsert = value
        End Set
    End Property

	'---------------------------------------------------------------------------------------
	' Name : Update
	'
	'---------------------------------------------------------------------------------------
    Public Property Update() As Boolean
        Get
            Return boolUpdate
        End Get
        Set(ByVal value As Boolean)
            boolUpdate = value
        End Set
    End Property

#End Region

End Class
