'========================================================================================='
'   Name : clsUtil
'
'   Description :   this is the class which contains various utilities for formatting and 
'                   converting date, integer and currency
'
'   Create date: 04/09/2008     - Cognizant Offshore.
'
'
'========================================================================================='
Public Class clsUtil


    ' Short Date format
    Public Const SHORT_DATE_FORMAT As String = "MM/dd/yyyy"

    ' Default date
    Public Const DEFAULT_DATE As DateTime = #12:00:00 AM#

    ' Default effective date
    Public Const DEFAULT_EFF_DATE As DateTime = #1/1/1753#

    ' Default termination date
    Public Const DEFAULT_TERM_DATE As DateTime = #12/31/9999#

    ' Application caption
    Public Const APPLICATION_CAPTION As String = "Configuration Tables"

    Public Const ROW_STATE_COL As String = "RowState"

    ' Enumeration for RowState
    Public Enum RowState As Integer
        Unchanged = 0
        Inserted = 1
        Updated = 2
    End Enum

    ' Enumeration for User Type
    Public Enum UserType As Integer
        UserID = 0
        UserGroup = 1
    End Enum

    '---------------------------------------------------------------------------------------
    ' Name : HandleError
    '           This subroutine displays error message
    '
    ' Parameters :
    ' pstrMessage - Error message
    ' pException - Exception
    '---------------------------------------------------------------------------------------
    Public Shared Sub HandleError(ByVal pstrMessage As String, ByVal pException As Exception)
        MsgBox(pstrMessage & _
            ControlChars.CrLf & _
            ControlChars.CrLf & _
            "Following error message has been reported - " & _
            pException.Message & _
            ControlChars.CrLf & _
            ControlChars.CrLf _
            , MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : FormatForShortDate
    '           This function converts date to short date format
    '
    ' Parameters :
    ' pParam - date
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function FormatForShortDate(ByVal pParam As Object) As String

        Dim dtParam As DateTime

        If (pParam Is Nothing) Then
            Return ""
        End If

        dtParam = CDate(pParam)

        If dtParam = DEFAULT_DATE Then
            Return ""
        End If

        Return dtParam.ToString("MM/dd/yyyy")

    End Function


    '---------------------------------------------------------------------------------------
    ' Name : FormatForLongDate
    '           This function converts the date to long date format
    '
    ' Parameters :
    ' pParam - date
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function FormatForLongDate(ByVal pParam As Object) As String

        Dim dtParam As DateTime

        If (pParam Is Nothing) Then
            Return ""
        End If

        dtParam = CDate(pParam)

        If dtParam = DEFAULT_DATE Then
            Return ""
        End If

        Return dtParam.ToString("MM/dd/yyyy HH:mm:ss:fff")

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : FormatForString
    '           This function removes spaces
    '
    ' Parameters :
    ' pParam
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function FormatForString(ByVal pParam As Object) As String
        If (pParam Is Nothing) Then
            Return ""
        End If

        If pParam.ToString = "" Then
            Return ""
        End If

        Return Trim$(CStr(pParam))

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : FormatForInteger
    '           This function formats the integer value
    '
    ' Parameters :
    ' pParam
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function FormatForInteger(ByVal pParam As Object) As String
        If (pParam Is Nothing) Then
            Return "0"
        End If

        If pParam.ToString() = "" Then
            Return "0"
        End If

        Return CStr(pParam)

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : FormatForCurrency
    '           This function formats the currency value
    '
    ' Parameters :
    ' pParam
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function FormatForCurrency(ByVal pParam As Object) As String
        If (pParam Is Nothing) Then
            Return "$0.00"
        End If

        If pParam.ToString() = "" Then
            Return "$0.00"
        End If

        Return FormatCurrency(pParam, 2)
    End Function
    '---------------------------------------------------------------------------------------
    ' Name : GetToInteger
    '           This function formats the string parameter to integer
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Shared Function GetToInteger(ByVal pstrData As String) As Integer
        If (pstrData Is Nothing) Then
            Return 0
        End If

        If (Trim(pstrData) = "") Then
            Return 0
        End If

        Return CInt(pstrData)

    End Function
    '---------------------------------------------------------------------------------------
    ' Name : GetToCurrency
    '           This function formats the string parameter to currency
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Double
    '---------------------------------------------------------------------------------------
    Public Shared Function GetToCurrency(ByVal pstrData As String) As Double
        If (pstrData Is Nothing) Then
            Return 0
        End If

        If (Trim(pstrData) = "") Then
            Return 0
        End If

        Return CDbl(pstrData)

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetToShortDate
    '           This function converts string to short date
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Date
    '---------------------------------------------------------------------------------------
    Public Shared Function GetToShortDate(ByVal pstrData As String) As Date

        If (pstrData Is Nothing) Then
            Return DEFAULT_DATE
        End If

        If (pstrData = "") Then
            Return DEFAULT_DATE
        End If

        Return CDate(pstrData)

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetToShortDate
    '           This function converts object to short date
    '
    ' Parameters :
    ' poData
    '
    ' Return value : Date
    '---------------------------------------------------------------------------------------
    Public Shared Function GetToShortDate(ByVal poData As Object) As Date

        If (poData Is Nothing) Then
            Return DEFAULT_DATE
        End If

        Return CDate(poData)

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetToString
    '           This function checks the string parameter if it is stirng and returns the 
    '           string
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Shared Function GetToString(ByVal pstrData As String) As String
        If (pstrData Is Nothing) Then
            Return ""
        End If

        Return pstrData

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckValidDate
    '           This function checks for valid date
    '
    ' Parameters :
    ' pstrDate
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Shared Function CheckValidDate(ByVal pstrDate As String) As Boolean

        Dim boolValid As Boolean
        Dim dt As DateTime

        If Len(pstrDate) > 10 And Len(pstrDate) < 8 Then
            Return False
        End If

        boolValid = IsDate(pstrDate)

        If boolValid = False Then
            Return boolValid
        End If

        dt = CDate(pstrDate)

        If dt < #1/1/1753# Then
            Return False
        End If

        Return True

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckValidNumber
    '           This function checks for valid number
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Shared Function CheckValidNumber(ByVal pstrData As String) As Boolean
        Return IsNumeric(pstrData)
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckValidPositiveInteger
    '           This function checks for valid positive integer
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Shared Function CheckValidPositiveInteger(ByVal pstrData As String) As Boolean

        If clsUtil.CheckValidNumber(pstrData) = False Then
            Return False
        End If

        If clsUtil.GetToInteger(pstrData) < 0 Or _
                InStr(pstrData, ".") > 0 Then
            Return False
        End If

        Return True

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckValidBoolean
    '           This function checks for valid boolean
    '
    ' Parameters :
    ' pstrData
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Shared Function CheckValidBoolean(ByVal pstrData As String) As Boolean
        If GetToInteger(pstrData) = 0 Or GetToInteger(pstrData) = 1 Then
            Return True
        ElseIf pstrData.ToUpper = "True".ToUpper Or pstrData.ToUpper = "False".ToUpper Then
            Return True
        Else
            Return False
        End If
    End Function

	'---------------------------------------------------------------------------------------
	' Name : CheckValidInteger
    '           This function checks for valid Integer value
	' Parameters :
	' pstrData
	'
	' Return value : Boolean
	'---------------------------------------------------------------------------------------
    Public Shared Function CheckValidInteger(ByVal pstrData As String) As Boolean
        Dim intVal As Integer
        Return Integer.TryParse(pstrData, intVal)
    End Function

	'---------------------------------------------------------------------------------------
    ' Name : GetDataType
    '           This function checks for the sql types and returns the VB.NET types.
	'
	' Parameters :
	' pstrType
	'
	' Return value : String
	'---------------------------------------------------------------------------------------
    Public Shared Function GetDataType(ByVal pstrType As String) As String

        If pstrType = "decimal" Or pstrType = "tinyint" _
                    Or pstrType = "numeric" Or pstrType = "smallint" _
                    Or pstrType = "int" Or pstrType = "float" _
                    Or pstrType = "money" Or pstrType = "smallmoney" Or pstrType = "bit" _
                            Then
            Return "System.Decimal"
            Exit Function
        ElseIf pstrType = "date" Or pstrType = "datetime" Or pstrType = "time" Or pstrType = "smalldatetime" Then
            Return "System.DateTime"
            Exit Function
        Else
            Return "System.String"
        End If

    End Function

	'---------------------------------------------------------------------------------------
	' Name : GetIntegerTypes
    '           This function checks for sql type for Integer and decimal types
	' Parameters :
	' pstrType
	'
	' Return value : String
	'---------------------------------------------------------------------------------------
    Public Shared Function GetIntegerTypes(ByVal pstrType As String) As String

        If pstrType = "tinyint" Or pstrType = "int" Or pstrType = "smallint" _
                    Or pstrType = "int" _
                            Then
            Return "Integer"
        ElseIf pstrType = "decimal" Or pstrType = "float" _
                    Or pstrType = "numeric" Or pstrType = "float" _
                    Or pstrType = "money" Or pstrType = "smallmoney" Or pstrType = "bit" _
                            Then
            Return "Decimal"
        End If
        Return ""
    End Function
End Class



