

Public Class frmSecurity
    '========================================================================================='
    '   Name : frmSecurity
    '
    '   Description :   This form helps to view and configure the security information.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region " Private Variables/Properties "

    Private objSecurityModel As New clsSecurityModel

    '---------------------------------------------------------------------------------------
    ' Name : SecurityModel
    '
    '---------------------------------------------------------------------------------------
    Public Property SecurityModel() As clsSecurityModel
        Get
            Return objSecurityModel
        End Get
        Set(ByVal value As clsSecurityModel)
            objSecurityModel = value
        End Set
    End Property

#End Region

#Region " Private Events "

    '---------------------------------------------------------------------------------------
    ' Name : frmSecurity_Load
    '           Invokes on form load.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub frmSecurity_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        grdSecurityView.DataSource = SecurityModel.SecurityTable
        PopulateDB()
        cboUserType.SelectedIndex = 0
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdConfigure_Click
    '           Invokes when configure command is selected, loads the selected list into the
    '           security configuration screen to save the information.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdConfigure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConfigure.Click

        Dim strUser As String
        Dim strTable As String
        Dim SecurityConfigureScreen As New frmSecurityConfigure
        Dim intRowIndex As Integer

        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        If lstUserSelect.Items.Count = 0 Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("No user selected.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If
        If lstTablesSelect.Items.Count = 0 Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("No table selected.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        For Each strUser In lstUserSelect.Items
            For Each strTable In lstTablesSelect.Items
                intRowIndex = SecurityConfigureScreen.grdConfigure.Rows.Add()
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("USUS_ID").Value = strUser
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("DB_NAME").Value = cboDatabase.SelectedItem.ToString
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("TABLE_NAME").Value = strTable

                If SecurityModel.SecurityTable.Select("USUS_ID='" & strUser & "'" & " and TABLE_NAME= '" & strTable & "'").Length = 0 Then
                    Continue For
                End If

                If SecurityModel.SecurityTable.Select("USUS_ID='" & strUser & "' and TABLE_NAME= '" & strTable & "'and PERM_INS= 'Y'").Length <> 0 Then
                    SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("INS").Value = True
                Else
                    SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("INS").Value = False
                End If

                If SecurityModel.SecurityTable.Select("USUS_ID='" & strUser & "' and TABLE_NAME= '" & strTable & "'and PERM_UPD= 'Y'").Length <> 0 Then
                    SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("UPD").Value = True
                Else
                    SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("UPD").Value = False
                End If

            Next
        Next

        SecurityConfigureScreen.ParentSecurityForm = Me
        SecurityConfigureScreen.SecurityModel = SecurityModel
        Me.Cursor = Windows.Forms.Cursors.Arrow
        SecurityConfigureScreen.ShowDialog()

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdPushUser_Click
    '           Pushes the selected user from the main list to selected user list.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdPushUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPushUser.Click
        Dim intIndex As Integer

        If lstUserAll.SelectedItem Is Nothing Then
            Exit Sub
        End If

        intIndex = lstUserSelect.Items.Add(lstUserAll.SelectedItem)
        lstUserSelect.SelectedIndex = intIndex

        intIndex = lstUserAll.SelectedIndex
        lstUserAll.Items.Remove(lstUserAll.SelectedItem)
        If intIndex = lstUserAll.Items.Count Then
            lstUserAll.SelectedIndex = intIndex - 1
        Else
            lstUserAll.SelectedIndex = intIndex
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdPopUser_Click
    '           Pops the user back into the main list from the selected user list.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdPopUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPopUser.Click
        Dim intIndex As Integer

        If lstUserSelect.SelectedItem Is Nothing Then
            Exit Sub
        End If
        intIndex = lstUserAll.Items.Add(lstUserSelect.SelectedItem)
        lstUserAll.SelectedIndex = intIndex

        intIndex = lstUserSelect.SelectedIndex
        lstUserSelect.Items.Remove(lstUserSelect.SelectedItem)

        If intIndex = lstUserSelect.Items.Count Then
            lstUserSelect.SelectedIndex = intIndex - 1
        Else
            lstUserSelect.SelectedIndex = intIndex
        End If
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdPushTable_Click
    '           Pushes the selected table from the main table into the selected table list.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdPushTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPushTable.Click
        Dim intIndex As Integer

        If lstTablesAll.SelectedItem Is Nothing Then
            Exit Sub
        End If

        lstTablesSelect.ClearSelected()

        intIndex = lstTablesSelect.Items.Add(lstTablesAll.SelectedItem)
        lstTablesSelect.SelectedIndex = intIndex

        intIndex = lstTablesAll.SelectedIndex
        lstTablesAll.Items.Remove(lstTablesAll.SelectedItem)

        If intIndex = lstTablesAll.Items.Count Then
            lstTablesAll.SelectedIndex = intIndex - 1
        Else
            lstTablesAll.SelectedIndex = intIndex
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdPopTable_Click
    '           Pops back the selected table name from the selected list to the main list.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdPopTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPopTable.Click
        Dim intIndex As Integer

        If lstTablesSelect.SelectedItem Is Nothing Then
            Exit Sub
        End If

        intIndex = lstTablesAll.Items.Add(lstTablesSelect.SelectedItem)
        lstTablesAll.SelectedIndex = intIndex

        intIndex = lstTablesSelect.SelectedIndex
        lstTablesSelect.Items.Remove(lstTablesSelect.SelectedItem)

        If intIndex = lstTablesSelect.Items.Count Then
            lstTablesSelect.SelectedIndex = intIndex - 1
        Else
            lstTablesSelect.SelectedIndex = intIndex
        End If
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cboDatabase_SelectedIndexChanged
    '           Invokes when selection is changed in the Database drop down to populate the 
    '           tables in the selected database.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cboDatabase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDatabase.SelectedIndexChanged
        PopulateTable(cboDatabase.SelectedIndex)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cboUserType_SelectedIndexChanged
    '           Invokes when the selection is changed in the User type drop down, populates 
    '           the user ids or user groups according to the selection.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cboUserType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboUserType.SelectedIndexChanged
        PopulateUser(cboUserType.SelectedIndex)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : grdSecurityView_CellDoubleClick
    '           Invokes when a cell is double clicked, opens the configuration screen to 
    '           reconfigure the security information.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub grdSecurityView_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdSecurityView.CellDoubleClick
        Dim intRowIndex As Integer
        Dim SecurityConfigureScreen As frmSecurityConfigure
        If e.RowIndex >= 0 Then
            Me.Cursor = Windows.Forms.Cursors.WaitCursor

            SecurityConfigureScreen = New frmSecurityConfigure
            intRowIndex = SecurityConfigureScreen.grdConfigure.Rows.Add()
            SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("USUS_ID").Value _
                                                = grdSecurityView.Rows(e.RowIndex).Cells("USUS_ID").Value
            SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("DB_NAME").Value _
                                                = grdSecurityView.Rows(e.RowIndex).Cells("DB_NAME").Value
            SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("TABLE_NAME").Value _
                                                = grdSecurityView.Rows(e.RowIndex).Cells("TABLE_NAME").Value
            If clsUtil.FormatForString(grdSecurityView.Rows(e.RowIndex).Cells("PERM_INS").Value) = "Y" Then
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("INS").Value = True
            Else
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("INS").Value = False
            End If
            If clsUtil.FormatForString(grdSecurityView.Rows(e.RowIndex).Cells("PERM_UPD").Value) = "Y" Then
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("UPD").Value = True
            Else
                SecurityConfigureScreen.grdConfigure.Rows(intRowIndex).Cells("UPD").Value = False
            End If


            SecurityConfigureScreen.ParentSecurityForm = Me
            SecurityConfigureScreen.SecurityModel = SecurityModel
            Me.Cursor = Windows.Forms.Cursors.Arrow
            SecurityConfigureScreen.ShowDialog()
        End If

    End Sub

#End Region

#Region " Private Methods "

    '---------------------------------------------------------------------------------------
    ' Name : PopulateDB
    '           Populates the DB list in the DB drop down.
    '---------------------------------------------------------------------------------------
    Private Sub PopulateDB()
        Dim intDBId As Integer
        cboDatabase.Items.Clear()

        For Each intDBId In SecurityModel.GetDBIDs
            cboDatabase.Items.Add(SecurityModel.DB(intDBId).DBName)
        Next

        cboDatabase.SelectedIndex = 0
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : PopulateTable
    '           Populates the table list into the main tables list.
    ' Parameters :
    ' pintDBIndex
    '---------------------------------------------------------------------------------------
    Private Sub PopulateTable(ByVal pintDBIndex As Integer)
        Dim objDB As clsDB
        Dim intCount As Integer

        lstTablesSelect.Items.Clear()
        lstTablesAll.Items.Clear()

        objDB = SecurityModel.DB(pintDBIndex)

        For intCount = 0 To objDB.TableCount - 1
            lstTablesAll.Items.Add(objDB.Tables(intCount).Name)
        Next

        lstTablesAll.SelectedIndex = 0

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : PopulateUser
    '           Populates the user list in the main user list.
    ' Parameters :
    ' pintIndex
    '---------------------------------------------------------------------------------------
    Private Sub PopulateUser(ByVal pintIndex As Integer)
        Dim intUserId As Integer

        lstUserAll.Items.Clear()
        lstUserSelect.Items.Clear()

        intUserId = 0
        While intUserId < SecurityModel.UserType(pintIndex).UserCount
            lstUserAll.Items.Add(SecurityModel.UserType(pintIndex).User(intUserId))
            intUserId = intUserId + 1
        End While

        lstUserAll.SelectedIndex = 0
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : RefreshScreen
    '           Refreshes the screen.
    '---------------------------------------------------------------------------------------
    Public Sub RefreshScreen()

        lstUserSelect.Items.Clear()
        lstTablesSelect.Items.Clear()

        PopulateDB()
        PopulateUser(0)

        grdSecurityView.DataSource = SecurityModel.SecurityTable
    End Sub

#End Region



End Class