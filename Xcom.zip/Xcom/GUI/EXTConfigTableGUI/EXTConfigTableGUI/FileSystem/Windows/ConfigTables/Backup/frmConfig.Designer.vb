<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfig
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdConfig = New System.Windows.Forms.DataGridView
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSave = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAdd = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuUpdate = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuCancel = New System.Windows.Forms.ToolStripMenuItem
        Me.TransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAudit = New System.Windows.Forms.ToolStripMenuItem
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cmdOK = New System.Windows.Forms.Button
        Me.cboTable = New System.Windows.Forms.ComboBox
        Me.lblTables = New System.Windows.Forms.Label
        Me.cboDatabase = New System.Windows.Forms.ComboBox
        Me.lblDatabase = New System.Windows.Forms.Label
        Me.lblTableHeader = New System.Windows.Forms.Label
        Me.txtKeys = New System.Windows.Forms.TextBox
        CType(Me.grdConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grdConfig
        '
        Me.grdConfig.AllowUserToAddRows = False
        Me.grdConfig.AllowUserToDeleteRows = False
        Me.grdConfig.AllowUserToResizeRows = False
        Me.grdConfig.BackgroundColor = System.Drawing.Color.Gray
        Me.grdConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdConfig.Location = New System.Drawing.Point(3, 130)
        Me.grdConfig.Name = "grdConfig"
        Me.grdConfig.RowHeadersVisible = False
        Me.grdConfig.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdConfig.RowTemplate.ReadOnly = True
        Me.grdConfig.Size = New System.Drawing.Size(1006, 550)
        Me.grdConfig.TabIndex = 9
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.TransferToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1011, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSave, Me.mnuSeparator2, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuSave
        '
        Me.mnuSave.Enabled = False
        Me.mnuSave.Name = "mnuSave"
        Me.mnuSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuSave.Size = New System.Drawing.Size(138, 22)
        Me.mnuSave.Text = "&Save"
        '
        'mnuSeparator2
        '
        Me.mnuSeparator2.Name = "mnuSeparator2"
        Me.mnuSeparator2.Size = New System.Drawing.Size(135, 6)
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuExit.Size = New System.Drawing.Size(138, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'mnuEdit
        '
        Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAdd, Me.mnuUpdate, Me.mnuCancel})
        Me.mnuEdit.Name = "mnuEdit"
        Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuAdd
        '
        Me.mnuAdd.Enabled = False
        Me.mnuAdd.Name = "mnuAdd"
        Me.mnuAdd.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnuAdd.Size = New System.Drawing.Size(154, 22)
        Me.mnuAdd.Text = "&Add"
        '
        'mnuUpdate
        '
        Me.mnuUpdate.Enabled = False
        Me.mnuUpdate.Name = "mnuUpdate"
        Me.mnuUpdate.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.mnuUpdate.Size = New System.Drawing.Size(154, 22)
        Me.mnuUpdate.Text = "&Update"
        '
        'mnuCancel
        '
        Me.mnuCancel.Enabled = False
        Me.mnuCancel.Name = "mnuCancel"
        Me.mnuCancel.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuCancel.Size = New System.Drawing.Size(154, 22)
        Me.mnuCancel.Text = "Cancel"
        '
        'TransferToolStripMenuItem
        '
        Me.TransferToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAudit})
        Me.TransferToolStripMenuItem.Name = "TransferToolStripMenuItem"
        Me.TransferToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.TransferToolStripMenuItem.Text = "&Transfer"
        '
        'mnuAudit
        '
        Me.mnuAudit.Enabled = False
        Me.mnuAudit.Name = "mnuAudit"
        Me.mnuAudit.Size = New System.Drawing.Size(103, 22)
        Me.mnuAudit.Text = "&Audit"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cmdOK)
        Me.Panel1.Controls.Add(Me.cboTable)
        Me.Panel1.Controls.Add(Me.lblTables)
        Me.Panel1.Controls.Add(Me.cboDatabase)
        Me.Panel1.Controls.Add(Me.lblDatabase)
        Me.Panel1.Location = New System.Drawing.Point(3, 29)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(647, 53)
        Me.Panel1.TabIndex = 11
        '
        'cmdOK
        '
        Me.cmdOK.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOK.Location = New System.Drawing.Point(556, 13)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(75, 23)
        Me.cmdOK.TabIndex = 14
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'cboTable
        '
        Me.cboTable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTable.FormattingEnabled = True
        Me.cboTable.Location = New System.Drawing.Point(330, 15)
        Me.cboTable.Name = "cboTable"
        Me.cboTable.Size = New System.Drawing.Size(175, 21)
        Me.cboTable.TabIndex = 13
        '
        'lblTables
        '
        Me.lblTables.AutoSize = True
        Me.lblTables.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTables.Location = New System.Drawing.Point(285, 18)
        Me.lblTables.Name = "lblTables"
        Me.lblTables.Size = New System.Drawing.Size(44, 13)
        Me.lblTables.TabIndex = 12
        Me.lblTables.Text = "Tables"
        '
        'cboDatabase
        '
        Me.cboDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDatabase.FormattingEnabled = True
        Me.cboDatabase.Location = New System.Drawing.Point(70, 15)
        Me.cboDatabase.Name = "cboDatabase"
        Me.cboDatabase.Size = New System.Drawing.Size(175, 21)
        Me.cboDatabase.TabIndex = 11
        '
        'lblDatabase
        '
        Me.lblDatabase.AutoSize = True
        Me.lblDatabase.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatabase.Location = New System.Drawing.Point(11, 18)
        Me.lblDatabase.Name = "lblDatabase"
        Me.lblDatabase.Size = New System.Drawing.Size(61, 13)
        Me.lblDatabase.TabIndex = 10
        Me.lblDatabase.Text = "Database"
        '
        'lblTableHeader
        '
        Me.lblTableHeader.AutoEllipsis = True
        Me.lblTableHeader.BackColor = System.Drawing.Color.Navy
        Me.lblTableHeader.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTableHeader.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTableHeader.Location = New System.Drawing.Point(3, 85)
        Me.lblTableHeader.Name = "lblTableHeader"
        Me.lblTableHeader.Size = New System.Drawing.Size(1006, 22)
        Me.lblTableHeader.TabIndex = 12
        Me.lblTableHeader.Text = "Table - Unassigned"
        Me.lblTableHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtKeys
        '
        Me.txtKeys.BackColor = System.Drawing.Color.Navy
        Me.txtKeys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtKeys.ForeColor = System.Drawing.SystemColors.Menu
        Me.txtKeys.Location = New System.Drawing.Point(3, 108)
        Me.txtKeys.Multiline = True
        Me.txtKeys.Name = "txtKeys"
        Me.txtKeys.ReadOnly = True
        Me.txtKeys.Size = New System.Drawing.Size(1006, 20)
        Me.txtKeys.TabIndex = 13
        Me.txtKeys.Text = "Keys - None"
        '
        'frmConfig
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1011, 683)
        Me.Controls.Add(Me.txtKeys)
        Me.Controls.Add(Me.lblTableHeader)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.grdConfig)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmConfig"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Configuration Tables"
        CType(Me.grdConfig, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdConfig As System.Windows.Forms.DataGridView
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUpdate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAudit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cboTable As System.Windows.Forms.ComboBox
    Friend WithEvents lblTables As System.Windows.Forms.Label
    Friend WithEvents cboDatabase As System.Windows.Forms.ComboBox
    Friend WithEvents lblDatabase As System.Windows.Forms.Label
    Friend WithEvents lblTableHeader As System.Windows.Forms.Label
    Friend WithEvents mnuCancel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtKeys As System.Windows.Forms.TextBox

End Class
