Imports System.Xml

Public Class clsFacetsData
    '========================================================================================='
    '   Name : clsFacetsData
    '
    '   Description : this is the class to get the facets data.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Variables"
    ' Facets Connection Object
    Public Shared extFacetsData As ErCoreIfcExtensionData.IFaExtensionData
#End Region

#Region "Private Methods"

    Public Sub test()
        Dim strConnectionString As String
        Dim frmConfigForm As New frmConfig
        Dim dataModel As New clsDataModel
        'strConnectionString = "DRIVER={Sybase ASE ODBC Driver};UID=somakr;PWD=facets;" & _
        '                        "DB=fakpfpr0;APP=Facets Online;" & _
        '                        "SM=0;OP=2;AUT=1;IS=Set ansinull off;NA=63.78.177.6,18044"

        'strConnectionString = "Provider=ASEOLEDB;Server Name=63.110.97.35,18945;Initial Catalog=fakpfpr0;User Id=hgwplbatch;Password=facets"
        strConnectionString = "UID=hgwplbatch;PWD=facets;DSN=SybDev1_1;DataBase=fakpfpr0;"
        MessageBox.Show("Done")

        If InitDB(strConnectionString) = False Then
            Return
        End If

        If dataModel.Init() Then
            frmConfigForm.Model = dataModel
            frmConfigForm.Model.User = GetUserID(strConnectionString)
            frmConfigForm.ShowDialog()
        Else
            MsgBox("Initialization failed.", _
                        MsgBoxStyle.Information, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    '
    ' Name : InitFacets
    '          This sub module is to get the connection details from the facets data amd 
    '       initializes our extension.
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InitFacets() As Boolean
        Dim strContextData As String
        Dim strFacetsData As String
        Dim strConnectionString As String
        Dim strUserID As String
        Dim frmConfigForm As frmConfig
        Dim dataModel As New clsDataModel

        strContextData = extFacetsData.GetContextData("")
        strFacetsData = extFacetsData.GetData("")
        strConnectionString = GetNodeData("SGN0", "Connection", strContextData)
        strUserID = GetUserID(strConnectionString)
        'strConnectionString = ReplaceConnectionInfo(strConnectionString)

        'Chris
        strConnectionString = GetNodeInnerData(strConnectionString)

        'Begin Version 1.7
        'If InStr(1, strConnectionString, "UID=", CompareMethod.Binary) = 0 Then
        'For 471, manipulating connection string from facts context data
        '            strConnectionString = GetNodeInnerData(strConnectionString)
        'Else
        '    ' For 431, connection string from facts context data
        '    strConnectionString = SetConnectionInfo(strConnectionString)
        'End If
        'End Version 1.7

        If InitDB(strConnectionString) = False Then
            Return False
        End If

        If dataModel.Init() Then
            frmConfigForm = New frmConfig()
            frmConfigForm.Model = dataModel
            frmConfigForm.Model.User = GetUserID(strConnectionString)
            frmConfigForm.ShowDialog()
        Else
            MsgBox("Initialization failed.", _
                        MsgBoxStyle.Information, clsUtil.APPLICATION_CAPTION)
            Exit Function
        End If

        Return True

    End Function

    ' Begin Version 1.7
    '---------------------------------------------------------------------------------------
    '   GetNodeInnerData
    '   -  Function to get the Facets connection string from the Given Facets Data.
    '
    '    Parameters: - Facetsdata
    '
    '   Return Value: connection string.
    '---------------------------------------------------------------------------------------
    Public Function GetNodeInnerData(ByRef lstrConnectionStringGot As String) As String

        On Error GoTo ErrHandler
        Dim lobjcategoryNodes As MSXML2.IXMLDOMNodeList
        Dim lstrXMLElementName As String
        Dim lstrcollName As String
        Dim lcategoryNode As MSXML2.IXMLDOMElement
        Dim lobjcollDomainNode As MSXML2.IXMLDOMElement
        Dim lobjcollDomainNodes As MSXML2.IXMLDOMNodeList
        Dim lstrConnectionStr As String
        Dim lobjFacetsXML As New MSXML2.DOMDocument
        lstrConnectionStr = ""
        'MsgBox lstrConnectionStringGot

        lobjFacetsXML.loadXML(lstrConnectionStringGot)

        lobjcategoryNodes = lobjFacetsXML.documentElement.childNodes


        For Each lcategoryNode In lobjcategoryNodes
            If lcategoryNode.nodeName = "USERID" Then
                lstrConnectionStr = lstrConnectionStr & "UID=" & lcategoryNode.Text & ";"
            End If
            If lcategoryNode.nodeName = "PASSWORD" Then
                lstrConnectionStr = lstrConnectionStr & "PWD=" & lcategoryNode.Text & ";"
            End If
            If lcategoryNode.nodeName = "DATABASE" Then
                lstrConnectionStr = lstrConnectionStr & "DataBase=" & lcategoryNode.Text & ";"
            End If
            If lcategoryNode.nodeName = "DATASOURCE" Then
                lstrConnectionStr = lstrConnectionStr & "DSN=" & lcategoryNode.Text & ";"
            End If
        Next lcategoryNode

        GetNodeInnerData = lstrConnectionStr

        Exit Function

ErrHandler:
        MsgBox("Error Occured while Getting Node Inner Data. " & Err.Description, MsgBoxStyle.Critical)
    End Function
    'End Version 1.7

    '---------------------------------------------------------------------------------------
    '
    ' Name : GetUserID
    '       The function returns the User ID from the provided connection String.
    ' Parameters :
    ' Connection String
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Function GetUserID(ByVal pstrConnectionString As String) As String
        Dim intStartLocation As Integer
        Dim intEndLocation As Integer
        Dim strUserID As String
        strUserID = ""

        intStartLocation = pstrConnectionString.IndexOf("UID=")

        If (intStartLocation >= 0) Then
            intEndLocation = pstrConnectionString.IndexOf(";", intStartLocation)
            If intEndLocation < Len(pstrConnectionString) Then
                strUserID = Mid(pstrConnectionString, intStartLocation + 5, intEndLocation - intStartLocation - 4)
            End If
        End If

        Return strUserID
    End Function

    '---------------------------------------------------------------------------------------
    '   SetFacetsData
    '   -  Function to be invoked when click event is happen.
    '
    '    Parameters: - Facets Extension Datas.
    '
    '   Return Value: Boolean
    '---------------------------------------------------------------------------------------
    Public Function SetFacetsData(ByVal poExtData As ErCoreIfcExtensionData.IFaExtensionData, _
                        ByVal pstrCompId As String) As Boolean

        Try
            extFacetsData = poExtData
            Return InitFacets()
        Catch ex As Exception
            clsUtil.HandleError("Error occured while initializing extension.", ex)
            Return False
        End Try

    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : GetNodeData
    '       This function gets the Facets node data for the required node from the facets XML file.
    ' Parameters :
    ' Facets Data Name , Facets Collection Name, XmlData
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Function GetNodeData(ByVal pstrFacetsDataName As String, _
        ByVal pstrCollectionName As String, ByVal pstrXmlData As String) As String

        Dim facetsDataNodes As XmlNodeList
        Dim facetsDataNode As XmlNode
        Dim strFacetDataName As String
        Dim document As New XmlDocument
        Dim collectionNodes As XmlNodeList
        Dim collectionNode As XmlNode
        Dim strCollectionName As String

        document.LoadXml(pstrXmlData)
        facetsDataNodes = document.DocumentElement.ChildNodes

        For Each facetsDataNode In facetsDataNodes
            strFacetDataName = facetsDataNode.Attributes("name").Value
            If strFacetDataName = pstrFacetsDataName Then
                If pstrCollectionName = "" Then
                    Return facetsDataNode.InnerText()
                End If
                collectionNodes = facetsDataNode.ChildNodes()
                For Each collectionNode In collectionNodes
                    strCollectionName = collectionNode.Attributes("name").Value
                    If strCollectionName = pstrCollectionName Then
                        Return collectionNode.InnerText()
                    End If
                Next
            End If
        Next

        Return ""
    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : ReplaceConnectionInfo
    '           This function replaces the connection string with the SM mode as SM=0;
    ' Parameters :
    '   Connection String
    '
    ' Return value : Replaced Connection String
    '---------------------------------------------------------------------------------------
    Public Function ReplaceConnectionInfo(ByVal pstrConnectionString As String) _
                        As String

        Dim intStartLocation As Integer
        Dim intEndLocation As Integer
        Dim strReplaceString As String

        intStartLocation = pstrConnectionString.IndexOf("SM=")

        If (intStartLocation > 0) Then
            intEndLocation = pstrConnectionString.IndexOf(";", intStartLocation)
            strReplaceString = Left(pstrConnectionString, intStartLocation)
            strReplaceString = strReplaceString & "SM=0;"
            strReplaceString = strReplaceString & _
                    Right(pstrConnectionString, (Len(pstrConnectionString) - intEndLocation - 1))
        Else
            strReplaceString = pstrConnectionString
        End If

        Return strReplaceString

    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : InitDB
    '       Initialise the database connection using DBHandler class.
    ' Parameters :
    '   Connection  String
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InitDB(ByVal pstrConnectionString As String) As Boolean
        Dim dbhandler As clsDBHandler

        Try
            dbhandler = clsDBHandler.GetDBHandler()
            dbhandler.strConnString = pstrConnectionString
            dbhandler.Init()
            Return True
        Catch ex As Exception
            clsUtil.HandleError("Error occured while database connection initialization.", ex)
            Return False
        End Try
    End Function

#End Region

End Class

