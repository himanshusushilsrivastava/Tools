Module modDebugMain
    Sub Main()

        Dim strConnectionString As String
        Dim frmConfigForm As New frmConfig
        Dim dataModel As New clsDataModel
        'strConnectionString = "DRIVER={Sybase ASE ODBC Driver};UID=somakr;PWD=facets;" & _
        '                        "DB=fakpfpr0;APP=Facets Online;" & _
        '                        "SM=0;OP=2;AUT=1;IS=Set ansinull off;NA=63.78.177.6,18044"

        'strConnectionString = "Provider=ASEOLEDB;Server Name=63.110.97.35,18945;Initial Catalog=fakpfpr0;User Id=hgwplbatch;Password=facets"
        strConnectionString = "Provider=ASEOLEDB;Server Name=192.30.110.243,10095;Initial Catalog=fakpfpr0;User Id=hgwplbatch;Password=facets"


        If InitDB(strConnectionString) = False Then
            Return
        End If

        If dataModel.Init() Then
            frmConfigForm.Model = dataModel
            frmConfigForm.Model.User = GetUserID(strConnectionString)
            frmConfigForm.ShowDialog()
        Else
            MsgBox("Initialization failed.", _
                        MsgBoxStyle.Information, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

    End Sub
    Public Function InitDB(ByVal pstrConnectionString As String) As Boolean
        Dim dbhandler As clsDBHandler

        Try
            dbhandler = clsDBHandler.GetDBHandler()
            dbhandler.strConnString = pstrConnectionString
            dbhandler.Init()
            Return True
        Catch ex As Exception
            clsUtil.HandleError("Error occured while database connection initialization.", ex)
            Return False
        End Try
    End Function
    Public Function GetUserID(ByVal pstrConnectionString As String) As String
        Dim intStartLocation As Integer
        Dim intEndLocation As Integer
        Dim strUserID As String
        strUserID = ""

        intStartLocation = pstrConnectionString.IndexOf("UID=")

        If (intStartLocation > 0) Then
            intEndLocation = pstrConnectionString.IndexOf(";", intStartLocation)
            If intEndLocation < Len(pstrConnectionString) Then
                strUserID = Mid(pstrConnectionString, intStartLocation + 5, intEndLocation - intStartLocation - 4)
            End If
        End If

        Return strUserID
    End Function
End Module
