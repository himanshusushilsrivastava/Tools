Imports ADODB

Public Class clsDBOperations

    '========================================================================================='
    '   Name : clsDBOperations
    '
    '   Description :   This class executes the data using dbHandler into the Database.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Methods"

    '---------------------------------------------------------------------------------------
    ' Name : ExecuteSP
    '           Executes the SP.
    ' Parameters :
    ' pstrSPName
    ' pdictValue
    '
    ' Return value : Recordset
    '---------------------------------------------------------------------------------------
    Function ExecuteSP(ByVal pstrSPName As String, ByVal pdictValue As Dictionary(Of Integer, Parameter)) As Recordset
        Dim dbHandler As clsDBHandler
        Dim rs As ADODB.Recordset
        Dim cmd As ADODB.Command
        Dim intCount As Integer
        Dim dbParam As Parameter

        rs = New ADODB.Recordset
        cmd = New ADODB.Command

        dbHandler = clsDBHandler.GetDBHandler()
        cmd = dbHandler.GetSPCommandObject(pstrSPName)

        If (pdictValue Is Nothing) = False Then
            intCount = 0

            For Each intCount In pdictValue.Keys
                dbParam = cmd.CreateParameter()
                dbParam.Name = pdictValue(intCount).Name
                dbParam.Direction = pdictValue(intCount).Direction
                dbParam.Type = pdictValue(intCount).Type
                dbParam.Value = pdictValue(intCount).Value
                dbParam.Size = pdictValue(intCount).Size
                dbParam.Precision = pdictValue(intCount).Precision
                cmd.Parameters.Append(dbParam)
            Next
        End If


        rs = dbHandler.GetRecordSetObject()
        Try
            rs.Open(cmd)
        Catch ex As Exception
            clsUtil.HandleError("Error occured while database operation.", ex)
            Return Nothing
        End Try
        Return rs
    End Function

#End Region

End Class
