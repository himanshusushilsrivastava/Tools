<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSecurityConfigure
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdConfigure = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cmdSave = New System.Windows.Forms.Button
        Me.chkUpdate = New System.Windows.Forms.CheckBox
        Me.chkInsert = New System.Windows.Forms.CheckBox
        Me.lblGrantAll = New System.Windows.Forms.Label
        Me.USUS_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DB_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TABLE_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.INS = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.UPD = New System.Windows.Forms.DataGridViewCheckBoxColumn
        CType(Me.grdConfigure, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grdConfigure
        '
        Me.grdConfigure.AllowUserToAddRows = False
        Me.grdConfigure.AllowUserToDeleteRows = False
        Me.grdConfigure.AllowUserToResizeRows = False
        Me.grdConfigure.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdConfigure.BackgroundColor = System.Drawing.Color.Silver
        Me.grdConfigure.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdConfigure.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.USUS_ID, Me.DB_NAME, Me.TABLE_NAME, Me.INS, Me.UPD})
        Me.grdConfigure.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.grdConfigure.Location = New System.Drawing.Point(2, 35)
        Me.grdConfigure.Name = "grdConfigure"
        Me.grdConfigure.RowHeadersVisible = False
        Me.grdConfigure.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.grdConfigure.Size = New System.Drawing.Size(508, 334)
        Me.grdConfigure.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cmdSave)
        Me.Panel1.Controls.Add(Me.chkUpdate)
        Me.Panel1.Controls.Add(Me.chkInsert)
        Me.Panel1.Controls.Add(Me.lblGrantAll)
        Me.Panel1.Location = New System.Drawing.Point(2, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(508, 29)
        Me.Panel1.TabIndex = 1
        '
        'cmdSave
        '
        Me.cmdSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.Location = New System.Drawing.Point(423, 2)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(75, 23)
        Me.cmdSave.TabIndex = 3
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'chkUpdate
        '
        Me.chkUpdate.AutoSize = True
        Me.chkUpdate.Location = New System.Drawing.Point(166, 6)
        Me.chkUpdate.Name = "chkUpdate"
        Me.chkUpdate.Size = New System.Drawing.Size(61, 17)
        Me.chkUpdate.TabIndex = 2
        Me.chkUpdate.Text = "Update"
        Me.chkUpdate.UseVisualStyleBackColor = True
        '
        'chkInsert
        '
        Me.chkInsert.AutoSize = True
        Me.chkInsert.Location = New System.Drawing.Point(81, 6)
        Me.chkInsert.Name = "chkInsert"
        Me.chkInsert.Size = New System.Drawing.Size(55, 17)
        Me.chkInsert.TabIndex = 1
        Me.chkInsert.Text = "Insert"
        Me.chkInsert.UseVisualStyleBackColor = True
        '
        'lblGrantAll
        '
        Me.lblGrantAll.AutoSize = True
        Me.lblGrantAll.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrantAll.Location = New System.Drawing.Point(10, 6)
        Me.lblGrantAll.Name = "lblGrantAll"
        Me.lblGrantAll.Size = New System.Drawing.Size(56, 13)
        Me.lblGrantAll.TabIndex = 5
        Me.lblGrantAll.Text = "Grant All"
        '
        'USUS_ID
        '
        Me.USUS_ID.HeaderText = "USUS_ID"
        Me.USUS_ID.Name = "USUS_ID"
        Me.USUS_ID.ReadOnly = True
        Me.USUS_ID.Width = 75
        '
        'DB_NAME
        '
        Me.DB_NAME.HeaderText = "DB_NAME"
        Me.DB_NAME.Name = "DB_NAME"
        Me.DB_NAME.ReadOnly = True
        Me.DB_NAME.Width = 79
        '
        'TABLE_NAME
        '
        Me.TABLE_NAME.HeaderText = "TABLE_NAME"
        Me.TABLE_NAME.Name = "TABLE_NAME"
        Me.TABLE_NAME.ReadOnly = True
        Me.TABLE_NAME.Width = 96
        '
        'INS
        '
        Me.INS.HeaderText = "INSERT"
        Me.INS.Name = "INS"
        Me.INS.Width = 49
        '
        'UPD
        '
        Me.UPD.HeaderText = "UPDATE"
        Me.UPD.Name = "UPD"
        Me.UPD.Width = 52
        '
        'frmSecurityConfigure
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(512, 371)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.grdConfigure)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSecurityConfigure"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Configure"
        CType(Me.grdConfigure, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grdConfigure As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents chkUpdate As System.Windows.Forms.CheckBox
    Friend WithEvents chkInsert As System.Windows.Forms.CheckBox
    Friend WithEvents lblGrantAll As System.Windows.Forms.Label
    Friend WithEvents USUS_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DB_NAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TABLE_NAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents INS As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents UPD As System.Windows.Forms.DataGridViewCheckBoxColumn
End Class
