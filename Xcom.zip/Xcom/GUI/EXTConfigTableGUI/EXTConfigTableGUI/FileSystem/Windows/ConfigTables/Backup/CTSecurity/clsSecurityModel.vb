Option Explicit On

Imports System.Data
Imports System.Data.OleDb
Imports System.Reflection
Imports Microsoft.VisualBasic


Public Class clsSecurityModel
    '========================================================================================='
    '   Name : clsSecurityModel
    '
    '   Description :   This class stores all the data and methods related to the Security forms.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region " Private Properties/Variables "

    Private dictUserList As New Dictionary(Of Integer, clsUsers)
    Private dictDatabaseList As New Dictionary(Of Integer, clsDB)

    Private dtSecurityTable As New DataTable
    Private dtMasterList As New DataTable

    Private dbOperation As New clsDBOperations

    '---------------------------------------------------------------------------------------
    ' Name : MasterTable
    '           
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property MasterTable() As DataTable
        Get
            Return dtMasterList
        End Get
    End Property


    '---------------------------------------------------------------------------------------
    ' Name : SecurityTable
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property SecurityTable() As DataTable
        Get
            Return dtSecurityTable
        End Get
        '---------------------------------------------------------------------------------------
    End Property


    '---------------------------------------------------------------------------------------
    ' Name : UserType
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property UserType(ByVal ID As Integer) As clsUsers
        Get
            Dim objUser As clsUsers = Nothing
            dictUserList.TryGetValue(ID, objUser)
            Return objUser
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : GetUserTypeIDs
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetUserTypeIDs() As ICollection(Of Integer)
        Return dictUserList.Keys()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : DB
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property DB(ByVal ID As Integer) As clsDB
        Get
            Dim objDB As clsDB = Nothing
            dictDatabaseList.TryGetValue(ID, objDB)
            Return objDB
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : GetDBIDs
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetDBIDs() As ICollection(Of Integer)
        GetDBIDs = dictDatabaseList.Keys()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetDBCount
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetDBCount() As Integer
        GetDBCount = dictDatabaseList.Count()
    End Function
#End Region

#Region " Private Methods "

    '---------------------------------------------------------------------------------------
    ' Name : InitSecurity
    '           Initializes the the Security form data.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InitSecurity() As Boolean
        If GetDb() = False Then
            Return False
            Exit Function
        End If
        If GetTable() = False Then
            Return False
            Exit Function
        End If
        If GetUserIds() = False Then
            Return False
            Exit Function
        End If
        If SelectSecurityTable() = False Then
            Return False
            Exit Function
        End If
        Return True
    End Function
    '---------------------------------------------------------------------------------------
    ' Name : GetDb
    '           Gets the DB list from the Master Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetDb() As Boolean
        Dim rs As New ADODB.Recordset
        Dim intCount As Integer

        rs = dbOperation.ExecuteSP("scs_cnfg_db_select", Nothing)

        If rs Is Nothing Then
            Return False
        End If

        intCount = 0
        dictDatabaseList.Clear()
        While Not rs.EOF

            Dim objDB As New clsDB
            objDB.DBName = clsUtil.FormatForString(rs.Fields(0).Value)
            dictDatabaseList.Add(intCount, objDB)
            ' go to next record in the results
            rs.MoveNext()

            intCount = intCount + 1
        End While

        rs.Close()

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetTable
    '           Gets the Table list from the Master Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetTable() As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim intCount As Integer
        Dim intDBID As Integer

        For Each intDBID In GetDBIDs()

            dictParam.Clear()
            dbParam = New ADODB.Parameter
            dbParam.Name = "@pchDB"
            dbParam.Direction = ADODB.ParameterDirectionEnum.adParamInput
            dbParam.Type = ADODB.DataTypeEnum.adChar
            dbParam.Precision = 255
            dbParam.Size = 30
            dbParam.Value = DB(intDBID).DBName
            dictParam.Add(0, dbParam)
            rs = dbOperation.ExecuteSP("scs_cnfg_tables_select", dictParam)

            If rs Is Nothing Then
                Return False
            End If

            rs.MoveFirst()

            DB(intDBID).Init(rs.RecordCount)

            intCount = 0

            While Not rs.EOF
                DB(intDBID).Tables(intCount).Name = clsUtil.FormatForString(rs.Fields(0).Value)
                ' go to next record in the results
                rs.MoveNext()

                intCount = intCount + 1
            End While

            rs.Close()
        Next

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetUserIds
    '           Gets the list of all User Ids.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetUserIds() As Boolean
        Dim objUser As clsUsers
        Dim rs As New ADODB.Recordset
        Dim intUserTypeId As Integer
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim intCount As Integer

        dictUserList.Clear()
        objUser = New clsUsers
        dictUserList.Add(clsUtil.UserType.UserID, objUser)

        objUser = New clsUsers
        dictUserList.Add(clsUtil.UserType.UserGroup, objUser)

        For Each intUserTypeId In GetUserTypeIDs()
            dictParam.Clear()

            dbParam = GetParameter("@pnUserType", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adSmallInt, 10, 4, intUserTypeId)
            dictParam.Add(0, dbParam)

            rs = dbOperation.ExecuteSP("scs_cnfg_users_select", dictParam)
            If rs Is Nothing Then
                Return False
                Exit Function
            End If

            UserType(intUserTypeId).Init(rs.RecordCount)

            intCount = 0
            While Not rs.EOF
                UserType(intUserTypeId).User(intCount) = rs.Fields(0).Value
                rs.MoveNext()
                intCount = intCount + 1
            End While

            rs.Close()
        Next
        Return True
    End Function


    '---------------------------------------------------------------------------------------
    ' Name : SaveSecurityTable
    '           Saves the data into Security table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function SaveSecurityTable() As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim dr As DataRow

        For Each dr In SecurityTable.Rows
            dictParam.Clear()

            dbParam = GetParameter("@pvcUSUS_ID", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 10, dr.Item("USUS_ID"))
            dictParam.Add(0, dbParam)

            dbParam = GetParameter("@pvcDBName", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 30, dr.Item("DB_NAME"))
            dictParam.Add(1, dbParam)

            dbParam = GetParameter("@pvcTableName", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 30, dr.Item("TABLE_NAME"))
            dictParam.Add(2, dbParam)

            dbParam = GetParameter("@pchPermIns", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 1, dr.Item("PERM_INS"))
            dictParam.Add(3, dbParam)

            dbParam = GetParameter("@pchPermUpd", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 1, dr.Item("PERM_UPD"))
            dictParam.Add(4, dbParam)

            rs = dbOperation.ExecuteSP("scs_cnfg_perm_save", dictParam)
            If rs Is Nothing Then
                Return False
                Exit Function
            End If
        Next

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetSecurityTable
    '           Initializes the Security Table.
    '---------------------------------------------------------------------------------------
    Private Sub GetSecurityTable()
        dtSecurityTable = New DataTable
        dtSecurityTable.Columns.Add("USUS_ID", Type.GetType("System.String"))
        dtSecurityTable.Columns.Add("DB_NAME", Type.GetType("System.String"))
        dtSecurityTable.Columns.Add("TABLE_NAME", Type.GetType("System.String"))
        dtSecurityTable.Columns.Add("PERM_INS", Type.GetType("System.String"))
        dtSecurityTable.Columns.Add("PERM_UPD", Type.GetType("System.String"))
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : SelectSecurityTable
    '           Fetches the Security table information.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function SelectSecurityTable() As Boolean
        Dim rs As ADODB.Recordset
        Dim da As New System.Data.OleDb.OleDbDataAdapter

        dtSecurityTable = New DataTable

        rs = dbOperation.ExecuteSP("scs_cnfg_perm_select", Nothing)

        If rs Is Nothing Then
            Return False
        End If

        GetSecurityTable()
        da.Fill(dtSecurityTable, rs)

        Return True
    End Function


    '---------------------------------------------------------------------------------------
    ' Name : GetParameter
    '           Creates a ADODB parameter.
    ' Parameters :
    ' pstrName
    ' pdbdir
    '
    ' Return value : _
    '---------------------------------------------------------------------------------------
    Private Function GetParameter(ByVal pstrName As String, ByVal pdbdir As ADODB.ParameterDirectionEnum, _
            ByVal pdbtype As ADODB.DataTypeEnum, ByVal pintPrec As Byte, ByVal pintSize As Integer, _
            ByVal pstrValue As Object) As ADODB.Parameter

        Dim dbparam As ADODB.Parameter

        dbparam = New ADODB.Parameter
        dbparam.Name = pstrName
        dbparam.Direction = pdbdir
        dbparam.Type = pdbtype
        dbparam.Precision = pintPrec
        dbparam.Size = pintSize
        dbparam.Value = pstrValue

        Return dbparam
    End Function
#End Region

End Class
