Public Class clsTable
    '========================================================================================='
    '   Name : clsTable
    '
    '   Description : This is the class which stores the table information.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Properties/Variables"

    Private strTable As String

    '---------------------------------------------------------------------------------------
    ' Name : Name
    '
    '---------------------------------------------------------------------------------------
    Public Property Name() As String
        Get
            Return strTable
        End Get
        Set(ByVal value As String)
            strTable = value
        End Set
    End Property

#End Region

End Class
