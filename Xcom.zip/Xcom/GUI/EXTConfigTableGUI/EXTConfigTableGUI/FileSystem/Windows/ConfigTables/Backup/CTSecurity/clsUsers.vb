Public Class clsUsers
    '========================================================================================='
    '   Name : clsUsers
    '
    '   Description : This is the class which stores the Users and user groups.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

    Private intUserCount As Integer
    Private UserId() As Object

	'---------------------------------------------------------------------------------------
	' Name : User
	'
	'---------------------------------------------------------------------------------------
    Public Property User(ByVal pintIndex As Integer) As Object
        Get
            Return UserId(pintIndex)
        End Get
        Set(ByVal value As Object)
            UserId(pintIndex) = value
        End Set
    End Property

	'---------------------------------------------------------------------------------------
	' Name : UserCount
	'
	'---------------------------------------------------------------------------------------
    Public ReadOnly Property UserCount() As Integer
        Get
            Return intUserCount
        End Get
    End Property

#Region "Private Methods"

    '---------------------------------------------------------------------------------------
    ' Name : Init
    '           Initializes the objects.
    ' Parameters :
    ' pintCount
    '---------------------------------------------------------------------------------------
    Public Sub Init(ByVal pintCount As Integer)
        ReDim UserId(pintCount)
        intUserCount = pintCount
    End Sub

#End Region
End Class
