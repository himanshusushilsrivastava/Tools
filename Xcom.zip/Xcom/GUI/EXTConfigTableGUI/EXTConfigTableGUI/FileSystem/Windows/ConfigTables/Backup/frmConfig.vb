Imports System.Reflection

Public Class frmConfig
    '========================================================================================='
    '   Name : frmConfig
    '
    '   Description :   This form displays the Table data and menu items to update the data.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '   Modified date: 07/28/2009   - Ver 1.1 Modified for SRS 22926  - Cognizant Offshore.
    '   Modified date: 01/25/2010   - Ver 1.2 Modified for SRS 35184  - Cognizant Offshore.
    '   Modified date: 02/19/2010   - Ver 1.3 Modified for UCR Comments - Cognizant Offshore.
    '========================================================================================='

#Region " Private Variables/Properties "

    Private dataModel As New clsDataModel
    Private boolRowStateUpd As Boolean
    Private boolRowStateIns As Boolean
    Private intFirstVisibleCol As Integer
    Private intLastVisibleCol As Integer
    Private dvTableData As DataView

    '---------------------------------------------------------------------------------------
    ' Name : Model
    '
    '---------------------------------------------------------------------------------------
    Public Property Model() As clsDataModel
        Get
            Return dataModel
        End Get
        Set(ByVal value As clsDataModel)
            dataModel = value
        End Set
    End Property

#End Region

#Region " Private Events "

    '---------------------------------------------------------------------------------------
    ' Name : grdConfig_DataError
    '
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Public Sub EnableDoubleBuffered(ByVal dgv As DataGridView)

        Dim dgvType As Type = dgv.[GetType]()

        Dim pi As PropertyInfo = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)

        pi.SetValue(dgv, True, Nothing)

    End Sub

    Private Sub grdConfig_DataError(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles grdConfig.DataError
        If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdConfig.Rows(e.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) _
                                = clsUtil.RowState.Inserted Or _
                                clsUtil.GetToInteger(clsUtil.FormatForInteger(grdConfig.Rows(e.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) _
                                = clsUtil.RowState.Updated Then
            If clsUtil.GetDataType(dataModel.ColType(grdConfig.Columns(e.ColumnIndex).Name)) = "System.DateTime" Then
                grdConfig.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = ""
                e.Cancel = False
            End If

        End If
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : grdConfig_CellValidating
    '
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub grdConfig_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles grdConfig.CellValidating
        Dim dr As DataRow
        Dim strDB As String = Nothing
        Dim lstCol As List(Of String)
        Dim grdcbocell As DataGridViewComboBoxCell

        If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdConfig.Rows(e.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) _
                = clsUtil.RowState.Inserted Or _
                clsUtil.GetToInteger(clsUtil.FormatForInteger(grdConfig.Rows(e.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) _
                = clsUtil.RowState.Updated Then
            If dataModel.SelectedTable = clsUtil.COL_LST_TBL Then
                If grdConfig.Columns(e.ColumnIndex).Name = "TABLE_NAME" Then
                    If e.FormattedValue.ToString.Trim = "" Then
                        MsgBox("Select value for " & grdConfig.Columns(e.ColumnIndex).Name, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        e.Cancel = True
                        Exit Sub
                    End If
                    For Each dr In dataModel.DBTblList.Select("TBL_NM='" & e.FormattedValue.ToString & "'")
                        strDB = dr.Item("DB").ToString
                    Next
                    If dataModel.CheckTableExists(e.FormattedValue.ToString, strDB) = False Then
                        MsgBox("Table does not exists.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        e.Cancel = True
                        Exit Sub
                    End If
                    lstCol = dataModel.GetCols(e.FormattedValue.ToString, strDB, "char")
                    grdConfig.Rows(e.RowIndex).Cells("USUS_ID_COL_NAME").Dispose()
                    grdcbocell = New DataGridViewComboBoxCell()
                    grdcbocell.DataSource = lstCol
                    grdConfig.Rows(e.RowIndex).Cells("USUS_ID_COL_NAME") = grdcbocell

                    lstCol = dataModel.GetCols(e.FormattedValue.ToString, strDB, "date")
                    grdConfig.Rows(e.RowIndex).Cells("CREATE_DT_COL_NAME").Dispose()
                    grdcbocell = New DataGridViewComboBoxCell()
                    grdcbocell.DataSource = lstCol
                    grdConfig.Rows(e.RowIndex).Cells("CREATE_DT_COL_NAME") = grdcbocell
                End If
            End If
        End If

    End Sub
    '---------------------------------------------------------------------------------------
    ' Name : frmConfig_Load
    '           Refreshes the screen and enables or disables the Menu items.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub frmConfig_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshScreen()
        EnableDoubleBuffered(grdConfig)
        grdConfig.VirtualMode = True
        PopulateDB()
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdOK_Click
    '           Checks for unsaved and load the table data along with table information.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Dim intColId As Integer
        Dim result As MsgBoxResult
        Dim intCount As Integer
        Dim strSelectedTable As String
        Dim strSelectedDB As String
        Dim strKeys As String

        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        'Checking for unsaved data
        If CheckUnsavedData() Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            result = MsgBox("Table data modified. Do you wish to Save?", MsgBoxStyle.YesNoCancel, clsUtil.APPLICATION_CAPTION)
            Me.Cursor = Windows.Forms.Cursors.WaitCursor
            If result = MsgBoxResult.Yes Then
                If Save() = False Then
                    Me.Cursor = Windows.Forms.Cursors.Arrow
                    Exit Sub
                End If
            ElseIf result = MsgBoxResult.Cancel Then
                Me.Cursor = Windows.Forms.Cursors.Arrow
                Exit Sub
            End If
        End If

        RefreshScreen()

        'Checking for Selected Table and DB
        If cboDatabase.SelectedItem Is Nothing Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Select Database.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        If cboTable.SelectedItem Is Nothing Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Select Table.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        strSelectedTable = clsUtil.FormatForString(cboTable.SelectedItem)
        strSelectedDB = clsUtil.FormatForString(cboDatabase.SelectedItem)

        dataModel.SelectedDB = strSelectedDB
        dataModel.SelectedTable = strSelectedTable

        'Setting the value for selected Table and DB
        For Each intCount In dataModel.GetDBIDs
            If dataModel.DB(intCount).DBName = strSelectedDB Then
                dataModel.SelectedDBIndex = intCount
                Exit For
            End If
        Next

        intCount = 0
        While intCount < dataModel.DB(dataModel.SelectedDBIndex).TableCount
            If dataModel.DB(dataModel.SelectedDBIndex).Tables(intCount).Name = strSelectedTable Then
                dataModel.SelectedTableIndex = intCount
                Exit While
            End If
            intCount = intCount + 1
        End While

        If dataModel.CheckTableExists(strSelectedTable, strSelectedDB) = False Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Database access not available or Table does not exists.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        'If dataModel.CheckReadPermission(strSelectedTable, strSelectedDB) = False Then
        '    Me.Cursor = Windows.Forms.Cursors.Arrow
        '    MsgBox("Read permission on the selected table not available from back-end.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
        '    Exit Sub
        'End If

        If Init() = False Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            If dataModel.GetColumnCount <= 0 Then
                MsgBox("Error in Database Operation.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            End If
            Exit Sub
        End If

        'Populating grid
        PopulateGrid()

        If strSelectedTable = clsUtil.MASTER_TABLE Then
            dataModel.GetDbAll()
        End If

        lblTableHeader.Text = "Table - " & strSelectedDB & " -> " & strSelectedTable

        'Displaying the Keys
        strKeys = "Keys - "

        For Each intColId In dataModel.GetColumnIDs
            If dataModel.Column(intColId).Key Then
                strKeys = strKeys & dataModel.Column(intColId).ColName & ", "
            End If
            If dataModel.Column(intColId).Identity Then
                strKeys = strKeys & dataModel.Column(intColId).ColName & "(Identity) , "
            End If
        Next
        If strKeys <> "Keys - " Then
            strKeys = Mid(strKeys, 1, strKeys.LastIndexOf(", "))
            txtKeys.Text = strKeys
        End If

        mnuSave.Enabled = False
        mnuCancel.Enabled = False
        If dataModel.DB(dataModel.SelectedDBIndex).Tables(dataModel.SelectedTableIndex).Permissions.Insert Then
            mnuAdd.Enabled = True
        End If
        If dataModel.DB(dataModel.SelectedDBIndex).Tables(dataModel.SelectedTableIndex).Permissions.Update Then
            mnuUpdate.Enabled = True
        End If
        mnuSave.Enabled = True
        mnuAdd.Enabled = True
        mnuUpdate.Enabled = True

        grdConfig.Select()

        Me.Cursor = Windows.Forms.Cursors.Arrow
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : mnuAdd_Click
    '           Invokes when AddMenu is selected, Adds a row for the table.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub mnuAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdd.Click
        Dim intColID As Integer
        Dim lstUID As List(Of String)
        Dim lstDt As List(Of String)
        Dim objCol As clsCol

        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        If dataModel.CheckInsertPermission(dataModel.SelectedTable, dataModel.SelectedDB) = False Then

            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Insert permission on the selected table not available from back-end.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        If boolRowStateIns = False And boolRowStateUpd = False Then
            boolRowStateIns = True
            If grdConfig.SortedColumn Is Nothing Then
                lstUID = dataModel.GetUIDColName
                lstDt = dataModel.GetDateColName

                For Each intColID In dataModel.GetColumnIDs
                    objCol = dataModel.Column(intColID)
                    If boolRowStateUpd = True Or boolRowStateIns = True Then
                        grdConfig.Columns.Item(objCol.ColName).SortMode = DataGridViewColumnSortMode.Programmatic
                        If lstUID.Contains(objCol.ColName) Or lstDt.Contains(objCol.ColName) Then
                            grdConfig.Columns(objCol.ColName).Visible = False
                        End If
                    End If
                Next

            Else
                PopulateGrid()
            End If
            mnuUpdate.Enabled = False
        End If

        RowAdd()

        mnuSave.Enabled = True
        mnuCancel.Enabled = True

        Me.Cursor = Windows.Forms.Cursors.Arrow
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : mnuUpdate_Click
    '           Invoked when Update Menu is selected, enables a row to update.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub mnuUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUpdate.Click

        Dim grdrow As DataGridViewRow
        Dim grdcellSelected As DataGridViewCell
        Dim lstRow As New List(Of Integer)
        Dim intRowIndex As Integer
        Dim dr As DataRow
        Dim intColID As Integer
        Dim lstUID As List(Of String)
        Dim lstDt As List(Of String)
        Dim objCol As clsCol

        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        If dataModel.CheckUpdatePermission(dataModel.SelectedTable, dataModel.SelectedDB) = False Then

            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Update permission on the selected table not available from back-end.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Exit Sub
        End If

        grdConfig.EndEdit()

        For Each grdcellSelected In grdConfig.SelectedCells
            grdrow = grdConfig.Rows(grdcellSelected.RowIndex)
            If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) _
                    = clsUtil.RowState.Inserted Or _
                    clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) _
                    = clsUtil.RowState.Updated _
                    Then
                Continue For
            End If

            dr = (CType(grdConfig.Rows(grdrow.Index).DataBoundItem, DataRowView)).Row

            If lstRow.Contains(dvTableData.Table.Rows.IndexOf(dr)) = False Then
                lstRow.Add(dvTableData.Table.Rows.IndexOf(dr))
            End If

        Next

        If boolRowStateIns = False And boolRowStateUpd = False Then
            boolRowStateUpd = True
            If grdConfig.SortedColumn Is Nothing Then
                lstUID = dataModel.GetUIDColName
                lstDt = dataModel.GetDateColName

                For Each intColID In dataModel.GetColumnIDs
                    objCol = dataModel.Column(intColID)
                    If boolRowStateUpd = True Or boolRowStateIns = True Then
                        grdConfig.Columns.Item(objCol.ColName).SortMode = DataGridViewColumnSortMode.Programmatic
                        If lstUID.Contains(objCol.ColName) Or lstDt.Contains(objCol.ColName) Then
                            grdConfig.Columns(objCol.ColName).Visible = False
                        End If
                    End If
                Next

            Else
                PopulateGrid()
            End If
            mnuAdd.Enabled = False
        End If


        For Each intRowIndex In lstRow
            RowUpdate(intRowIndex)
        Next

        mnuSave.Enabled = True
        mnuCancel.Enabled = True

        Me.Cursor = Windows.Forms.Cursors.Arrow
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cboDatabase_SelectedIndexChanged
    '           Event invoked when Database drop down selection is changed.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cboDatabase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDatabase.SelectedIndexChanged
        PopulateTable(cboDatabase.SelectedIndex)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : mnuSave_Click
    '           Invokes when Save command is selected, saves the unsaved data.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub mnuSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuSave.Click
        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        If Save() Then
            If Init() = False Then
                Me.Cursor = Windows.Forms.Cursors.Arrow
                If dataModel.GetColumnCount <= 0 Then
                    MsgBox("Error in fetching data.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                End If
                Exit Sub
            End If

            mnuAdd.Enabled = True
            mnuUpdate.Enabled = True

            boolRowStateUpd = False
            boolRowStateIns = False

            dataModel.RemoveAllUpdCol()

            PopulateGrid()

        End If

        Me.Cursor = Windows.Forms.Cursors.Arrow
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : mnuExit_Click
    '           Invokes when Exit menu is selected, closes the screen.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub mnuExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : mnuCancel_Click
    '           Invoked when Cancel menu is selected, cancels the selected rows from updation
    '           or addition.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub mnuCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCancel.Click
        Me.Cursor = Windows.Forms.Cursors.WaitCursor
        dataModel.TableData = dataModel.KeyTable.Copy

        mnuAdd.Enabled = True
        mnuUpdate.Enabled = True

        boolRowStateUpd = False
        boolRowStateIns = False

        PopulateGrid()

        dataModel.RemoveAllUpdCol()

        Me.Cursor = Windows.Forms.Cursors.Arrow
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : grdConfig_CellDoubleClick
    '           Invokes when a cell in frmConfig grid is double clicked, makes the row 
    '           enabled for editing.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub grdConfig_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdConfig.CellDoubleClick
        If e.RowIndex >= 0 Then
            If boolRowStateUpd = True Then
                If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdConfig.Rows(e.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) = _
                    clsUtil.RowState.Unchanged Then
                    RowUpdate(e.RowIndex)
                End If
            End If
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : ProcessCmdKey
    '           Invokes when any key is pressed, checks if key is enter and makes the row
    '           editable or adds a new row.
    ' Parameters :
    ' msg
    ' keyData
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean

        Dim grdrow As DataGridViewRow

        If grdConfig.Focused Then

            If msg.WParam.ToInt32() = CInt(Keys.Enter) Then
                If grdConfig.Rows.Count > 0 Then
                    If clsUtil.GetToInteger(clsUtil.FormatForString(grdConfig.Rows(grdConfig.CurrentCell.RowIndex).Cells(clsUtil.ROW_STATE_COL).Value)) _
                                                        = clsUtil.RowState.Inserted Then
                        If grdConfig.CurrentCell.ColumnIndex = grdConfig.Columns.GetLastColumn(DataGridViewElementStates.Visible, DataGridViewElementStates.None).Index Then
                            If grdConfig.CurrentCell.RowIndex = grdConfig.RowCount - 1 Then
                                RowAdd()
                                SendKeys.Send("")
                                Return True
                                Exit Function
                            End If
                        End If
                    End If
                End If

                If boolRowStateUpd = True Then

                    grdrow = grdConfig.Rows(grdConfig.CurrentCell.RowIndex)
                    If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) _
                                                                                    = clsUtil.RowState.Unchanged Then
                        RowUpdate(grdrow.Index)
                    End If

                    grdConfig.CurrentCell = grdConfig.CurrentRow.Cells(intFirstVisibleCol)
                    grdConfig.BeginEdit(True)
                    SendKeys.Send("")
                    Return True
                End If

            End If
        End If

        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : frmConfig_FormClosing
    '           Invoked when form is closing, checks for unsaved data.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub frmConfig_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim result As MsgBoxResult
        If CheckUnsavedData() = True Then
            result = MsgBox("Table data modified. Do you wish to Save?", MsgBoxStyle.YesNoCancel, clsUtil.APPLICATION_CAPTION)
            If result = MsgBoxResult.Yes Then
                If Save() = False Then
                    e.Cancel = True
                End If
            ElseIf result = MsgBoxResult.Cancel Then
                e.Cancel = True
            End If
        End If
    End Sub

#End Region

#Region " Private Methods"

    '---------------------------------------------------------------------------------------
    ' Name : RefreshScreen
    '           Refereshes the screen.
    '---------------------------------------------------------------------------------------
    Private Sub RefreshScreen()
        mnuAdd.Enabled = False
        mnuUpdate.Enabled = False
        mnuAudit.Enabled = False
        mnuSave.Enabled = False
        mnuCancel.Enabled = False

        dataModel.SelectedDBIndex = -1
        dataModel.SelectedTableIndex = -1

        txtKeys.Text = "Keys - None"
        lblTableHeader.Text = "Table - Unassigned"

        boolRowStateUpd = False
        boolRowStateIns = False

        grdConfig.DataSource = Nothing
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : PopulateDB
    '           Populates the DB drop down.
    '---------------------------------------------------------------------------------------
    Private Sub PopulateDB()
        Dim intDBId As Integer
        cboDatabase.Items.Clear()
        For Each intDBId In dataModel.GetDBIDs
            cboDatabase.Items.Add(dataModel.DB(intDBId).DBName)
        Next
        If cboDatabase.Items.Count > 0 Then
            cboDatabase.SelectedIndex = 0
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : CheckData
    '           Checks the data of a row.
    ' Parameters :
    ' pintRowIndex
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function CheckData(ByVal pintRowIndex As Integer) As Boolean

        Dim strValue As String
        Dim strType As String
        Dim strColName As String
        Dim intColId As Integer
        Dim intLastIndex As Integer
        Dim strMaxValue As String
        Dim strColType As String
        Dim objCol As clsCol

        For Each intColId In dataModel.GetColumnIDs
            objCol = dataModel.Column(intColId)
            strColType = objCol.Type
            strType = clsUtil.GetDataType(strColType)
            strColName = objCol.ColName
            strValue = clsUtil.FormatForString(grdConfig.Rows(pintRowIndex).Cells(strColName).Value)

            If dataModel.Column(intColId).Identity Then
                Continue For
            End If
            If dataModel.CheckUserIdColName(objCol.ColName) Then
                grdConfig.Rows(pintRowIndex).Cells(strColName).Value = dataModel.User
                Continue For
            End If
            If dataModel.CheckDateColName(objCol.ColName) Then
                grdConfig.Rows(pintRowIndex).Cells(strColName).Value = DateTime.Now
                Continue For
            End If

            If clsUtil.FormatForString(grdConfig.Rows(pintRowIndex).Cells(strColName).Value) = "" Then
                If dataModel.Column(intColId).Nullable Then
                    Continue For
                Else
                    If strType = "System.String" And dataModel.SelectedTable <> clsUtil.MASTER_TABLE Then
                        Continue For
                    End If
                    MsgBox("Not Null Column. Enter " & dataModel.Column(intColId).Type & " value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                    grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                    grdConfig.BeginEdit(True)
                    Return False
                    Exit Function
                End If
            Else
                If strType = "System.DateTime" Then
                    If clsUtil.CheckValidDate(Trim(strValue)) = False Then
                        MsgBox("Enter Datetime value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                        grdConfig.BeginEdit(True)
                        Return False
                        Exit Function
                    End If
                    If grdConfig.Columns(strColName).ValueType.FullName.ToString = "System.DateTime" Then
                        If clsUtil.CheckValidDate(strValue) = False Then
                            MsgBox("Enter Datetime value for column " & grdConfig.Columns(strColName).Name, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            grdConfig.BeginEdit(True)
                            Return False
                            Exit Function
                        End If
                        If dataModel.ColType(grdConfig.Columns(strColName).Name) = "smalldatetime" Then
                            If clsUtil.CheckValidSmallDateTime(grdConfig.Rows(pintRowIndex).Cells(strColName).Value.ToString.Trim) = False Then
                                MsgBox("Enter Date between 01/01/1900 and 06/06/2079 for column " & grdConfig.Columns(strColName).Name, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                                grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                                grdConfig.BeginEdit(True)
                                Return False
                                Exit Function
                            End If

                        End If
                    End If
                ElseIf strType = "System.Decimal" Then
                    If strColType = "bit" Then
                        If clsUtil.CheckValidBoolean(strValue) = False Then
                            MsgBox("Enter Bit/Boolean value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            grdConfig.BeginEdit(True)
                            Return False
                            Exit Function
                        End If

                    Else
                        If clsUtil.CheckValidNumber(strValue) = False Then
                            MsgBox("Enter Numeric value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            grdConfig.BeginEdit(True)
                            Return False
                            Exit Function

                        Else
                            If clsUtil.GetIntegerTypes(dataModel.Column(intColId).Type) = "Integer" Then
                                If clsUtil.CheckValidInteger(strValue) = False Then
                                    MsgBox("Enter Integer value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                                    grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                                    grdConfig.BeginEdit(True)
                                    Return False
                                    Exit Function
                                End If

                                If strColType = "tinyint" Then
                                    If (clsUtil.GetToInteger(strValue) > 255 Or clsUtil.GetToInteger(strValue) < 0) Then
                                        MsgBox("Enter integer between 0 to 256 value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                                        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                                        grdConfig.BeginEdit(True)
                                        Return False
                                        Exit Function
                                    End If
                                ElseIf strColType = "smallint" Then
                                    If (clsUtil.GetToInteger(strValue) > 32767 Or clsUtil.GetToInteger(strValue) < -32768) Then
                                        MsgBox("Enter integer between -32768 to 32767 value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                                        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                                        grdConfig.BeginEdit(True)
                                        Return False
                                        Exit Function
                                    End If
                                ElseIf strColType = "int" Then
                                    If (clsUtil.GetToInteger(strValue) > 2147483647 Or clsUtil.GetToInteger(strValue) < -2147483648) Then
                                        MsgBox("Enter integer between -2147483648 to 2147483647 value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                                        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                                        grdConfig.BeginEdit(True)
                                        Return False
                                        Exit Function
                                    End If
                                End If
                            End If
                        End If
                    End If


                ElseIf strType = "System.Boolean" Then
                    If clsUtil.CheckValidBoolean(strValue) = False Then
                        MsgBox("Enter Boolean value for column " & strColName, MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                        grdConfig.BeginEdit(True)
                        Return False
                        Exit Function
                    End If
                End If
                If dataModel.Column(intColId).Scale <> 0 Then
                    strMaxValue = ""
                    intLastIndex = 0
                    While intLastIndex < dataModel.Column(intColId).Length
                        strMaxValue = strMaxValue & "9"
                        intLastIndex = intLastIndex + 1
                    End While
                    intLastIndex = 0
                    strMaxValue = strMaxValue & "."
                    While intLastIndex < dataModel.Column(intColId).Scale
                        strMaxValue = strMaxValue & "9"
                        intLastIndex = intLastIndex + 1
                    End While

                    If strValue.LastIndexOf(".") >= 0 Then
                        intLastIndex = strValue.LastIndexOf(".")
                        If (Mid(strValue, 1, intLastIndex)).Length > dataModel.Column(intColId).Length Then
                            MsgBox("Max Value for " & strColName & " column is " & strMaxValue, MsgBoxStyle.Critical, _
                                            clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            Return False
                            Exit Function
                        End If
                        If (Mid(strValue, intLastIndex + 2)).Length > dataModel.Column(intColId).Scale Then
                            MsgBox("Max Value for " & strColName & " column is " & strMaxValue, MsgBoxStyle.Critical, _
                                            clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            Return False
                            Exit Function
                        End If
                    Else
                        If strValue.Length > dataModel.Column(intColId).Length Then
                            MsgBox("Max Value for " & strColName & " column is " & strMaxValue, MsgBoxStyle.Critical, _
                                            clsUtil.APPLICATION_CAPTION)
                            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(strColName)
                            Return False
                            Exit Function
                        End If
                    End If

                End If
            End If

        Next

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : Save
    '           Checks the data and Saves into the database.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function Save() As Boolean
        Dim grdrow As DataGridViewRow
        Dim intColId As Integer
        Dim dbHandler As clsDBHandler
        Dim intRowId As Integer
        Dim strValue As String
        Dim objCol As clsCol
        Dim intCount As Integer
        Dim strSelectedDB As String
        Dim strSelectedTable As String
        Dim lstRem As List(Of Integer)
        Dim boolCheck As Boolean

        grdConfig.EndEdit()
        'grdConfig.Rows(0).Cells(0).Style.Format = "MM/dd/yyyy HH:mm:ss fff tt" 'ver 1.1 'ver 1.2
        grdConfig.Rows(0).Cells(0).Style.Format = "MM/dd/yyyy HH:mm:ss tt" 'ver 1.2
        grdConfig.Update()
        grdConfig.BindingContext(grdConfig.DataSource).EndCurrentEdit()

        For Each intRowId In dataModel.GetUpdColIDs
            grdrow = grdConfig.Rows(intRowId)

            If CheckData(grdrow.Index) = False Then
                Return False
                Exit Function
            End If
            If CheckKeys(grdrow.Index) = False Then
                Return False
                Exit Function
            End If
            If dataModel.SelectedTable = clsUtil.COL_LST_TBL Then
                If CheckCols(grdrow.Index) = False Then
                    Return False
                    Exit Function
                End If
            End If
            If dataModel.SelectedTable = clsUtil.MASTER_TABLE Then
                If CheckTable() = False Then
                    Return False
                    Exit Function
                End If
            End If
        Next

        lstRem = New List(Of Integer)

        For Each intRowId In dataModel.GetUpdColIDs
            grdrow = grdConfig.Rows(intRowId)
            boolCheck = True
            If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) _
                        = clsUtil.RowState.Updated Then
                strValue = ""
                For Each intColId In dataModel.GetColumnIDs
                    objCol = dataModel.Column(intColId)
                    If dataModel.KeyTable.Rows(intRowId).Item(objCol.ColName).ToString <> _
                                dataModel.TableData.Rows(intRowId).Item(objCol.ColName).ToString Then
                        boolCheck = False
                    End If
                    'ver 1.1 New code block starts here
                    If (dataModel.TableData.Rows(intRowId).Item(intColId).GetType().ToString() = "System.DateTime") Then
                        ' grdrow.Cells(intColId).Style.Format = "MM/dd/yyyy HH:mm:ss fff tt" 'ver 1.2
                        grdrow.Cells(intColId).Style.Format = "MM/dd/yyyy HH:mm:ss tt" 'ver 1.2
                    End If
                    'ver 1.1 new code block ends here
                Next
                If boolCheck Then
                    dataModel.TableData.Rows(grdrow.Index).RejectChanges()
                    lstRem.Add(grdrow.Index)
                End If
            End If
        Next

        For Each intRowId In lstRem
            dataModel.RemoveUpdCol(intRowId)
        Next

        dataModel.TableData.AcceptChanges()

        dbHandler = clsDBHandler.GetDBHandler
        'dbHandler.BeginTransaction()
        If dataModel.UpdateTableData() = False Then
            MsgBox("Error in updating data.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            'dbHandler.RollbackTransaction()
            Return False
        Else
            If dataModel.InsertTableData() = False Then
                MsgBox("Error in adding data.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                'dbHandler.RollbackTransaction()
                Return False
            End If
        End If
        'dbHandler.CommitTransaction()

        If dataModel.Init = False Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Error while Initializing the Table and DB List.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            Return False
        End If

        If dataModel.SelectedTable = clsUtil.MASTER_TABLE Then
            PopulateDB()

            strSelectedDB = dataModel.SelectedDB
            strSelectedTable = dataModel.SelectedTable

            'Setting the value for selected Table and DB
            For Each intCount In dataModel.GetDBIDs
                If dataModel.DB(intCount).DBName = strSelectedDB Then
                    dataModel.SelectedDBIndex = intCount
                    Exit For
                End If
            Next

            intCount = 0
            While intCount < dataModel.DB(dataModel.SelectedDBIndex).TableCount
                If dataModel.DB(dataModel.SelectedDBIndex).Tables(intCount).Name = dataModel.SelectedTable Then
                    dataModel.SelectedTableIndex = intCount
                    Exit While
                End If
                intCount = intCount + 1
            End While

            cboDatabase.SelectedItem = strSelectedDB
            cboTable.SelectedItem = strSelectedTable
        End If
        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckTable
    '           Checks if the table exists.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function CheckTable() As Boolean
        Dim grdrow As DataGridViewRow

        For Each grdrow In grdConfig.Rows
            If clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) = clsUtil.RowState.Updated _
                Or clsUtil.GetToInteger(clsUtil.FormatForInteger(grdrow.Cells(clsUtil.ROW_STATE_COL).Value)) = clsUtil.RowState.Inserted _
                    Then
                If dataModel.CheckTableExists(clsUtil.FormatForString(grdrow.Cells("TABLE_NAME").Value), _
                        clsUtil.FormatForString(grdrow.Cells("DB_NAME").Value)) = False Then
                    MsgBox("Table does not exist.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                    grdConfig.CurrentCell = grdConfig.Rows(grdrow.Index).Cells(intFirstVisibleCol)
                    Return False
                    Exit Function
                End If
            End If

        Next

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckKeys
    '           Check the unique index columns for the specified row.
    ' Parameters :
    ' pintIndex
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function CheckKeys(ByVal pintIndex As Integer) As Boolean
        Dim grdrow As DataGridViewRow
        Dim intColId As Integer
        Dim boolIdentity As Boolean
        Dim strValue As String
        Dim objCol As clsCol

        boolIdentity = False
        For Each intColId In dataModel.GetColumnIDs
            If dataModel.Column(intColId).Identity Then
                boolIdentity = True
                Exit For
            End If
        Next

        grdrow = grdConfig.Rows(pintIndex)

        If boolIdentity = False Then
            If dataModel.DB(dataModel.SelectedDBIndex).Tables(dataModel.SelectedTableIndex).KeysCount > 0 Then
                strValue = ""
                For Each intColId In dataModel.GetColumnIDs
                    objCol = dataModel.Column(intColId)
                    If objCol.Key = True Then
                        If clsUtil.GetDataType(objCol.Type) = "System.DateTime" Then
                            If grdrow.Cells(objCol.ColName).Value.ToString.Trim = "" Then
                                strValue = strValue & " (" & objCol.ColName & " is " & "null" & " or "
                                strValue = strValue & objCol.ColName & "=" & "'')" & " and "
                            Else
                                strValue = strValue & objCol.ColName & "=" & "#" & _
                                                (CDate(grdrow.Cells(objCol.ColName).Value)) & _
                                                "#" & " and "
                            End If


                        Else

                            If grdrow.Cells(objCol.ColName).Value.ToString.Trim = "" Then
                                strValue = strValue & " (" & objCol.ColName & " is " & "null" & " or "
                                strValue = strValue & objCol.ColName & "=" & "'" & _
                                            clsUtil.FormatForString(grdrow.Cells(objCol.ColName).Value).Trim & _
                                            "')" & " and "
                            Else
                                strValue = strValue & objCol.ColName & "=" & "'" & _
                                            clsUtil.FormatForString(grdrow.Cells(objCol.ColName).Value).Trim & _
                                            "'" & " and "
                            End If



                        End If

                    End If
                Next

                strValue = Mid(strValue, 1, strValue.LastIndexOf(" and "))
                If dataModel.TableData.Select(strValue).Length > 1 Then
                    MsgBox("Attempt to insert duplicate key. Please check the values for the Keys.", _
                                                MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                    grdConfig.CurrentCell = grdConfig.Rows(pintIndex).Cells(intFirstVisibleCol)

                    Return False
                    Exit Function
                ElseIf boolRowStateIns Then
                    If dataModel.KeyTable.Select(strValue).Length > 0 Then
                        MsgBox("Attempt to insert duplicate key. Please check the values for the Keys.", _
                                            MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        grdConfig.CurrentCell = grdConfig.Rows(pintIndex).Cells(intFirstVisibleCol)

                        Return False
                        Exit Function
                    End If
                End If
            Else
                strValue = ""
                For Each intColId In dataModel.GetColumnIDs
                    objCol = dataModel.Column(intColId)

                    If clsUtil.GetDataType(objCol.Type) = "System.DateTime" Then
                        If grdrow.Cells(objCol.ColName).Value.ToString.Trim = "" Then
                            strValue = strValue & " (" & objCol.ColName & " is " & "null" & " or "
                            strValue = strValue & objCol.ColName & "=" & "'')" & " and "
                        Else
                            strValue = strValue & objCol.ColName & "=" & "#" & _
                                            (CDate(grdrow.Cells(objCol.ColName).Value)) & _
                                            "#" & " and "
                        End If


                    Else

                        If grdrow.Cells(objCol.ColName).Value.ToString.Trim = "" Then
                            strValue = strValue & " (" & objCol.ColName & " is " & "null" & " or "
                            strValue = strValue & objCol.ColName & "=" & "'" & _
                                        clsUtil.FormatForString(grdrow.Cells(objCol.ColName).Value).Trim & _
                                        "')" & " and "
                        Else
                            strValue = strValue & objCol.ColName & "=" & "'" & _
                                        clsUtil.FormatForString(grdrow.Cells(objCol.ColName).Value).Trim & _
                                        "'" & " and "
                        End If

                    End If
                Next
                strValue = Mid(strValue, 1, strValue.LastIndexOf(" and "))

                If dataModel.TableData.Select(strValue).Length > 1 Then
                    MsgBox("Attempt to insert duplicate key. Please check the values for the Keys.", _
                                                MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                    grdConfig.CurrentCell = grdConfig.Rows(pintIndex).Cells(intFirstVisibleCol)

                    Return False
                    Exit Function
                ElseIf boolRowStateIns Then
                    If dataModel.KeyTable.Select(strValue).Length > 0 Then
                        MsgBox("Attempt to insert duplicate key. Please check the values for the Keys.", _
                                            MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
                        grdConfig.CurrentCell = grdConfig.Rows(pintIndex).Cells(intFirstVisibleCol)

                        Return False
                        Exit Function
                    End If
                End If
            End If
        End If


        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : PopulateTable
    '           Populates the table drop down.
    ' Parameters :
    ' pintDBIndex
    '---------------------------------------------------------------------------------------
    Private Sub PopulateTable(ByVal pintDBIndex As Integer)
        cboTable.Items.Clear()

        Dim intCount As Integer

        For intCount = 0 To dataModel.DB(pintDBIndex).TableCount - 1
            cboTable.Items.Add(dataModel.DB(pintDBIndex).Tables(intCount).Name)
        Next
        If cboTable.Items.Count > 0 Then
            cboTable.SelectedIndex = 0
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : HideColumns
    '           Hide the columns which are updated by, date or indentity columns.
    ' Parameters :
    ' pintRowIndex
    '---------------------------------------------------------------------------------------
    Private Sub HideColumns(ByVal pintRowIndex As Integer)

        Dim grdrow As DataGridViewRow
        Dim strCol As String

        grdrow = grdConfig.Rows(pintRowIndex)
        For Each strCol In dataModel.IndentityCol
            grdConfig.Columns(strCol).Visible = False
        Next

        intFirstVisibleCol = grdConfig.Columns.GetFirstColumn(DataGridViewElementStates.Visible, DataGridViewElementStates.None).Index
        intLastVisibleCol = grdConfig.Columns.GetLastColumn(DataGridViewElementStates.Visible, DataGridViewElementStates.None).Index
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : CheckUnsavedData
    '           Checks if unsaved data is present in the Screen.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function CheckUnsavedData() As Boolean
        If dataModel.GetUpdColCount > 0 Then
            Return True
        End If
        Return False
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : Init
    '
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function Init() As Boolean
        If dataModel.GetData() = False Then
            Return False
            Exit Function
        End If
        dataModel.InitKeyTable()
        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : PopulateGrid
    '           Populates the grid.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function PopulateGrid() As Boolean
        Dim intColID As Integer
        Dim grdtxtcol As DataGridViewTextBoxColumn
        Dim strType As String
        Dim objCol As clsCol
        Dim lstUID As List(Of String)
        Dim lstDt As List(Of String)

        grdConfig.Columns.Clear()

        dvTableData = New DataView
        dvTableData.Table = dataModel.TableData

        Dim dv As New DataView
        dv.Table = dataModel.TableData
        grdConfig.DataSource = dv

        lstUID = dataModel.GetUIDColName
        lstDt = dataModel.GetDateColName

        For Each intColID In dataModel.GetColumnIDs
            objCol = dataModel.Column(intColID)
            strType = objCol.Type
            grdtxtcol = CType(grdConfig.Columns(objCol.ColName), DataGridViewTextBoxColumn)
            grdtxtcol.CellTemplate = New DataGridViewTextBoxCell()
            If clsUtil.GetDataType(strType) = "System.String" Or strType = "bit" Then
                grdtxtcol.MaxInputLength = objCol.Length
                'ver 1.1 new code block starts here
                'Begin ver 1.3
                'ElseIf clsUtil.GetDataType(strType).ToLower = "system.datetime" Then
            ElseIf clsUtil.GetDataType(strType).ToString() = "System.DateTime" Then
                'End ver 1.3
                'grdtxtcol.DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss fff tt" 'ver 1.2
                grdtxtcol.DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss tt"   'ver 1.2
                'ver 1.1 new code block ends here
            End If
            If dataModel.Column(intColID).Scale <> 0 Then
                grdtxtcol.MaxInputLength = objCol.Length + objCol.Scale + 1
            End If
            If boolRowStateUpd = True Or boolRowStateIns = True Then
                grdConfig.Columns.Item(objCol.ColName).SortMode = DataGridViewColumnSortMode.Programmatic
                If lstUID.Contains(objCol.ColName) Or lstDt.Contains(objCol.ColName) Then
                    grdConfig.Columns(objCol.ColName).Visible = False
                End If
            End If
        Next

        grdConfig.Columns(clsUtil.ROW_STATE_COL).Visible = False

        mnuCancel.Enabled = False
        mnuSave.Enabled = False

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : RowAdd
    '           Adds a Row
    '---------------------------------------------------------------------------------------
    Private Sub RowAdd()
        Dim dr As DataRow
        Dim font As Font
        Dim grdcbocell As DataGridViewComboBoxCell
        Dim intRowIndex As Integer
        Dim drTbl As DataRow


        dr = dataModel.TableData.Rows.Add()
        grdConfig.Refresh()

        intRowIndex = dr.Table.Rows.IndexOf(dr)
        HideColumns(intRowIndex)


        If dataModel.SelectedTable = clsUtil.MASTER_TABLE Then
            grdConfig.Rows(intRowIndex).Cells("DB_NAME").Dispose()
            grdcbocell = New DataGridViewComboBoxCell()
            grdcbocell.DataSource = dataModel.DBAll
            grdConfig.Rows(intRowIndex).Cells("DB_NAME") = grdcbocell
        End If

        If dataModel.SelectedTable = clsUtil.COL_LST_TBL Then
            grdConfig.Rows(intRowIndex).Cells("TABLE_NAME").Dispose()
            grdcbocell = New DataGridViewComboBoxCell()
            For Each drTbl In dataModel.DBTblList.Rows
                grdcbocell.Items.Add(drTbl.Item("TBL_NM"))
            Next
            grdConfig.Rows(intRowIndex).Cells("TABLE_NAME") = grdcbocell
            grdConfig.Rows(intRowIndex).Cells("TABLE_NAME").Value = grdcbocell.Items.Item(0)
        End If

        dataModel.AddUpdCol(intRowIndex, clsUtil.RowState.Inserted)

        grdConfig.Rows(intRowIndex).ReadOnly = False

        font = New Font(grdConfig.Font, FontStyle.Bold)
        grdConfig.Rows(grdConfig.RowCount - 1).DefaultCellStyle.Font = font
        grdConfig.Rows(grdConfig.RowCount - 1).Cells(clsUtil.ROW_STATE_COL).Value = clsUtil.RowState.Inserted
        grdConfig.CurrentCell = grdConfig.Rows(grdConfig.RowCount - 1).Cells(intFirstVisibleCol)
        grdConfig.BeginEdit(True)

    End Sub


    '---------------------------------------------------------------------------------------
    ' Name : RowUpdate
    '           Updates a Row
    ' Parameters :
    ' intRowIndex
    '---------------------------------------------------------------------------------------
    Private Sub RowUpdate(ByVal pintRowIndex As Integer)
        Dim font As Font
        Dim grdrow As DataGridViewRow
        Dim grdcbocell As DataGridViewComboBoxCell
        Dim strDB As String
        Dim dr As DataRow
        Dim intDBIndex As Integer
        Dim intTblIndex As Integer
        Dim objDB As clsDB

        grdrow = grdConfig.Rows(pintRowIndex)
        font = New Font(grdConfig.Font, FontStyle.Bold)
        grdConfig.Rows(pintRowIndex).DefaultCellStyle.Font = font

        grdrow.Cells(clsUtil.ROW_STATE_COL).Value = clsUtil.RowState.Updated
        grdrow.ReadOnly = False

        HideColumns(grdrow.Index)

        If dataModel.SelectedTable = clsUtil.MASTER_TABLE Then
            strDB = clsUtil.FormatForString(grdConfig.Rows(pintRowIndex).Cells("DB_NAME").Value)
            grdConfig.Rows(pintRowIndex).Cells("DB_NAME").Dispose()
            grdcbocell = New DataGridViewComboBoxCell()
            grdcbocell.DataSource = dataModel.DBAll
            grdConfig.Rows(pintRowIndex).Cells("DB_NAME") = grdcbocell
        End If

        If dataModel.SelectedTable = clsUtil.COL_LST_TBL Then
            grdConfig.Rows(pintRowIndex).Cells("TABLE_NAME").Dispose()
            grdcbocell = New DataGridViewComboBoxCell()
            For Each intDBIndex In dataModel.GetDBIDs
                objDB = dataModel.DB(intDBIndex)
                For intTblIndex = 0 To dataModel.DB(intDBIndex).TableCount - 1
                    grdcbocell.Items.Add(objDB.Tables(intTblIndex).Name)
                Next
            Next
            grdConfig.Rows(pintRowIndex).Cells("TABLE_NAME") = grdcbocell
        End If

        dr = (CType(grdConfig.Rows(pintRowIndex).DataBoundItem, DataRowView)).Row

        grdConfig.Rows(pintRowIndex).ReadOnly = False

        dataModel.AddUpdCol(dr.Table.Rows.IndexOf(dr), clsUtil.RowState.Updated)
        'ver 1.1 Code block ends here
        Dim i As Integer
        For i = 0 To dr.ItemArray.Length - 1
            If (dr.Item(i).GetType().ToString() = "System.DateTime") Then
                grdrow.Cells(i).Style.Format = "MM/dd/yyyy HH:mm:ss tt"
            End If
        Next
        'ver 1.1 - Code block ends here
        grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells(intFirstVisibleCol)
        grdConfig.BeginEdit(True)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : CheckCols
    '           Checks the column names entered for a specific table while entering values
    '           for the User Id and Date list table.
    ' Parameters :
    ' pintRowIndex
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckCols(ByVal pintRowIndex As Integer) As Boolean
        Dim dr As DataRow
        Dim strDB As String

        strDB = "fakpfpr0"
        For Each dr In dataModel.DBTblList.Select("TBL_NM='" & grdConfig.Rows(pintRowIndex).Cells("TABLE_NAME").Value.ToString & "'")
            strDB = dr.Item("DB").ToString
        Next

        If grdConfig.Rows(pintRowIndex).Cells("USUS_ID_COL_NAME").Value.ToString.Trim = "" And _
            grdConfig.Rows(pintRowIndex).Cells("CREATE_DT_COL_NAME").Value.ToString.Trim = "" _
            Then
            MsgBox("Select column names.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
            grdConfig.CurrentCell = grdConfig.Rows(pintRowIndex).Cells("USUS_ID_COL_NAME")
            Return False
        End If

        Return True
    End Function
#End Region

    'Begin Ver 1.3
    'Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    'End Sub

    'Private Sub grdConfig_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdConfig.CellContentClick

    'End Sub
    'End Ver 1.3
End Class
