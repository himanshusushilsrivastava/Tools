
Public Class frmSecurityConfigure
    '========================================================================================='
    '   Name : frmSecurityConfigure
    '
    '   Description :   This form configures the security information and saves into the database.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region " Private Variables/Properties "

    Private frmParent As frmSecurity
    Private objSecurityModel As New clsSecurityModel

    '---------------------------------------------------------------------------------------
    ' Name : SecurityModel
    '
    '---------------------------------------------------------------------------------------
    Public Property SecurityModel() As clsSecurityModel
        Get
            Return objSecurityModel
        End Get
        Set(ByVal value As clsSecurityModel)
            objSecurityModel = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : ParentSecurityForm
    '
    '---------------------------------------------------------------------------------------
    Public Property ParentSecurityForm() As frmSecurity
        Get
            Return frmParent
        End Get
        Set(ByVal value As frmSecurity)
            frmParent = value
        End Set
    End Property

#End Region

#Region " Private Events "

    '---------------------------------------------------------------------------------------
    ' Name : chkInsert_CheckedChanged
    '           Invokes when Insert check box is selected, selects all the Insert check 
    '           boxes in the grid.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub chkInsert_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInsert.CheckedChanged
        Dim grdr As DataGridViewRow
        For Each grdr In grdConfigure.Rows
            grdr.Cells("INS").Value = chkInsert.Checked
        Next
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : chkUpdate_CheckedChanged
    '           Invokes when Update check box is selected, selects all the update check 
    '           boxes in the grid.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub chkUpdate_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkUpdate.CheckedChanged
        Dim grdr As DataGridViewRow
        For Each grdr In grdConfigure.Rows
            grdr.Cells("UPD").Value = chkUpdate.Checked
        Next
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : cmdSave_Click
    '           Invoked when Save command is clicked, saves the data into the database.
    ' Parameters :
    ' sender
    ' e
    '---------------------------------------------------------------------------------------
    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim grdr As DataGridViewRow
        Dim dr As DataRow

        Me.Cursor = Windows.Forms.Cursors.WaitCursor

        SecurityModel.SecurityTable.Rows.Clear()
        For Each grdr In grdConfigure.Rows
            dr = SecurityModel.SecurityTable.Rows.Add()
            dr.Item("USUS_ID") = grdr.Cells("USUS_ID").Value
            dr.Item("DB_NAME") = grdr.Cells("DB_NAME").Value
            dr.Item("TABLE_NAME") = grdr.Cells("TABLE_NAME").Value

            If CType(grdr.Cells("INS").Value, Boolean) = True Then
                dr.Item("PERM_INS") = "Y"
            Else
                dr.Item("PERM_INS") = "N"
            End If

            If CType(grdr.Cells("UPD").Value, Boolean) = True Then
                dr.Item("PERM_UPD") = "Y"
            Else
                dr.Item("PERM_UPD") = "N"
            End If

        Next
        If SecurityModel.SaveSecurityTable() = False Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Error saving the information.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
        End If
        If SecurityModel.SelectSecurityTable = False Then
            Me.Cursor = Windows.Forms.Cursors.Arrow
            MsgBox("Re-Initialization failed.", MsgBoxStyle.Critical, clsUtil.APPLICATION_CAPTION)
        End If
        ParentSecurityForm.RefreshScreen()
        Me.Cursor = Windows.Forms.Cursors.Arrow
        Me.Close()
    End Sub

#End Region

End Class