Imports System.Xml

Public Class clsFacetsData
    '========================================================================================='
    '   Name : clsFacetsData
    '
    '   Description : This is the class to get the facets data.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '   1.1          06/24/2010     - Cognizant Offshore Changed for Facets 4.71 upgrade
    '
    '========================================================================================='

#Region "Private Variables"
    ' Facets Connection Object
    Public Shared extFacetsData As ErCoreIfcExtensionData.IFaExtensionData
#End Region

#Region "Private Methods"

    '---------------------------------------------------------------------------------------
    '
    ' Name : InitFacets
    '          This sub module is to get the connection details from the facets data amd 
    '       initializes our extension.
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InitFacets() As Boolean
        Dim strContextData As String
        Dim strFacetsData As String
        Dim strConnectionString As String
        Dim strUserID As String
        Dim frmSecurityForm As frmSecurity
        Dim dataModel As New clsSecurityModel

        strContextData = extFacetsData.GetContextData("")
        strFacetsData = extFacetsData.GetData("")
        strConnectionString = GetNodeData("SGN0", "Connection", strContextData)

        'Begin Version 1.1
        'checking whether facets application 431 or 471
        If (strConnectionString.IndexOf("UID=") = -1) Then
            strConnectionString = GetInnerNodeData(strConnectionString)
        End If
        'End Version 1.1

        strUserID = GetUserID(strConnectionString)
        strConnectionString = ReplaceConnectionInfo(strConnectionString)

        If InitDB(strConnectionString) = False Then
            Return False
        End If

        If dataModel.InitSecurity() Then
            frmSecurityForm = New frmSecurity()
            frmSecurityForm.SecurityModel = dataModel
            frmSecurityForm.ShowDialog()
        Else
            MsgBox("Initialization failed.", _
                        MsgBoxStyle.Information, clsUtil.APPLICATION_CAPTION)
            Exit Function
        End If

        Return True

    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : GetUserID
    '       The function returns the User ID from the provided connection String.
    ' Parameters :
    ' Connection String
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Function GetUserID(ByVal pstrConnectionString As String) As String
        Dim intStartLocation As Integer
        Dim intEndLocation As Integer
        Dim strUserID As String
        strUserID = ""

        intStartLocation = pstrConnectionString.IndexOf("UID=")

        If (intStartLocation > 0) Then
            intEndLocation = pstrConnectionString.IndexOf(";", intStartLocation)
            If intEndLocation < Len(pstrConnectionString) Then
                strUserID = Mid(pstrConnectionString, intStartLocation + 5, intEndLocation - intStartLocation - 4)
            End If
        End If

        Return strUserID
    End Function

    '---------------------------------------------------------------------------------------
    '   SetFacetsData
    '   -  Function to be invoked when click event is happen.
    '
    '    Parameters: - Facets Extension Datas.
    '
    '   Return Value: Boolean
    '---------------------------------------------------------------------------------------
    Public Function SetFacetsData(ByVal poExtData As ErCoreIfcExtensionData.IFaExtensionData, _
                        ByVal pstrCompId As String) As Boolean

        Try
            extFacetsData = poExtData
            Return InitFacets()
        Catch ex As Exception
            clsUtil.HandleError("Error occured while initializing extension.", ex)
            Return False
        End Try

    End Function
    'Begin Version 1.1
    '---------------------------------------------------------------------------------------
    '
    ' Name : GetInnerNodeData
    '       Generate the connection string from the contextdata.
    ' Parameters :
    '   pstrInnerXmlData : String
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Function GetInnerNodeData(ByVal pstrInnerXmlData As String) As String

        Dim facetsInnerDataNodes As XmlNodeList
        Dim facetsInnerDataNode As XmlNode
        Dim strFacetDataName As String
        Dim innerDocument As New XmlDocument
        innerDocument.LoadXml(pstrInnerXmlData)
        facetsInnerDataNodes = innerDocument.DocumentElement.ChildNodes
        strFacetDataName = ""
        'strFacetDataName = "DRIVER={Sybase ASE ODBC Driver};"

        For Each facetsInnerDataNode In facetsInnerDataNodes
            Select Case (facetsInnerDataNode.Name)
                Case "USERID"
                    strFacetDataName = strFacetDataName + "UID=" + facetsInnerDataNode.InnerText + ";"
                Case "PASSWORD"
                    strFacetDataName = strFacetDataName + "PWD=" + facetsInnerDataNode.InnerText + ";"
                    'strFacetDataName = strFacetDataName + "PWD=facets;"
                Case "DATABASE"
                    strFacetDataName = strFacetDataName + "DataBase=" + facetsInnerDataNode.InnerText + ";"
                Case "DATASOURCE"
                    strFacetDataName = strFacetDataName + "DSN=" + facetsInnerDataNode.InnerText + ";"
            End Select
        Next

        'strFacetDataName = strFacetDataName + "PS=4;APP=Facets Online;SM=0;OP=2;AUT=1;IS=Set ansinull off;"

        Return strFacetDataName
    End Function
    'End Version 1.1


    '---------------------------------------------------------------------------------------
    '
    ' Name : GetNodeData
    '       This function gets the Facets node data for the required node from the facets XML file.
    ' Parameters :
    ' Facets Data Name , Facets Collection Name, XmlData
    '
    ' Return value : String
    '---------------------------------------------------------------------------------------
    Public Function GetNodeData(ByVal pstrFacetsDataName As String, _
        ByVal pstrCollectionName As String, ByVal pstrXmlData As String) As String

        Dim facetsDataNodes As XmlNodeList
        Dim facetsDataNode As XmlNode
        Dim strFacetDataName As String
        Dim document As New XmlDocument
        Dim collectionNodes As XmlNodeList
        Dim collectionNode As XmlNode
        Dim strCollectionName As String

        document.LoadXml(pstrXmlData)
        facetsDataNodes = document.DocumentElement.ChildNodes

        For Each facetsDataNode In facetsDataNodes
            strFacetDataName = facetsDataNode.Attributes("name").Value
            If strFacetDataName = pstrFacetsDataName Then
                If pstrCollectionName = "" Then
                    Return facetsDataNode.InnerText()
                End If
                collectionNodes = facetsDataNode.ChildNodes()
                For Each collectionNode In collectionNodes
                    strCollectionName = collectionNode.Attributes("name").Value
                    If strCollectionName = pstrCollectionName Then
                        Return collectionNode.InnerText()
                    End If
                Next
            End If
        Next

        Return ""
    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : ReplaceConnectionInfo
    '           This function replaces the connection string with the SM mode as SM=0;
    ' Parameters :
    '   Connection String
    '
    ' Return value : Replaced Connection String
    '---------------------------------------------------------------------------------------
    Public Function ReplaceConnectionInfo(ByVal pstrConnectionString As String) _
                        As String

        Dim intStartLocation As Integer
        Dim intEndLocation As Integer
        Dim strReplaceString As String

        intStartLocation = pstrConnectionString.IndexOf("SM=")

        If (intStartLocation > 0) Then
            intEndLocation = pstrConnectionString.IndexOf(";", intStartLocation)
            strReplaceString = Left(pstrConnectionString, intStartLocation)
            strReplaceString = strReplaceString & "SM=0;"
            strReplaceString = strReplaceString & _
                    Right(pstrConnectionString, (Len(pstrConnectionString) - intEndLocation - 1))
        Else
            strReplaceString = pstrConnectionString
        End If

        Return strReplaceString

    End Function

    '---------------------------------------------------------------------------------------
    '
    ' Name : InitDB
    '       Initialise the database connection using DBHandler class.
    ' Parameters :
    '   Connection  String
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InitDB(ByVal pstrConnectionString As String) As Boolean
        Dim dbhandler As clsDBHandler

        Try
            dbhandler = clsDBHandler.GetDBHandler()
            dbhandler.strConnString = pstrConnectionString
            dbhandler.Init()
            Return True
        Catch ex As Exception
            clsUtil.HandleError("Error occured while database connection initialization.", ex)
            Return False
        End Try
    End Function

#End Region

End Class

