Option Explicit On

Imports System.Data
Imports System.Data.OleDb
Imports System.Reflection
Imports Microsoft.VisualBasic

Public Class clsDataModel
    '========================================================================================='
    '   Name : clsDataModel
    '
    '   Description :   This class stores all the data and methods related to the forms.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '   Modified date: 07/28/2009   - Ver 1.1 Modified for SRS 22926  - Cognizant Offshore.
    '                  01/25/2010   - Ver 1.2 Modified for SRS 35184  - Cognizant Offshore.
    '========================================================================================='

#Region "Private Properties/Variables"

    Private dtTableData As New DataTable
    Private dtKey As New DataTable

    Private dictColumnList As New Dictionary(Of Integer, clsCol)
    Private dictColTypeList As New Dictionary(Of String, String)
    Private dictDatabaseList As New Dictionary(Of Integer, clsDB)
    Private dtUIDDtColName As DataTable
    Private lstDBAll As New List(Of String)
    Private dictInsUpdColList As New Dictionary(Of Integer, Integer)
    Private dtDBTbl As DataTable
    Private lstIdenCol As New List(Of String)

    Private dbOperation As New clsDBOperations
    Private intSelectedTable As Integer
    Private intSelectedDB As Integer
    Private strSelectedTable As String
    Private strSelectedDB As String
    Private strUserId As String



	'---------------------------------------------------------------------------------------
	' Name : ColType
	'
	'---------------------------------------------------------------------------------------
    Public ReadOnly Property ColType(ByVal ID As String) As String
        Get
            Dim strValue As String = ""
            dictColTypeList.TryGetValue(ID, strValue)
            Return strValue
        End Get
    End Property
	'---------------------------------------------------------------------------------------
	' Name : IndentityCol
	'
	'---------------------------------------------------------------------------------------
    Public ReadOnly Property IndentityCol() As List(Of String)
        Get
            Return lstIdenCol
        End Get
    End Property
    '---------------------------------------------------------------------------------------
    ' Name : DBTblList
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property DBTblList() As DataTable
        Get
            Return dtDBTbl
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : User
    '           
    '---------------------------------------------------------------------------------------
    Public Property User() As String
        Get
            Return strUserId
        End Get
        Set(ByVal value As String)
            strUserId = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : SelectedTableIndex
    '           
    '---------------------------------------------------------------------------------------
    Public Property SelectedTableIndex() As Integer
        Get
            Return intSelectedTable
        End Get
        Set(ByVal value As Integer)
            intSelectedTable = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : SelectedDBIndex
    '           
    '---------------------------------------------------------------------------------------
    Public Property SelectedDBIndex() As Integer
        Get
            Return intSelectedDB
        End Get
        Set(ByVal value As Integer)
            intSelectedDB = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : SelectedTableIndex
    '           
    '---------------------------------------------------------------------------------------
    Public Property SelectedTable() As String
        Get
            Return strSelectedTable
        End Get
        Set(ByVal value As String)
            strSelectedTable = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : SelectedDBIndex
    '           
    '---------------------------------------------------------------------------------------
    Public Property SelectedDB() As String
        Get
            Return strSelectedDB
        End Get
        Set(ByVal value As String)
            strSelectedDB = value
        End Set
    End Property
    '---------------------------------------------------------------------------------------
    ' Name : TableData
    '
    '---------------------------------------------------------------------------------------
    Public Property TableData() As DataTable
        Get
            Return dtTableData
        End Get
        Set(ByVal value As DataTable)
            dtTableData = value
        End Set
    End Property


    '---------------------------------------------------------------------------------------
    ' Name : KeyTable
    '
    '---------------------------------------------------------------------------------------
    Public Property KeyTable() As DataTable
        Get
            Return dtKey
        End Get
        Set(ByVal value As DataTable)
            dtKey = value
        End Set
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Column
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property Column(ByVal ID As Integer) As clsCol
        Get
            Dim objCol As clsCol = Nothing
            dictColumnList.TryGetValue(ID, objCol)
            Return objCol
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : GetColumnIDs
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetColumnIDs() As ICollection(Of Integer)
        Return dictColumnList.Keys()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetColumnCount
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetColumnCount() As Integer
        Return dictColumnList.Count()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : DB
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property DB(ByVal ID As Integer) As clsDB
        Get
            Dim objDB As clsDB = Nothing
            dictDatabaseList.TryGetValue(ID, objDB)
            Return objDB
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : GetDBIDs
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetDBIDs() As ICollection(Of Integer)
        GetDBIDs = dictDatabaseList.Keys()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetDBCount
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetDBCount() As Integer
        GetDBCount = dictDatabaseList.Count()
    End Function

    Public ReadOnly Property DBAll() As List(Of String)
        Get
            Return lstDBAll
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : Column
    '
    '---------------------------------------------------------------------------------------
    Public ReadOnly Property UpdatedColumn(ByVal ID As Integer) As Integer
        Get
            Dim intValue As Integer
            intValue = -1
            dictInsUpdColList.TryGetValue(ID, intValue)
            Return intValue
        End Get
    End Property

    '---------------------------------------------------------------------------------------
    ' Name : GetColumnIDs
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetUpdColIDs() As ICollection(Of Integer)
        Return dictInsUpdColList.Keys()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetColumnCount
    '
    '
    ' Return value : Integer
    '---------------------------------------------------------------------------------------
    Public Function GetUpdColCount() As Integer
        Return dictInsUpdColList.Count()
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : AddUpdCol
    '           Add value into the updated column list
    ' Parameters :
    ' pintKey
    ' pstrVal
    '---------------------------------------------------------------------------------------
    Public Sub AddUpdCol(ByVal pintKey As Integer, ByVal pstrVal As Integer)
        dictInsUpdColList.Add(pintKey, pstrVal)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : RemoveUpdCol
    '           Removes value from the update col list
    ' Parameters :
    ' pintKey
    '---------------------------------------------------------------------------------------
    Public Sub RemoveUpdCol(ByVal pintKey As Integer)
        dictInsUpdColList.Remove(pintKey)
    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : RemoveAllUpdCol
    '
    '---------------------------------------------------------------------------------------
    Public Sub RemoveAllUpdCol()
        dictInsUpdColList.Clear()
    End Sub
#End Region

#Region "Private Methods"
    '---------------------------------------------------------------------------------------
    ' Name : Init
    '           Initializes the Main form data.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function Init() As Boolean

        If GetDb() = False Then
            Return False
            Exit Function
        End If

        If GetTable() = False Then
            Return False
            Exit Function
        End If

        If GetUIDDtColName() = False Then
            Return False
            Exit Function
        End If

        Return True
    End Function


    '---------------------------------------------------------------------------------------
    ' Name : GetUIDDtColName
    '           Gets all the UI and Date Column names.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetUIDDtColName() As Boolean
        Dim rs As New ADODB.Recordset
        Dim dr As DataRow

        rs = dbOperation.ExecuteSP("scs_cnfg_uid_dt_col_select", Nothing)

        If rs Is Nothing Then
            Return False
        End If

        dtUIDDtColName = New DataTable

        dtUIDDtColName.Columns.Add("Table_Name")
        dtUIDDtColName.Columns.Add("UIDColName")
        dtUIDDtColName.Columns.Add("DtColName")

        While Not rs.EOF
            dr = dtUIDDtColName.Rows.Add()
            dr.Item("Table_Name") = rs.Fields(0).Value
            dr.Item("UIDColName") = rs.Fields(1).Value
            dr.Item("DtColName") = rs.Fields(2).Value

            rs.MoveNext()
        End While

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetDb
    '           Gets the DB list from the Master Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetDb() As Boolean
        Dim rs As New ADODB.Recordset
        Dim intCount As Integer

        dtDBTbl = New DataTable
        dtDBTbl.Columns.Add("DB")
        dtDBTbl.Columns.Add("TBL_NM")

        rs = dbOperation.ExecuteSP("scs_cnfg_db_select", Nothing)

        If rs Is Nothing Then
            Return False
        End If

        intCount = 0
        dictDatabaseList.Clear()
        While Not rs.EOF

            Dim objDB As New clsDB
            objDB.DBName = clsUtil.FormatForString(rs.Fields(0).Value)
            dictDatabaseList.Add(intCount, objDB)
            ' go to next record in the results
            rs.MoveNext()

            intCount = intCount + 1
        End While

        rs.Close()

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetDbAll
    '           Gets the DB list from the table containing all the databases.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function GetDbAll() As Boolean
        Dim rs As New ADODB.Recordset

        rs = dbOperation.ExecuteSP("scs_cnfg_db_all_select", Nothing)

        If rs Is Nothing Then
            Return False
        End If

        lstDBAll.Clear()
        While Not rs.EOF

            lstDBAll.Add(clsUtil.FormatForString(rs.Fields(0).Value))
            ' go to next record in the results
            rs.MoveNext()
        End While

        rs.Close()

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetTable
    '           Gets the Table list from the Master Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Private Function GetTable() As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim intCount As Integer
        Dim intDBID As Integer
        Dim dr As DataRow

        For Each intDBID In GetDBIDs()

            dictParam.Clear()
            dbParam = New ADODB.Parameter
            dbParam.Name = "@pchDB"
            dbParam.Direction = ADODB.ParameterDirectionEnum.adParamInput
            dbParam.Type = ADODB.DataTypeEnum.adChar
            dbParam.Precision = 255
            dbParam.Size = 30
            dbParam.Value = DB(intDBID).DBName
            dictParam.Add(0, dbParam)
            rs = dbOperation.ExecuteSP("scs_cnfg_tables_select", dictParam)

            If rs Is Nothing Then
                Return False
            End If

            rs.MoveFirst()

            DB(intDBID).Init(rs.RecordCount)

            intCount = 0

            While Not rs.EOF

                dr = dtDBTbl.Rows.Add()
                dr.Item("DB") = DB(intDBID).DBName
                dr.Item("TBL_NM") = clsUtil.FormatForString(rs.Fields(0).Value)

                DB(intDBID).Tables(intCount).Name = clsUtil.FormatForString(rs.Fields(0).Value)

                If clsUtil.FormatForString(rs.Fields(1).Value) = "Y" Then
                    DB(intDBID).Tables(intCount).Permissions.Insert = True
                Else
                    DB(intDBID).Tables(intCount).Permissions.Insert = False
                End If

                If clsUtil.FormatForString(rs.Fields(2).Value) = "Y" Then
                    DB(intDBID).Tables(intCount).Permissions.Update = True
                Else
                    DB(intDBID).Tables(intCount).Permissions.Update = False
                End If

                ' go to next record in the results
                rs.MoveNext()

                intCount = intCount + 1
            End While

            rs.Close()
        Next

        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetData
    '           Get Column details and Table data
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function GetData() As Boolean
        Dim rs As ADODB.Recordset
        dictInsUpdColList.Clear()
        rs = GetTableCols(SelectedTable, SelectedDB)
        If rs Is Nothing Then
            Return False
            Exit Function
        End If
        SetCols(rs)
        If GetTableData() = False Then
            Return False
            Exit Function
        End If
        Return True
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetTableData
    '           Gets the Selected Table Data.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function GetTableData() As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dtTableData = New DataTable

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adChar, 255, 30, SelectedTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adChar, 255, 30, SelectedDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_exec_select", dictParam)

        If rs Is Nothing Then
            Return False
            Exit Function
        End If

        'recordset is closed
        If rs.State = 0 Then
            Return False
            Exit Function
        End If


        dtTableData = GetTableData(rs).Copy
        rs.Close()
        Return True
    End Function

    Private Sub SetCols(ByVal prs As ADODB.Recordset)
        Dim intCount As Integer
        Dim intKeysCount As Integer

        dictColTypeList.Clear()

        intCount = 0
        intKeysCount = 0

        While Not prs.EOF

            Dim objCol As New clsCol

            objCol.ColName = clsUtil.FormatForString(prs.Fields(0).Value)
            objCol.Type = clsUtil.FormatForString(prs.Fields(1).Value)

            dictColTypeList.Add(objCol.ColName, objCol.Type)

            objCol.Length = clsUtil.GetToInteger(clsUtil.FormatForInteger(prs.Fields(2).Value))
            If clsUtil.FormatForString(prs.Fields(3).Value) = "Y" Then
                objCol.Nullable = True
            Else
                objCol.Nullable = False
            End If
            If clsUtil.FormatForString(prs.Fields(4).Value) = "Y" Then
                objCol.Key = True
                intKeysCount = intKeysCount + 1
            Else
                objCol.Key = False
            End If
            If clsUtil.FormatForString(prs.Fields(5).Value) = "Y" Then
                objCol.Identity = True
                lstIdenCol.Add(clsUtil.FormatForString(prs.Fields(0).Value))
            Else
                objCol.Identity = False
            End If
            objCol.Scale = clsUtil.GetToInteger(clsUtil.FormatForInteger(prs.Fields(6).Value))

            dictColumnList.Add(intCount, objCol)

            ' go to next record in the results
            prs.MoveNext()

            intCount = intCount + 1
        End While

        DB(SelectedDBIndex).Tables(SelectedTableIndex).KeysCount = intKeysCount

        prs.Close()

    End Sub
    '---------------------------------------------------------------------------------------
    ' Name : GetTableCols
    '           Gets the columns related with the Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function GetTableCols(ByVal pstrTable As String, ByVal pstrDB As String) As ADODB.Recordset
        Dim rs As ADODB.Recordset
        'Dim strDBQuery As String
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dictColumnList.Clear()

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_col_detail_select", dictParam)

        If rs Is Nothing Then
            Return Nothing
        End If
        If rs.Fields.Count = 0 Then
            Return Nothing
        End If

        Return rs
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetTableData
    '           Coverts the table data received from the database into datatable.
    '
    ' Parameters :
    ' prstData - record set containing the Table data.
    '
    ' Return value : DataTable
    '---------------------------------------------------------------------------------------
    Public Function GetTableData(ByVal prstData As ADODB.Recordset) As DataTable
        Dim ds As New DataSet
        Dim dt As DataTable
        Dim dc As DataColumn
        Dim intColID As Integer
        Dim intCount As Integer

        Dim da As New System.Data.OleDb.OleDbDataAdapter

        dt = New DataTable(SelectedTable)
        intCount = 0

        'Create columns in the datatable
        For Each intColID In GetColumnIDs()
            If clsUtil.GetDataType(Column(intColID).Type) = "System.DateTime" Then
                dc = dt.Columns.Add(Column(intColID).ColName, Type.GetType("System.DateTime"))
                dc.DefaultValue = Nothing
                'dc.DateTimeMode.Format(Type.GetType("System.DateTime"), "", "MM-dd-yyyy HH:mm:SS")
                'dc.DateTimeMode = DataSetDateTime.Utc
            Else
                dc = dt.Columns.Add(Column(intColID).ColName, Type.GetType("System.String"))
                dc.DefaultValue = ""
            End If
        Next

        dt.Columns.Add(clsUtil.ROW_STATE_COL, Type.GetType("System.Decimal"))

        dt.Columns(clsUtil.ROW_STATE_COL).DefaultValue = clsUtil.RowState.Unchanged

        da.Fill(dt, prstData)

        'ds.Tables.Add(dt)

        Return dt
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : InsertTableData
    '           Insert the data into the selected table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function InsertTableData() As Boolean

        Dim strQuery As String
        Dim dr As DataRow
        Dim intColId As Integer
        Dim rs As ADODB.Recordset
        Dim strQueryVal As String
        Dim intLastIndex As Integer
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim intQueryLength As Integer
        Dim intUpdColKey As Integer
        Dim intKeyCount As Integer
        Dim strColType As String
        Dim strType As String
        Dim strColName As String
        Dim objCol As clsCol

        intKeyCount = DB(SelectedDBIndex).Tables(SelectedTableIndex).KeysCount

        For Each intUpdColKey In GetUpdColIDs()

            If UpdatedColumn(intUpdColKey) = clsUtil.RowState.Inserted Then
                dr = TableData.Rows(intUpdColKey)
                dictParam.Clear()
                strQuery = "("
                strQueryVal = ") VALUES("

                For Each intColId In GetColumnIDs()
                    objCol = dictColumnList(intColId)
                    strColName = objCol.ColName
                    strColType = objCol.Type
                    strType = clsUtil.GetDataType(objCol.Type)

                    If Column(intColId).Identity = False Then
                        If CheckDateColName(strColName) Then
                            strQuery = strQuery & strColName & ","
                            strQueryVal = strQueryVal & "GETDATE(),"
                        ElseIf CheckUserIdColName(strColName) Then
                            strQuery = strQuery & strColName & ","
                            strQueryVal = strQueryVal & "'" & User & "',"
                        ElseIf strColType = "bit" Then
                            strQuery = strQuery & strColName & ","
                            If dr.Item(strColName).ToString.Trim = "" And objCol.Nullable Then
                                strQueryVal = strQueryVal & "NULL,"
                            Else
                                strQueryVal = strQueryVal & clsUtil.GetBit(dr.Item(strColName).ToString.Trim) & ","
                            End If

                        ElseIf strType = "System.Decimal" Then
                            If clsUtil.FormatForString(dr.Item(strColName).ToString) <> "" Then
                                strQuery = strQuery & Column(intColId).ColName & ","
                                strQueryVal = strQueryVal & clsUtil.FormatForString(dr.Item(strColName).ToString.Trim) & ","
                            End If
                        Else
                            strQuery = strQuery & Column(intColId).ColName & ","
                            If dr.Item(strColName).ToString.Trim = "" And objCol.Nullable Then
                                strQueryVal = strQueryVal & "NULL,"
                            Else
                                strQueryVal = strQueryVal & "'" & clsUtil.FormatForString(dr.Item(strColName).ToString.Trim) & "'" & ","
                            End If
                        End If
                    End If
                Next

                intLastIndex = strQueryVal.LastIndexOf(",")
                strQueryVal = Mid(strQueryVal, 1, intLastIndex)
                intLastIndex = strQuery.LastIndexOf(",")
                strQuery = Mid(strQuery, 1, intLastIndex)
                strQuery = strQuery & strQueryVal & ")"
                'rs = dbOperation.ExecuteQuery(strQuery)

                dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                                        ADODB.DataTypeEnum.adChar, 255, 30, SelectedDB)
                dictParam.Add(0, dbParam)

                dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, SelectedTable)
                dictParam.Add(1, dbParam)


                intQueryLength = strQuery.Length
                intQueryLength = clsUtil.GetToInteger(clsUtil.FormatForInteger(intQueryLength / 6))

                dbParam = GetParameter("@pvcQuery1", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(0, intQueryLength))
                dictParam.Add(2, dbParam)

                dbParam = GetParameter("@pvcQuery2", ADODB.ParameterDirectionEnum.adParamInput, _
                                        ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(intQueryLength, intQueryLength))
                dictParam.Add(3, dbParam)

                dbParam = GetParameter("@pvcQuery3", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(2 * intQueryLength, intQueryLength))
                dictParam.Add(4, dbParam)

                dbParam = GetParameter("@pvcQuery4", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(3 * intQueryLength, intQueryLength))
                dictParam.Add(5, dbParam)

                dbParam = GetParameter("@pvcQuery5", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(4 * intQueryLength, intQueryLength))
                dictParam.Add(6, dbParam)

                dbParam = GetParameter("@pvcQuery6", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(5 * intQueryLength))
                dictParam.Add(7, dbParam)

                rs = dbOperation.ExecuteSP("scs_cnfg_exec_insert", dictParam)
                If rs Is Nothing Then
                    Return False
                    Exit Function
                End If
            End If
        Next

        Return True

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : UpdateTableData
    '           Updates the data into the Selected Table.
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function UpdateTableData() As Boolean

        Dim strQuery As String
        Dim dr As DataRow
        Dim intColId As Integer
        Dim rs As ADODB.Recordset
        Dim strQueryWhere As String
        Dim intLastIndex As Integer
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim intQueryLength As Integer
        Dim intUpdColKey As Integer
        Dim intKeyCount As Integer
        Dim strColName As String
        Dim strColType As String
        Dim strType As String
        Dim objCol As clsCol

        intKeyCount = DB(SelectedDBIndex).Tables(SelectedTableIndex).KeysCount


        For Each intUpdColKey In GetUpdColIDs()
            If UpdatedColumn(intUpdColKey) = clsUtil.RowState.Updated Then
                dr = TableData.Rows(intUpdColKey)
                dictParam.Clear()
                strQuery = ""
                strQueryWhere = " WHERE "

                For Each intColId In GetColumnIDs()
                    objCol = dictColumnList(intColId)
                    strColName = objCol.ColName
                    strColType = objCol.Type
                    strType = clsUtil.GetDataType(objCol.Type)

                    If Column(intColId).Identity = False Then
                        If CheckDateColName(strColName) Then
                            strQuery = strQuery & strColName & "= GETDATE(),"

                        ElseIf CheckUserIdColName(strColName) Then
                            strQuery = strQuery & strColName & "= '" & User & "',"

                        ElseIf strColType = "bit" Then
                            If dr.Item(strColName).ToString.Trim = "" And objCol.Nullable Then
                                strQuery = strQuery & Column(intColId).ColName & "=NULL, "
                            Else
                                strQuery = strQuery & Column(intColId).ColName & "=" & clsUtil.GetBit(dr.Item(strColName).ToString.Trim) & ", "
                            End If

                            'ver 1.1 -- Added for Datetime column to update column properly - Code block starts here
                        ElseIf strColType = "datetime" Then
                            If dr.Item(strColName).ToString.Trim = "" And objCol.Nullable Then
                                strQuery = strQuery & Column(intColId).ColName & "=NULL, "
                            Else
                                'Begin ver 1.2
                                'strQuery = strQuery & Column(intColId).ColName & "= str_Replace('" & Convert.ToDateTime(dr.Item(strColName).ToString.Trim).ToString("MMM dd yyyy  hh:mm:ss:fff tt") & "', '000',  left(right(convert(char(26), " & Column(intColId).ColName & " , 109), 5), 3) " & ") " & ", "
                                strQuery = strQuery & Column(intColId).ColName & "= '" & Convert.ToDateTime(dr.Item(strColName).ToString.Trim).ToString("MMM dd yyyy  hh:mm:ss tt") & "'" & ", "
                                'End ver 1.2
                            End If
                            'ver 1.1 -- Code block ends here

                        ElseIf strType = "System.Decimal" Then
                            If clsUtil.FormatForString(dr.Item(strColName).ToString) <> "" Then
                                strQuery = strQuery & Column(intColId).ColName & "=" & clsUtil.FormatForString(dr.Item(strColName).ToString.Trim) & ","
                            End If

                        Else
                            If dr.Item(strColName).ToString.Trim = "" And objCol.Nullable Then
                                strQuery = strQuery & Column(intColId).ColName & "=NULL,"
                            Else
                                strQuery = strQuery & Column(intColId).ColName & "=" & "'" & clsUtil.FormatForString(dr.Item(strColName).ToString.Trim) & "'" & ","
                            End If
                        End If
                    End If


                    If intKeyCount > 0 Then
                        If Column(intColId).Key Then
                            If strColType = "text" Then
                                strQueryWhere = strQueryWhere

                            ElseIf strColType = "bit" Then
                                strQueryWhere = strQueryWhere & _
                                                strColName & "=" & _
                                                clsUtil.GetBit(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                " AND "

                            ElseIf strType = "System.Decimal" Then
                                'ver 1.1 - New block starts here
                                If clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) = "" Then
                                    strQueryWhere = strQueryWhere & _
                                                    strColName & "= NULL AND "
                                Else
                                    'ver 1.1 - New block ends here
                                    'Old block before ver 1.1
                                    strQueryWhere = strQueryWhere & _
                                                    strColName & "=" & _
                                                    clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                    " AND "
                                    'Old block before ver 1.1
                                End If 'ver 1.1
                                'ver 1.1 - New block starts here
                            Else
                                If clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) = "" Then
                                    strQueryWhere = strQueryWhere & "( " & _
                                                    strColName & "= '' or " & _
                                                    strColName & "= null ) AND "

                                ElseIf strColType = "datetime" Then 'new code introduced by ram
                                    strQueryWhere = strQueryWhere & _
                                                    "CONVERT(VARCHAR, CONVERT (DATETIME, " & strColName & "), 101) + " & _
                                                    "CONVERT(VARCHAR, CONVERT (DATETIME, " & strColName & "), 108) " & _
                                                    "= CONVERT(VARCHAR, CONVERT(DATETIME," & "'" & _
                                                    clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                    "'), 101 ) + " & _
                                                    "CONVERT(VARCHAR, CONVERT(DATETIME,'" & _
                                                    clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                    "'), 108 )" & " AND "
                                    'ver 1.1 - New block ends here
                                Else
                                    strQueryWhere = strQueryWhere & _
                                                    strColName & "=" & "'" & _
                                                    clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                    "'" & " AND "
                                End If
                            End If
                        End If
                    Else
                        If strColType = "text" Then
                            strQueryWhere = strQueryWhere

                        ElseIf strColType = "bit" Then
                            strQueryWhere = strQueryWhere & _
                                            strColName & "=" & _
                                            clsUtil.GetBit(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                            " AND "

                            'ver 1.1 New code block starts here
                        ElseIf strColType = "datetime" Then
                            strQueryWhere = strQueryWhere & _
                                            strColName & "= " & _
                                            " str_Replace('" & Convert.ToDateTime(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim).ToString("MMM dd yyyy  hh:mm:ss:fff tt") & "', '000',  left(right(convert(char(26), " & strColName & " , 109), 5), 3) " & ") " & _
                                            " AND "
                            'ver 1.1 New code block ends here

                        ElseIf strType = "System.Decimal" Then
                            'ver 1.1 New code block starts here
                            If clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) = "" Then
                                strQueryWhere = strQueryWhere & _
                                                strColName & "= NULL AND "

                                'ver 1.1 New code block ends here
                            Else
                                strQueryWhere = strQueryWhere & _
                                                strColName & "=" & _
                                                clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                " AND "
                            End If

                            'ver 1.1 New code block ends here
                        Else
                            If clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) = "" Then
                                strQueryWhere = strQueryWhere & "( " & _
                                                strColName & "= '' OR " & _
                                                strColName & "= NULL ) AND "
                            ElseIf CheckDateColName(strColName) Then
                                strQueryWhere = strQueryWhere & _
                                                "CONVERT(VARCHAR, CONVERT (DATETIME, " & strColName & "), 101) + " & _
                                                "CONVERT(VARCHAR, CONVERT (DATETIME, " & strColName & "), 108) " & _
                                                "= CONVERT(VARCHAR, CONVERT(DATETIME," & "'" & _
                                                clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                "'), 101 ) + " & _
                                                "CONVERT(VARCHAR, CONVERT(DATETIME,'" & _
                                                clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                                "'), 108 )" & " AND "

                                'ver 1.1 New code block ends here

                            Else
                                strQueryWhere = strQueryWhere & _
                                        Column(intColId).ColName & "=" & "'" & _
                                        clsUtil.FormatForString(KeyTable.Rows(intUpdColKey).Item(strColName).ToString.Trim) & _
                                        "'" & " AND "
                            End If
                        End If
                    End If

                Next

                intLastIndex = strQuery.LastIndexOf(",")
                strQuery = Mid(strQuery, 1, intLastIndex)
                strQuery = strQuery & strQueryWhere
                intLastIndex = strQuery.LastIndexOf("AND")
                strQuery = Mid(strQuery, 1, intLastIndex)


                dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                                        ADODB.DataTypeEnum.adChar, 255, 30, SelectedDB)
                dictParam.Add(0, dbParam)

                dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, SelectedTable)
                dictParam.Add(1, dbParam)


                intQueryLength = strQuery.Length
                intQueryLength = clsUtil.GetToInteger(clsUtil.FormatForInteger(intQueryLength / 6))

                dbParam = GetParameter("@pvcQuery1", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(0, intQueryLength))
                dictParam.Add(2, dbParam)

                dbParam = GetParameter("@pvcQuery2", ADODB.ParameterDirectionEnum.adParamInput, _
                                        ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(intQueryLength, intQueryLength))
                dictParam.Add(3, dbParam)

                dbParam = GetParameter("@pvcQuery3", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(2 * intQueryLength, intQueryLength))
                dictParam.Add(4, dbParam)

                dbParam = GetParameter("@pvcQuery4", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(3 * intQueryLength, intQueryLength))
                dictParam.Add(5, dbParam)

                dbParam = GetParameter("@pvcQuery5", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(4 * intQueryLength, intQueryLength))
                dictParam.Add(6, dbParam)

                dbParam = GetParameter("@pvcQuery6", ADODB.ParameterDirectionEnum.adParamInput, _
                                ADODB.DataTypeEnum.adVarChar, 255, 1900, strQuery.Substring(5 * intQueryLength))
                dictParam.Add(7, dbParam)

                rs = dbOperation.ExecuteSP("scs_cnfg_exec_update", dictParam)
                If rs Is Nothing Then
                    Return False
                    Exit Function
                End If

            End If

        Next

        Return True

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : InitKeyTable
    '           Initializes a coopy of the Table.
    '---------------------------------------------------------------------------------------
    Public Sub InitKeyTable()

        dtKey = New DataTable
        dtKey = TableData.Copy

    End Sub

    '---------------------------------------------------------------------------------------
    ' Name : CheckUserIdColName
    '           Checks if a column is User Id Column.
    '
    ' Parameters :
    ' pstrUIdColName - Column Name
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckUserIdColName(ByVal pstrUIdColName As String) As Boolean
        Dim dr As DataRow
        For Each dr In dtUIDDtColName.Select("Table_Name='" & SelectedTable & "'")
            If dr.Item("UIDColName").ToString = pstrUIdColName Then
                Return True
                Exit Function
            End If
        Next
        Return False
    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckDateColName
    '           Checks if a column is datetime Column for last update date.
    '
    ' Parameters :
    ' pstrDateColName
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckDateColName(ByVal pstrDateColName As String) As Boolean
        Dim dr As DataRow
        For Each dr In dtUIDDtColName.Select("Table_Name='" & SelectedTable & "'")
            If dr.Item("DtColName").ToString = pstrDateColName Then
                Return True
                Exit Function
            End If
        Next
        Return False
    End Function

	'---------------------------------------------------------------------------------------
	' Name : GetUIDColName
	'
	'
	' Return value : String
	'---------------------------------------------------------------------------------------
    Public Function GetUIDColName() As List(Of String)
        Dim dr As DataRow
        Dim lstCol As New List(Of String)

        For Each dr In dtUIDDtColName.Select("Table_Name='" & SelectedTable & "'")
            lstCol.Add(dr.Item("UIDColName").ToString)
        Next
        Return lstCol
    End Function


	'---------------------------------------------------------------------------------------
	' Name : GetDateColName
	'
	'
	' Return value : String
	'---------------------------------------------------------------------------------------
    Public Function GetDateColName() As List(Of String)
        Dim dr As DataRow
        Dim lstCol As New List(Of String)

        For Each dr In dtUIDDtColName.Select("Table_Name='" & SelectedTable & "'")
            lstCol.Add(dr.Item("DtColName").ToString)
        Next
        Return lstCol
    End Function
    '---------------------------------------------------------------------------------------
    ' Name : CheckTable
    '           Checks if the table is present in the Database.
    ' Parameters :
    ' pstrTable
    ' pstrDB
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckTableExists(ByVal pstrTable As String, ByVal pstrDB As String) As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_check_tbl", dictParam)

        If rs Is Nothing Then
            Return False
            Exit Function
        End If

        If clsUtil.FormatForString(rs.Fields(0).Value) = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function


    '---------------------------------------------------------------------------------------
    ' Name : CheckReadPermission
    '           Checks the back-end read permission on the table.
    ' Parameters :
    ' pstrTable
    ' pstrDB
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckReadPermission(ByVal pstrTable As String, ByVal pstrDB As String) As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_chck_select", dictParam)

        If rs Is Nothing Then
            Return False
            Exit Function
        End If

        If clsUtil.FormatForString(rs.Fields(0).Value) = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function


    '---------------------------------------------------------------------------------------
    ' Name : CheckInsertPermission
    '           Checks the back-end insert permission on the table.
    ' Parameters :
    ' pstrTable
    ' pstrDB
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckInsertPermission(ByVal pstrTable As String, ByVal pstrDB As String) As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_chck_insert", dictParam)

        If rs Is Nothing Then
            Return False
            Exit Function
        End If

        If clsUtil.FormatForString(rs.Fields(0).Value) = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : CheckUpdatePermission
    '           Checks the back-end update permission on the table.
    ' Parameters :
    ' pstrTable
    ' pstrDB
    '
    ' Return value : Boolean
    '---------------------------------------------------------------------------------------
    Public Function CheckUpdatePermission(ByVal pstrTable As String, ByVal pstrDB As String) As Boolean
        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_chck_update", dictParam)

        If rs Is Nothing Then
            Return False
            Exit Function
        End If

        If clsUtil.FormatForString(rs.Fields(0).Value) = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function

    '---------------------------------------------------------------------------------------
    ' Name : GetParameter
    '           Creates a ADODB parameter.
    ' Parameters :
    ' pstrName
    ' pdbdir
    '
    ' Return value : _
    '---------------------------------------------------------------------------------------
    Private Function GetParameter(ByVal pstrName As String, ByVal pdbdir As ADODB.ParameterDirectionEnum, _
            ByVal pdbtype As ADODB.DataTypeEnum, ByVal pintPrec As Byte, ByVal pintSize As Integer, _
            ByVal pstrValue As Object) As ADODB.Parameter

        Dim dbparam As ADODB.Parameter

        dbparam = New ADODB.Parameter
        dbparam.Name = pstrName
        dbparam.Direction = pdbdir
        dbparam.Type = pdbtype
        dbparam.Precision = pintPrec
        dbparam.Size = pintSize
        dbparam.Value = pstrValue

        Return dbparam
    End Function

    Public Function CheckCols(ByVal pstrTable As String, ByVal pstrDB As String, ByVal pstrCol As String, ByVal pstrType As String) As Boolean

        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        'Dim lstColNm As New List(Of String)

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        dbParam = GetParameter("@pvcColName", ADODB.ParameterDirectionEnum.adParamInput, _
        ADODB.DataTypeEnum.adChar, 255, 30, pstrCol)
        dictParam.Add(2, dbParam)

        dbParam = GetParameter("@pvcType", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrType)
        dictParam.Add(3, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_col_select", dictParam)

        If rs Is Nothing Then
            Return Nothing
            Exit Function
        End If

        While Not rs.EOF
            If clsUtil.FormatForString(rs.Fields(0).Value) = "N" Then
                Return False
            End If
            rs.MoveNext()
        End While

        Return True
    End Function


    Public Function GetCols(ByVal pstrTable As String, ByVal pstrDB As String, ByVal pstrType As String) As List(Of String)

        Dim rs As ADODB.Recordset
        Dim dictParam As New Dictionary(Of Integer, ADODB.Parameter)
        Dim dbParam As ADODB.Parameter
        Dim lstColNm As New List(Of String)

        dbParam = GetParameter("@pchTable", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrTable)
        dictParam.Add(0, dbParam)

        dbParam = GetParameter("@pchDB", ADODB.ParameterDirectionEnum.adParamInput, _
                        ADODB.DataTypeEnum.adChar, 255, 30, pstrDB)
        dictParam.Add(1, dbParam)

        dbParam = GetParameter("@pvcType", ADODB.ParameterDirectionEnum.adParamInput, _
                ADODB.DataTypeEnum.adChar, 255, 30, pstrType)
        dictParam.Add(2, dbParam)

        rs = dbOperation.ExecuteSP("scs_cnfg_cols_select", dictParam)

        If rs Is Nothing Then
            Return Nothing
            Exit Function
        End If

        lstColNm.Add("")
        While Not rs.EOF
            lstColNm.Add(clsUtil.FormatForString(rs.Fields(0).Value))
            
            rs.MoveNext()
        End While

        Return lstColNm
    End Function
#End Region

End Class
