Public Class clsTable
    '========================================================================================='
    '   Name : clsTable
    '
    '   Description : This is the class which stores the table information.
    '
    '   Create date: 04/09/2008     - Cognizant Offshore.
    '
    '
    '========================================================================================='

#Region "Private Properties/Variables"

    Private strTable As String
    Private objPerm As clsPerm
    Private intKeysCount As Integer

	'---------------------------------------------------------------------------------------
	' Name : Permissions
	'
	'---------------------------------------------------------------------------------------
    Public ReadOnly Property Permissions() As clsPerm
        Get
            Return objPerm
        End Get
    End Property

	'---------------------------------------------------------------------------------------
	' Name : Name
	'
	'---------------------------------------------------------------------------------------
    Public Property Name() As String
        Get
            Return strTable
        End Get
        Set(ByVal value As String)
            strTable = value
        End Set
    End Property

	'---------------------------------------------------------------------------------------
	' Name : KeysCount
	'
	'---------------------------------------------------------------------------------------
    Public Property KeysCount() As Integer
        Get
            Return intKeysCount
        End Get
        Set(ByVal value As Integer)
            intKeysCount = value
        End Set
    End Property

#End Region

#Region "Private Methods"

    '---------------------------------------------------------------------------------------
    ' Name : New
    '
    '---------------------------------------------------------------------------------------
    Sub New()
        objPerm = New clsPerm
    End Sub

#End Region
End Class
