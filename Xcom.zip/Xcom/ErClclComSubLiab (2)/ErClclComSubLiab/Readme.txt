Update 3/14/2016


SHIPPED FILES


        I.  FILES
 
		AssemblyInfo.cs
		ErClclComSubLiab.csproj
		ErClclComSubLiab.user
		SubLiability.cs
		ErClclComSubLiab.dll
		Interop.ErCoreIfcExtensionData.dll
		


	II. README FILE (This File)



VALIDATION:
The file(s) that this zip package installs can be found in the "List Of Files" sections.  Please verify that the file(s) received match this list.


                MODULE(S):  ErClclComSubLiab.dll, Interop.ErCoreIfcExtensionData.dll
                DESCRIPTION:  This file contains sample code for a Calculate Patient Liability Extension and an executable version of the extension.  


                VERIFICATION: For more information on using this extension please refer to the "Facets Extensibility Guide" -> "Sample Extensions-Facets Extensibilty" section on Customer Exchange.




LIST OF FILES

FILE NAME:
      			
	AssemblyInfo.cs
	ErClclComSubLiab.csproj
	ErClclComSubLiab.user
	SubLiability.cs
	ErClclComSubLiab.dll
	Interop.ErCoreIfcExtensionData.dll


CONTACT INFORMATION
If you have any questions about this update, please submit an incident to Support.


Copyright � 2016 TriZetto Corporation. All rights reserved. 
This material may be reproduced by or for the US Government to the extent permitted by the copyright license under DFARS 42:227-7013(e).
TriZetto�, the TriZetto logo, TriZetto.com, and certain names used by TriZetto in this document to identify products and services are registered or unregistered trademarks, trade names, service marks or logos (collectively, �Marks�) of TriZetto Corporation or its affiliates.  Many of TriZetto�s Marks are listed at www.trizetto.com/Trademarks/.  Other company, product and service names may be Marks of others.  All Marks used in this document, whether registered or unregistered, are the intellectual property of their respective owners and no rights are granted by TriZetto Corporation, to use such Marks, whether by implication, estoppel, or otherwise.
Restricted Rights Notice (Dec 2007) 
(a) This computer software is submitted with restricted rights under Government Contract. It may not be used, reproduced, or disclosed by the Government except as provided in paragraph (b) of this notice or as otherwise expressly stated in the contract.  
(b) This computer software may be- 
	(1) Used or copied for use with the computer(s) for which it was acquired, including use at any Government installation to which the computer(s) may be transferred; 
	(2) Used or copied for use with a backup computer if any computer for which it was acquired is inoperative; 
	(3) Reproduced for safekeeping (archives) or backup purposes; 
	(4) Modified, adapted, or combined with other computer software, provided that the modified, adapted, or combined portions of the derivative software incorporating any of the delivered, restricted computer software shall be subject to the same restricted rights; 
	(5) Disclosed to and reproduced for use by support service Contractors or their subcontractors in accordance with paragraphs (b)(1) through (4) of this notice; and 
	(6) Used or copied for use with a replacement computer. 
(c) Notwithstanding the foregoing, if this computer software is copyrighted computer software, it is licensed to the Government with the minimum rights set forth in paragraph (b) of this notice. 
(d) Any other rights or limitations regarding the use, duplication, or disclosure of this computer software are to be expressly stated in, or incorporated in, the contract. 
(e) This notice shall be marked on any reproduction of this computer software, in whole or in part.
