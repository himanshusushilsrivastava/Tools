﻿/* Begin Copyright 
*******************************************************************************
*
* Copyright (c) 2014-2015 The TriZetto Group, Inc. All rights reserved.
* This material may be reproduced by or for the US Government to the 
* extent permitted by the copyright license under DFARS 42:227-7013(e).
*
*******************************************************************************
 End Copyright */

using System;
using System.IO;
using System.Text;
using System.Xml;
using ErCoreIfcExtensionData;

/***************************************************************************************
 *  Example Subscriber Liability extension that will calculate 
 *      Claims Patient Liability amount at the line item level
 *      and update it to the appropriate CDML or CDDL field in the line item.
 *      
 *  Any Explanation Code for a disallow with a non blank EXCD_PT_LIAB_IND will be 
 *      added to the Patient Liability amount (CDML_DIS_PA_LIAB or CDDL_DIS_PA_LIAB).
 *      
 *  The CDML_DIS_PA_LIAB or CDDL_DIS_PA_LIAB will be added to the CDML_TOT_PA_LIAB (medical)
 *      or CDDL_TOT_PA_LIAB (dental) in addition to the copay, coinsurance and deductible amounts.
 * *       
 *  This C## extension should work on Sybase, Microsoft or Oracle databases.
 *  
 *  This example may be customized to check for a particular value in EXCD_PT_LIAB_IND
 *      and then added it to the patient liability amount.
 *      
 *  There is commented out code which may be used to dump the data sent to and from this extension
 *      for testing, and debugging purposes of this extension. 
 *      The code marked with SUBLIABLOG may be uncommented, however this code should not be 
 *      left executing for the production version of this extension.
 *   
 * **************************************************************************************
 */

namespace ErClclComSubLiab
{
    public class SubLiability
    {
        //////////// 
        // Globals
        ////////////

        // SUBLIABLOG begin
        //const string mksLogPath = "C:\\logs\\Subliab.log";
        //StreamWriter mcStmWriter;
        //string mcsDivider = "############################################################\n";
        // SUBLIABLOG end
       
        // Subscriber Liability Extension Timing
        public bool CalcSubLiab(ErCoreIfcExtensionData.IFaExtensionData ppiExtData, string pcsCompId)
        {
            bool lbRetVal = true;
            string lcsData, 
                   lcsModifiedData;
            string lcsDataId = ""; 

            // SUBLIABLOG begin
            // OpenLogFile(); 
            // // following logs the exit timing being used 
            // lcsData = ppiExtData.GetContextData(lcsDataId);
            // if (ppiExtData.LastResult)
            // {
            //     WriteOutput(lcsData);
            // }
            // SUBLIABLOG END

            XmlDocument allData = new XmlDocument();

            // GetData sent to the extension
            lcsData = ppiExtData.GetData(lcsDataId);

            if (ppiExtData.LastResult)
            {
                // load all the data to Xml Document
                allData.LoadXml(lcsData);

                // WriteOutput(lcsData); // SUBLIABLOG

                XmlNodeList nodelist = allData.SelectNodes("/FacetsData/Collection");

                foreach (XmlNode node in nodelist) // for each <collection> node
                {
                    string item;
                    item = node.Attributes.GetNamedItem("name").Value;

                    if (item == "CLCL")
                    {
                        string type;
                        XmlNode n = node.SelectSingleNode("Column[@name=\"CLCL_CL_TYPE\"]");

                        type = n.InnerText;

                        if ("M" == type)  // Medical claim
                        {
                            ProcessMedicalLiab(ppiExtData, nodelist);
                        }
                        else
                            if ("D" == type)  // Dental claim
                            {
                                ProcessDentalLiab(ppiExtData, nodelist);
                            }

                        break;
                    }
                }

                lcsModifiedData = allData.OuterXml;

                // send back our modified claim data back to Facets
                ppiExtData.SetData(lcsDataId, lcsModifiedData);

                // SUBLIABLOG
                // if (ppiExtData.LastResult)
                // {
                //     // now write out to log the extension data we are sending back to Facets
                //     lbRetVal = DataWrite(ppiExtData);
                // }
            }
            else
            {
                lbRetVal = false;
            }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(ppiExtData);
            return lbRetVal;
        }

        private void ProcessMedicalLiab(ErCoreIfcExtensionData.IFaExtensionData ppiExtData,
                                        XmlNodeList claimData)
        {
            bool done = false;

            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDMLALL")
                {
                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDMLALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        double copay        = 0.00;
                        double deductible   = 0.00;
                        double coinsurance  = 0.00;
                        double liabAmt = 0.00;
                        double totalPatientLiabAmt = 0.00;

                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDML_DED_AMT\"]");
                        string number = n.InnerText;
                        deductible = Double.Parse(number);

                        n = line.SelectSingleNode("Column[@name=\"CDML_COPAY_AMT\"]");
                        number = n.InnerText;
                        copay = Double.Parse(number);
 
                        n = line.SelectSingleNode("Column[@name=\"CDML_COINS_AMT\"]");
                        number = n.InnerText;
                        coinsurance = Double.Parse(number);

                        n = line.SelectSingleNode("Column[@name=\"CDML_SEQ_NO\"]");
                        string seqNo = n.InnerText;
                        liabAmt = medLiabOverride(claimData, seqNo);

                        if (liabAmt < 0)
                        {
                            liabAmt = calcCdmdLiab(ppiExtData, claimData, seqNo);
                        }

                        totalPatientLiabAmt = copay
                                                + coinsurance
                                                + deductible
                                                + liabAmt;
                        
                        n = line.SelectSingleNode("Column[@name=\"CDML_DIS_PA_LIAB\"]");
                        n.InnerText = liabAmt.ToString("F4");

                        n = line.SelectSingleNode("Column[@name=\"CDML_TOT_PA_LIAB\"]");
                        n.InnerText = totalPatientLiabAmt.ToString("F4");
                            
                    }
                    // found line items - no need to look at other collections
                    done = true;               
                }
                // found line items - no need to look at other collections
                if(done)
                    break;
             }
        }

        private double medLiabOverride(XmlNodeList claimData, string seqNo)
        {
            double liabAmt = -1.11;  // set to negative as signal no override found
            bool found = false;

            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDORALL")
                {

                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDORALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDML_SEQ_NO\"]");
                        string cdorSeqNo = n.InnerText;

                        if (cdorSeqNo == seqNo)
                        {
                            n = line.SelectSingleNode("Column[@name=\"CDOR_OR_ID\"]");

                            string id = n.InnerText;
                            if (id == "LD")
                            {
                                n = line.SelectSingleNode("Column[@name=\"CDOR_OR_AMT\"]");

                                string number = n.InnerText;
                                liabAmt = Double.Parse(number);

                                found = true; // found override for line, we are done
                                break;
                            }
                        }
                    }
                    // set found to break since if we found the CDDO array, no need to keep looking for it.
                    //      either override was found or it does not exist and don't need to look at other collections
                    found = true;
                }
                if (found)
                    break;
            }
 
            return liabAmt;
        }

        private double calcCdmdLiab(ErCoreIfcExtensionData.IFaExtensionData ppiExtData,
                                    XmlNodeList claimData, 
                                    string seqNo)
        {
            double totalLiabAmt = 0.00,
                   liabAmt = 0.00;
            bool itIsSubliab = false;
            bool found = false;

            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDMDALL")
                {

                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDMDALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDML_SEQ_NO\"]");
                        string cdmdSeqNo = n.InnerText;

                        if (cdmdSeqNo == seqNo)
                        {
                            n = line.SelectSingleNode("Column[@name=\"EXCD_ID\"]");
                            string excd = n.InnerText;

                            // Check the explanation to see if we use it or not?
                            itIsSubliab = readExcd(ppiExtData, excd);

                            if (itIsSubliab)
                            {
                                n = line.SelectSingleNode("Column[@name=\"CDMD_DISALL_AMT\"]");

                                string number = n.InnerText;
                                liabAmt = Double.Parse(number);

                                totalLiabAmt += liabAmt;
                            }
                        }
                    }
                    // set found to true since if we found the CDMD array, no need to keep looking for it.
                    found = true;
                }
                // done with process here
                if (found)
                    break;
            }

            return totalLiabAmt;
        }

        public bool readExcd(ErCoreIfcExtensionData.IFaExtensionData ppiExtData,
                              string excd)
        {
            bool subLiabFound = false;

            //  read Excd - seems to work for Sybase Microsoft Oracle
            string lcsData = ppiExtData.GetDbRequest("EXECUTE CMCSP_EXCD_SELECT @pEXCD_ID=\"" + excd + "\";");

            if (lcsData.Length > 0)
            {
                // SUBLIABLOG dump the read EXCD data
                // WriteOutput(lcsData);

                XmlDocument excdData = new XmlDocument();
                excdData.LoadXml(lcsData);

                XmlNode n = excdData.SelectSingleNode("/FacetsData/Column[@name=\"NUM_RESULTS\"]");
                string number = n.InnerText;
                int results = int.Parse(number);

                if(results == 1)
                {
                    XmlNodeList nodelist = excdData.SelectNodes("/FacetsData/Collection");

                    foreach (XmlNode node in nodelist) // for each <collection> node
                    {
                        string item;
                        item = node.Attributes.GetNamedItem("name").Value;

                        if (item == "DATA")
                        {
                            n = node.SelectSingleNode("Column[@name=\"EXCD_PT_LIAB_IND\"]");
                            string liabInd = n.InnerText;

                            // to specify actual values - for example a "P" means patient liability
                            if (liabInd.Equals("M"))
                            {
                                subLiabFound = true;
                            }
                            else
                            {
                                // However for this extenison any value in Liability Id consider as Patient Liablity
                                if (liabInd.Length > 0)
                                {
                                    subLiabFound = true;
                                }
                            }
                        }
                    }
                }
             }
        
            return(subLiabFound);
        }

        private void ProcessDentalLiab(ErCoreIfcExtensionData.IFaExtensionData ppiExtData,
                                        XmlNodeList claimData)
        {
            bool done = false;

            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDDLALL") // CMC_CDDL_CL_LINE
                {
                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDDLALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        double copay = 0.00;
                        double deductible = 0.00;
                        double coinsurance = 0.00;
                        double liabAmt = 0.00;
                        double totalPatientLiabAmt = 0.00;

                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDDL_DED_AMT\"]");
                        string number = n.InnerText;
                        deductible = Double.Parse(number);

                        n = line.SelectSingleNode("Column[@name=\"CDDL_COPAY_AMT\"]");
                        number = n.InnerText;
                        copay = Double.Parse(number);

                        n = line.SelectSingleNode("Column[@name=\"CDDL_COINS_AMT\"]");
                        number = n.InnerText;
                        coinsurance = Double.Parse(number);

                        n = line.SelectSingleNode("Column[@name=\"CDDL_SEQ_NO\"]");
                        string seqNo = n.InnerText;
                        liabAmt = dentalLiabOverride(claimData, seqNo);

                        if (liabAmt < 0)
                        {
                            liabAmt = calcCdddLiab(ppiExtData, claimData, seqNo);
                        }

                        totalPatientLiabAmt = copay
                                                + coinsurance
                                                + deductible
                                                + liabAmt;

                        n = line.SelectSingleNode("Column[@name=\"CDDL_DIS_PA_LIAB\"]");
                        n.InnerText = liabAmt.ToString("F4");

                        n = line.SelectSingleNode("Column[@name=\"CDDL_TOT_PA_LIAB\"]");
                        n.InnerText = totalPatientLiabAmt.ToString("F4");
                    }
                    // found dental line items - no need to look at other collections
                    done = true;
                }
                
                // found dental line items - no need to look at other collections
                if(done)
                    break;
            }
        }

        private double dentalLiabOverride(XmlNodeList claimData, string seqNo)
        {
            double liabAmt = -1.11;   // set to negative as signal no override found
            bool found = false;

            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDDOALL") // CMC_CDDO_DNLI_OVR
                {

                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDDOALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDDL_SEQ_NO\"]");
                        string cdorSeqNo = n.InnerText;

                        if (cdorSeqNo == seqNo)
                        {
                            n = line.SelectSingleNode("Column[@name=\"CDDO_OR_ID\"]");

                            string id = n.InnerText;
                            if (id == "LD")
                            {
                                n = line.SelectSingleNode("Column[@name=\"CDDO_OR_AMT\"]");

                                string number = n.InnerText;
                                liabAmt = Double.Parse(number);

                                found = true; // found override for line, we are done
                                break;
                            }
                        }
                    }
                    // set found to break since if we found the CDDO array, no need to keep looking for it.
                    //      either override was found or it does not exist and don't need to look at other collections
                    found = true;
                }
                // done with process here
                if (found)
                    break;
            }
 
            return liabAmt;
        }

        private double calcCdddLiab(IFaExtensionData ppiExtData, XmlNodeList claimData, string seqNo)
        {
            double totalLiabAmt = 0.00,
                   liabAmt = 0.00;
            bool itIsSubliab = false;
            bool found = false;


            foreach (XmlNode node in claimData) // for each <collection> node
            {
                string item;
                item = node.Attributes.GetNamedItem("name").Value;

                if (item == "CDDDALL")
                {

                    XmlNodeList linelist = node.SelectNodes("SubCollection[@name=\"CDDDALL\"]");

                    foreach (XmlNode line in linelist) // for each <collection> node
                    {
                        XmlNode n = line.SelectSingleNode("Column[@name=\"CDDL_SEQ_NO\"]");
                        string cdmdSeqNo = n.InnerText;

                        if (cdmdSeqNo == seqNo)
                        {
                            n = line.SelectSingleNode("Column[@name=\"EXCD_ID\"]");
                            string excd = n.InnerText;

                            // Check the explanation to see if we use it or not?
                            itIsSubliab = readExcd(ppiExtData, excd);

                            if (itIsSubliab)
                            {
                                n = line.SelectSingleNode("Column[@name=\"CDDD_DISALL_AMT\"]");

                                string number = n.InnerText;
                                liabAmt = Double.Parse(number);

                                totalLiabAmt += liabAmt;
                            }
                        }
                    }
                    // set found to true since if we found the CDDD array, no need to keep looking for it.
                    found = true;
                }
                // done with process here
                if (found)
                    break;
            }

            return totalLiabAmt;
        }

    // SUBLIABLOG (following functions are to dump data to log) begin 

    //    private bool DataWrite(ErCoreIfcExtensionData.IFaExtensionData ppiExtData)
    //    {
    //        string lcsData;
    //        string lcsDataId = ""; //Change if necessary to desired DataId
    //        bool lbRetVal = true;

    //       //GetData
    //        lcsData = ppiExtData.GetData(lcsDataId);
          
    //        if (ppiExtData.LastResult)
    //        {
    //            WriteOutput(lcsData);
    //        }
    //        else
    //        {
    //            lbRetVal = false;
    //        }

    //        mcStmWriter.Flush();
    //        mcStmWriter.Close();

    //         return lbRetVal;
    //    }

    //    private void WriteBanner(string pcsText)
    //    {
    //        StringBuilder lcsTemp = new StringBuilder(mcsDivider);

    //        try
    //        {
    //            lcsTemp.Append("# Claims Data - ");
    //            lcsTemp.Append(pcsText);
    //            lcsTemp.Append(" [");
    //            lcsTemp.Append(DateTime.Now);
    //            lcsTemp.Append("]\n");
    //            lcsTemp.Append(mcsDivider);
    //            WriteOutput(lcsTemp.ToString());
    //        }
    //        catch (System.Exception pException)
    //        {
    //            throw (pException);
    //        }
    //    }

    //    private void WriteOutput(string pcsText)
    //    {
    //        mcStmWriter.WriteLine(pcsText);
    //    }
 
    //    public void OpenLogFile()
    //    {
    //        if (File.Exists(mksLogPath))
    //        {
    //            mcStmWriter = File.AppendText(mksLogPath);
    //        }
    //        else
    //        {
    //            mcStmWriter = File.CreateText(mksLogPath);
    //        }
    //    }

    // SUBLIABLOG end

    }
}

 
