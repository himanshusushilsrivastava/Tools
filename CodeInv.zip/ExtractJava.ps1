﻿Get-ChildItem -Path "C:\Users\hsrivas1\Documents\GitHub\UHOneFacets\Repo1\*" -Include *.xml -Recurse | Copy-Item -Destination "C:\Users\hsrivas1\Desktop\UHONE-2.0\SearchTool\ImpactCode\xml\XML1" -Recurse -Force


#Copy-Item -LiteralPath $_.FullName -Destination "C:\Users\hsrivas1\Desktop\UHONE-2.0\SearchTool\ImpactCode\xml" |
#Get-Acl -Path $_.FullName | Set-Acl -Path ""C:\Users\hsrivas1\Desktop\UHONE-2.0\SearchTool\ImpactCode\xml"\$(Split-Path -Path $_.FullName -Leaf)"

