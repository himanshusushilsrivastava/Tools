﻿$date = Get-Date -format "yyyyMMdd"
$dateStr = Get-Date -format "MMddyyyyHHmmss"

#Reports Path
$reportpath = $PSScriptRoot + "\" + $dateStr + "_Code_Investigator.csv"

$SearchKeyword = Read-Host -Prompt 'Input your Search Keywords (Separate Multiple keywords with |)'

Get-ChildItem -recurse -Filter *.*  | Select-String -pattern "$SearchKeyword" | Select-Object path,filename,line,linenumber | Export-Csv -Path $reportpath

write "Report Generated at:" $reportpath

