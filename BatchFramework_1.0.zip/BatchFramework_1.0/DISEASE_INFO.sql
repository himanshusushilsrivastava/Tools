/******************************************************************************
 * DISEASE_Info - this table stores the disease info                          *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'DISEASE_INFO'
           AND    type = 'U')

    BEGIN

      DROP TABLE dbo.DISEASE_INFO.

      PRINT 'Table DISEASE_INFO.'

    END

GO
/******************************************************************************
 ** Table Name              : DISEASE_INFO                                    *
 **                                                                           *
 ** Purpose                 : Stores Diseases info                            *
 **                                                                           *
 **                                                                           *
 ** Revision History        :                                                 *
 ** Version Date        Modified By       Description                         *
 ** 1.0     june-28-2018 OGS offshore      Initial Version -                  *
 ******************************************************************************/

CREATE TABLE dbo.DISEASE_INFO(
        DISEASE_ID            char(20)    NOT NULL,
	      DISEASE_NAME          char(35)    NOT NULL,
        HEREDIATRY            char(1)     check(HEREDIATRY in ('Y','N')
);   

/******************************************************************************
 * Check for errors in creating the table DISEASE_INFO                  *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'DISEASE_INFO '
           AND    type = 'U')

    BEGIN

      PRINT 'DISEASE_INFO created successfully'

    END

ELSE

    BEGIN

      PRINT 'Error creating the table DISEASE_INFO '

    END
GO

