/******************************************************************************
 * DEMOGRAPHIC_INFO - this table stores the cost of diesease based on cost    *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'DEMOGRAPHIC_INFO'
           AND    type = 'U')

    BEGIN

      DROP TABLE dbo.DEMOGRAPHIC_INFO.

      PRINT 'Table DEMOGRAPHIC_INFO.'

    END

GO
/************************************************************************************
 ** Table Name              : DEMOGRAPHIC_INFO                                      *
 **                                                                                 *
 ** Purpose                 : this table stores the cost of diesease based on cost  *
 **                                                                                 *
 **                                                                                 *
 ** Revision History        :                                                       *
 ** Version Date        Modified By       Description                               *
 ** 1.0     june-28-2018 OGS offshore      Initial Version -                        *
 ***********************************************************************************/

CREATE TABLE dbo.DEMOGRAPHIC_INFO(
        COUNTRY            char(20)       NOT NULL,
	      STATE              char(2)        NOT NULL,
        DISEASE_ONE        char(20)       NOT NULL,
        COST_ONE           int            NOT NULL,
        DISEASE_TWO        char(20)       NOT NULL,
        COST_TWO           int            NOT NULL,
        DISEASE_THREE      char(20)       NOT NULL,
        COST_THREE         int            NOT NULL,
        DISEASE_FOUR       char(20)       NOT NULL,
        COST_FOUR          int            NOT NULL,
        DISEASE_FIVE       char(20)       NOT NULL,
        COST_FICE           int           NOT NULL,
        DISEASE_SIX        char(20)       NOT NULL,
        COST_SIX           int            NOT NULL,
        DISEASE_SEVEN      char(20)       NOT NULL,
        COST_SEVEN          int           NOT NULL,
        DISEASE_EIGHT      char(20)       NOT NULL,
        COST_EIGHT           int          NOT NULL,
        DISEASE_NINE       char(20)       NOT NULL,
        COST_NINE           int           NOT NULL,
        DISEASE_TEN        char(20)       NOT NULL,
        COST_TEN           int            NOT NULL
);

/******************************************************************************
 * Check for errors in creating the table DEMOGRAPHC_INFO                  *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'DEMOGRAPHC_INFO '
           AND    type = 'U')

    BEGIN

      PRINT 'DEMOGRAPHC_INFO created successfully'

    END

ELSE

    BEGIN

      PRINT 'Error creating the table DEMOGRAPHC_INFO '

    END
GO

