/******************************************************************************
 * USER - used to store file details of inbound or outboound job *
 ******************************************************************************/

/******************************************************************************
 * Check if the table already exists. If it exists, drop and recreate the     *
 * table                                                                      *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'USER_INFO'
           AND    type = 'U')

    BEGIN

      DROP TABLE dbo.USER_INFO.

      PRINT 'Table USER_INFO.'

    END

GO
/******************************************************************************
 ** Table Name              : USER_INFO                                            *
 **                                                                           *
 ** Purpose                 : Stores user info                                *
 **                                                                           *
 **                                                                           *
 ** Revision History        :                                                 *
 ** Version Date        Modified By       Description                         *
 ** 1.0     june-28-2018 OGS offshore      Initial Version -                  *
 ******************************************************************************/

CREATE TABLE dbo.USER_INFO(
  USER_ID               char(8) PRIMARY KEY   NOT NULL
	USER_FIRST_NAME       char(15)       NOT NULL,
	USER_LAST_NAME        char(35)       NULL,
	AGE                   int            NOT NULL,
	COUNTRY               char(20)       NOT  NULL,
	STATE                 char(2)        NOT NULL,
  SMOKE                 char(1)       check(SMOKE in ('Y','N')
);  

/******************************************************************************
 * Check for errors in creating the table USER_INFO                  *
 ******************************************************************************/

IF EXISTS(SELECT name
           FROM   sysobjects
           WHERE  name = 'USER_INFO '
           AND    type = 'U')

    BEGIN

      PRINT 'USER_INFO created successfully'

    END

ELSE

    BEGIN

      PRINT 'Error creating the table USER_INFO '

    END
GO

